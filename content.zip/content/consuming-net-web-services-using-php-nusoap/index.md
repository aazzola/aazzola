---
title: "Consuming .NET Webservices Using PHP and NuSoap"
draft: false
date: 2007-10-23 21:04
---
# Consuming .NET Webservices Using PHP and NuSoap

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2007-10-23 21:04
\[<a href="index.html" target="_self" title="Permalink to Consuming .NET Webservices Using PHP and NuSoap">Permalink</a>\]

In my scenario a .NET webservice offers particular encrypting capabilities. I need to consume the webservice with PHP by sending my plain string to get an encrypted one in return. The .NET webservice is working properly. I found the [NuSoap](http://sourceforge.net/projects/nusoap/ "NuSoap project Home Page") library, and adopted it, her the inclusion:

``` php
require_once('lib/nusoap.php');
```

And here the code:

``` php
// requires web service's specifications aka wsdl
// $parameters:
// requires following the array 'notation'
// array('parameters' => (array('text' => 'Hello World!!!')));
// that equals to Hello World!!!
// $proxy (->host, ->port, ->username, -> password)
// optional, uses a proxy server

function consume_webservice($wsdl, $method, $parameters, $debug = false, $proxy = null)
{
    if ($proxy != null)
        $proxy->host = $proxy->port = $proxy->username = $proxy->password = false;

    $client = new soapclient($wsdl, true, $proxy->host, $proxy->port,
        $proxy->username, $proxy->password);
    $err = $client->getError();

    if ($err)
        echo 'Constructor error' . $err;

    $result = $client->call($method, $parameters);

    // check for a fault
    if ($client->fault)
    {
        echo 'Fault';
        print_r($result);
    }
    else
    {
        // check for errors
        $err = $client->getError();

        if ($err)
            echo 'Error' . $err;
    }

    if ($debug)
    {
        echo 'Request' . htmlspecialchars($client->request, ENT_QUOTES);
        echo 'Response' . htmlspecialchars($client->response, ENT_QUOTES);
        echo 'Debug' . htmlspecialchars($client->debug_str, ENT_QUOTES);
    }

    return $result;
}
```

This approach works only with [soap](http://en.wikipedia.org/wiki/SOAP) webservices. Please note that .NET web services includes all response content into a "*parameters"* section by design.

Categories:

Share on:
<a href="https://twitter.com/intent/tweet?text=Consuming%20.NET%20Webservices%20Using%20PHP%20and%20NuSoap&amp;url=http%3a%2f%2fandreaazzola.com%2fconsuming-net-web-services-using-php-nusoap%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fconsuming-net-web-services-using-php-nusoap%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>