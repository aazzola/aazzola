---
title: "How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp"
draft: false
date: 2014-12-20 07:15
---
# How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2014-12-20 07:15
\[<a href="index.html" target="_self" title="Permalink to How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp">Permalink</a>\]

The article will describe **how to run ASP.NET vNext** on **Mac OS X**. The process, requires multiple configurations and therefore some patience. Luckily, OS X already includes one of the pre-requirements, **Ruby**, 2.0 on Mavericks and Yosemite, 1.8.7 on Mountain Lion, Lion, and Snow Leopard.

## Sublime Text

One very popular IDE or *advanced text editor* for Mac OS X is **<a href="http://www.sublimetext.com/" target="_blank" title="Sublime Text official website">Sublime Text</a>**. I use it on both OS X and Windows, for developing <a href="http://andreaazzola.com/category/salesforcecom" target="_blank" title="Salesforce.com posts">Salesforce.com</a> applications, to take notes or authoring this very article in pure HTML, and I'm very happy with it. Other supported IDEs—at the moment of writing—are:

- Atom - <a href="https://atom.io/" target="_blank" title="Atom editor">https://atom.io/</a>
- Emacs - <a href="http://www.gnu.org/software/emacs/" target="_blank" title="Emacs editor">http://www.gnu.org/software/emacs/</a>
- Brackets - <a href="http://brackets.io/" target="_blank" title="Brackets editor">http://brackets.io/</a>
- Vim - <a href="http://www.vim.org/" target="http://www.vim.org/" title="Vim editor">http://www.vim.org/</a>

## Homebrew

<a href="http://brew.sh/" target="_blank">Homebrew</a> is an open source package manager for Mac OS X, it leverages mostly on *git* and *ruby*. If you're not sure to have it installed, just open the *Terminal* and issue the command `brew doctor`. If the response is `command not found` well, it's not installed, so run the following command:`ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"`

## KVM, Mono and KRE

The **K Version Manager**—KVM—is a tool for installing different versions of the **ASP.NET vNext runtime** and switch between them. To install the KVM and Mono, run the command `brew tap aspnet/k`, this will only *tap*—reference—ASP.NET vNext repos, therefore launch `brew install kvm` to install the KVM package. This, will also install the latest K Runtime Environment—KRE.

## OmniSharp and Kulture

A prerequisite for this step is the <a href="https://sublime.wbond.net/installation" target="_blank" title="Package Control install">setup of Package Control</a>, please refer to the link for more details. Then, proceed to install the two following packages:

**Kulture**, is a Sublime Text package for ASP.NET vNext that brings the build system into the Sublime. To install it, press `CTRL+SHIFT+P`, then type `Install Package`, then `Kulture`, select it and press `Return`:

**OmniSharp** is a platform for enabling *C# cross-platform .NET development* for the IDE of your choice. In other words, *OmniSharp* plugs all the plumbing needed by the “Mac OS X based” IDE to behave like a proper .NET IDE. It supports both *Mac OS X*, *Linux* and *Windows*, and brings very useful features like *Auto Completion*, *Syntax/Semantic error highlighting*, *Build/ReBuild/Clean solution*, etc..

To install, follow the same procedure but type `OmniSharp` for the package name this time:

## Hello World

Let's check out the new setup:

1.  Clone the <a href="https://github.com/aspnet/Home" target="_blank" title="ASP.NET vNext Home repository">Home</a> repository: `git clone https://github.com/aspnet/Home`
2.  Browse the `/samples/HelloWeb/` folder
3.  Run `kpm restore` to restore dependencies, this may take a while
4.  Run `k kestrel`, aka the Mono *web server*
5.  Navigate you app at `http://localhost:5004`

And that should be it!

<embed src="../andrea-hugo-starter/static/5c2915260a1b98af29944694257d137cd3803b03.shtml" title="ASP.NET vNext HelloWeb" class="image-center" />

## References

- <a href="http://www.omnisharp.net/" target="_blank" title="OmniSharp official website">OmniSharp</a> official page
- <a href="https://github.com/aspnet/home#getting-started" target="_blank" title="ASP.NET vNext quickstart">Getting Started</a> on ASP.NET GitHub page

Categories:

Share on:
<a href="https://twitter.com/intent/tweet?text=How%20to%20run%20ASP.NET%20vNext%20on%20Mac%20OS%20with%20Kulture%20and%20OmniSharp&amp;url=http%3a%2f%2fandreaazzola.com%2faspnet-vnext-mac-os-omnisharp-kulture%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2faspnet-vnext-mac-os-omnisharp-kulture%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>