---
title: "Get Up And Code Podcast Review"
draft: false
date: 2015-01-17 08:22
---
# Get Up And Code Podcast Review

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2015-01-17 08:22
\[<a href="index.html" target="_self" title="Permalink to Get Up And Code Podcast Review">Permalink</a>\]

*I remember one time that I was under a pretty heavy barbell doing chest presses. I was listening to the podcast and the host made a very good joke, I lost my temper, I almost dropped the weight on myself and bursted out laughing in the middle of a otherwise very silent but also very populated gym. Luckily, I kept a bit of self control and saved possibly a few ribs. So be advised, and **listen responsibly ;)**.*

The discovery happened because I wanted to employ my daily commute to work to deepen my fitness knowledge amongst other things, confrontation is something that does not finds much space at the gym, people get there to workout and not much to talk. Scrolling through the *iTunes podcast directory*, health section, I found the **Get Up and Code** podcast and got intrigued. The description stated *fitness for developers* so I checked it out, hoping for a nicely tailored approach that might help me leverage some technical skills.

And I found that John (and Iris) teachings, were just what I needed:

1.  *No medical jargon* that I wouldn't have understood
2.  *Valuable tips* from *grounded people* with proven track record
3.  Talks between *friendly people* I could identify with

## The Show

The show focuses on **fitness** and **nutrition**. *Life hacks*, *wereables* are also part of the conversation. Being a developer—I would dare to say—is not a strict requirement, some might miss a few jokes or have a blurry understanding of few episodes at most.

The main host is **John Somnez**, an <a href="http://entreprogrammers.com/" target="_blank" title="The Entreprogrammers Podcast">enterpreneur,</a> [Pluralsight author](http://www.pluralsight.com/author/john-sonmez "John Somnez on Pluralsight"), <a href="http://simpleprogrammer.com" target="_blank" title="Simple Programmer">developer</a>, personal development coach, real estate investor and father. He also manages to produce Get Up And Code. **<a href="http://irisclasson.com/" target="_blank" title="Iris Classon&#39;s blog">Iris Classon</a>**, another expert developer (and nutritionist) co-hosted a significative percentage of the early episodes.

The show started in May 2013, since then John had managed to pull out episodes with a good consistency—74 at *17 Jan 2015*. Episodes lasts about 50 minutes average, there might be Somnez speaking solo, or they might involve a guest. Guests are usually athletes, coders, nutrion experts, niche experts, ranging from enthusiast to professional level. Few episodes also involves listeners as coaching subjects.

## Benefits of a Healthy Lifestyle

There are things going on in a person's body, at any given time: cell repair, hormonal response, immune reactions, termoregulation etc. The effectinevess of these functions is credited, by science, in small part to our genetic inheritance and in greater part to our state of health. Those processes are invisible, but have a huge impact on day-to-day life, I can personally vouch for a few:

- Wake up early in the morning without feeling groggy
- Costant energy flow throughout the day
- Improved cardiovascular system
- Improvements of posture, diminishing aches
- Faster recovery from injuries and diseases

Being healthy means being overall a better version of yourself, people often don't realize how much fitness and nutrition have impact on life. The body is a complex system, and should be handled in such regard, *Get Up and Code has demonstrate to be a very good medium in learning **how***.

## Health is a Habit, not a Goal

One of the reason why I appreciate podcasts, is because they have a schedule, and due to how our brain works—I warmly suggest the <a href="https://www.goodreads.com/book/show/11468377-thinking-fast-and-slow" target="_blank" title="Thinking, Fast and Slow by Daniel Kahneman">Thinking Fast and Slow by Daniel Kahneman</a> book for more insights—they may act as motivational nudge and habit builder.

If this is your first attempt toward a healthier lifestyle, I suggest, subscribe and help yourself making it an habit. Short burst of dedication, won't do any good and might also backfire—read: discouragement, pain. Start small and build from there, remember “divide et impera”!

## How to Subscribe

- iTunes <a href="https://itunes.apple.com/us/podcast/get-up-and-code!/id646958161" target="_blank" title="Get Up and Code on iTunes">https://itunes.apple.com/us/podcast/get-up-and-code!/id646958161</a>

Categories:
<a href="../category/fitness.html" class="tag">Fitness</a><a href="../category/personal-development.html" class="tag">Personal Development</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Get%20Up%20And%20Code%20Podcast%20Review&amp;url=http%3a%2f%2fandreaazzola.com%2fgetupandcode-podcast-review%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fgetupandcode-podcast-review%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>