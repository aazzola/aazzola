---
title: "Intermittent Fasting Diet and Benefits"
draft: false
date: 2016-09-06 06:20
---
# Intermittent Fasting Diet and Benefits

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2016-09-06 06:20
\[<a href="index.html" target="_self" title="Permalink to Intermittent Fasting Diet and Benefits">Permalink</a>\]

I have always found difficult to lose weight slowly, I'm a hearty eater and sometimes I also see food as a reward at the end of a stressful day. Self-control once bitten the first mouthful comes difficult, but ironically absolute abstention is much easier. Still I'm not obese, thanks to my habit of always practicing some sport; anyway, with the of the "beach-body readiness-test" pretext, I decided to shread a few extra kilos.

## The Intermittent Fasting Diet

So a few weeks ago I chose to adopt the *intermittent fasting* diet (IS). I ain't new to this: I eat once a day so between a meal and the other, I wait an average of 23 hours. The purpose of this diet is to concentrate meals in a small window: 8 hours or less (up to on meal a day, but not beyond) every day, in alternate days or only in certain days of the week. The approach means emulate natural cycles of food abundance and shortage: an adult man in nature in fact, would obtain a main meal per day and maybe throw in some snacks, but hardly could prepare the 6 balanced meals that some diets claims indispensible.

The concepts that follows represent my personal experience, before adopting the IS I strongly recommend that you consult a doctor.

## Benefits

The main benefit of adopting a small window on meals is that allows for the body and in particular for the digestive system to "heal itself". The food that we ingest, since chemically altered through physical processes such as cooking, is often a source of micro-infection, not such to be noted but sufficient to contribute to a generalized feeling of heaviness and energy deprivation. Being this a state of habit, first improvements can only be perceived after some effort.

But the main benefit sought from "fasters" is certainly weight loss: the IS is usually accompanied with a calorie restriction more or less drastic depending on oneself psycho-physical condition and objectives. The caloric restriction might require a a few sessions to kick in. It is important to understand that the body consume reserves in the following macro order:

1.  food in the digestive tract
2.  glycogen reserves in muscles and live
3.  fat reserves
4.  muscles, lean mass and tissues

In order to achieve a sculpted physique, it would be necessary adopt IS fast and being careful of never reach stage 4, which not only would provoke an undesirable loss of lean mass but also be extremely dangerous to health, since the body would literally start eating itself. These stages are however to be considered an indication, a minimum loss of lean mass is to be expected during stage 3 and 2, still additional proteins and amino acids can be supplemented to compensate for the loss.

Calorie loss during fasting, as during any caloric restriction, is mainly due to the sum basal metabolism (BMR) and physical activities performed. After about a couple of days stage 3 is reached, the liver passes from a diet based on glucose metabolism to the production of ketone bodies, accepted by the brain as a source of alternative nourishment, other tissues are instead able to assimilate fatty acids obtained from the synthesis of the adipose tissue.

## Day by day

As for committing to an IS regime, it is necessary to understand the correlation between calorie expenditure, metabolism and weight. My basal metabolism (BMR) is estimated at 3105 kcal/day: this number can be estimated online although I personally preferred to entrust a fitness tracker (such as the <a href="https://www.amazon.com/gp/product/B07FTN21JL/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=B07FTN21JL&amp;linkId=e0e6d082257aec961ca51179f1b1afeb" target="_blank" rel="nofollow" title="Fitbit Charge HR product description">Fitbit Charge HR</a>) that is also capable to take into account the extra activities of the day.

Consider that approximately 1 pound of body fat equals 3500 kcal: a day without introducing any food in a body eg. like mine could mean a weight loss of almost half a pound. Although calorie is still not a well defined measure unit and considering that the energy expenditure is *estimated*, it is important to carefully monitor weight, physical form, the energy levels in order to draw some conclusions.

During extended periods of IS (more than a week) the basal metabolism may lower activities: this is the response of the body to the caloric deficit. This mechanism exists naturally to increase efficiency in response to food unavailability. Fortunately the effect can be countered maintaining a high calorie expenditure through the assumption of temorgenic substances such as caffeine and green tea extract containing EGCG (Epigallocatechin Gallate).

The lower BMR constitutes a double-edged sword, in fact, stopping the fasting while the body works in *power saving* mode encourages the storage of every calorie introduced in the form of fat, obtaining the dreaded yo-yo effect. The fasting interruption therefore must be gradual and provide both a progressive increase of caloric intake, and an extension of the meal "window" and meal frequency. Luckily, the habit of fasting itself has the effect of promoting the habit of abstention from too much food.

In my daily meal, I strive for introducing only quality food (home-made, genuine and there shall be always vegetables) and reach at least 1000 calories, sometimes by supplementing with vitamin C, Vitamin D3, magnesium and phosphorus, Omega 3; the purpose of this is to replenish vitamins and mineral salts. It is also important to have a good percentage of proteins (at least 30%) to partially remedy to muscle catabolism that naturally occurs, although to a lesser extent, during fasting. It is also appropriate to avoid toxins stagnation and compensate for the hydration which normally would be introduced with food during the IS, so it's necessary to drink a lot.

My long term goal is to reach 10% or less of body fat, for a man typically means a well defined, toned body. For a woman the same result would at 15-20% of body (doesn't mean it would be easier though), while a body builder (male) would focus on 6-7%. I monitor regularly this data some impedance devices: a <a href="https://www.amazon.com/gp/product/B00BKRQ4E8/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=B00BKRQ4E8&amp;linkId=5259a259080477656a6f2b5a3deb9c05" target="_blank" rel="nofollow" title="Withing WS 50 product description">Withing Smart Body Analyzer scale</a>, but also a <a href="https://www.amazon.com/gp/product/B01DDX0B2W/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=B01DDX0B2W&amp;linkId=1aaad7a43dfff01ee2fa7b6c6e2ea331" rel="nofollow" target="_blank" title="Skulpt Pulse product description">Skulpt Pulse</a> for more accuracy. The latter in particular makes it possible to carry out measurements on specific body areas.

## It's Personal

There are many fasting variations, some aim to maximize body recovery, hormonal and circadian cycles, while others try not to be invasive and easy to adopt, others require fasting only on alternate or predetermined days (es: 5:2, 5 normal days and 2 of fasting). The formula is customizable to the individual's needs but the basic principle remains: skip the meal. Once learned how to properly fasting, it can be customized.

To obtain drastic results in less time I've chosen prolonged periods of abstention from food, very low caloric intakeand at a daily physical activity, but I still have two meals in special occasions. This allowed me to lose about 8kg in one month. When the "cutting" phase will be concluded, I'll switch to a 5:2 formula for the sake of maintenance.

Categories:
<a href="../category/nutrition.html" class="tag">Nutrition</a><a href="../category/fitness.html" class="tag">Fitness</a><a href="../category/diet.html" class="tag">Diet</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Intermittent%20Fasting%20Diet%20and%20Benefits&amp;url=http%3a%2f%2fandreaazzola.com%2fintermittent-fasting-diet-benefits%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fintermittent-fasting-diet-benefits%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>