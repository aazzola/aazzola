---
title: "Contact"
draft: false
---
# Contact

[Andrea Azzola](../index.html "Back to the Home Page")


Name\*
 

Subject

Email address\*
 
 

Message\*
 

Fields marked with an (\*) are mandatory

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/category/books/)
[Decision Fatigue](/category/decision-fatigue/)
[Diet](/category/diet/)
[Extreme Saving](/category/extreme-saving/)
[Finance](/category/finance/)
[Financial Independence](/category/financial-independence/)
[Fitness](/category/fitness/)
[Gears](/category/gears/)
[Geo Arbitrage](/category/geo-arbitrage/)
[Goal Setting](/category/goal-setting/)
[Nutrition](/category/nutrition/)
[Personal Branding](/category/personal-branding/)
[Personal Development](/category/personal-development/)
[Productivity](/category/productivity/)
[Time Management](/category/time-management/)
