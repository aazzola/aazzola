---
title: "Index"
draft: false
---

[Andrea Azzola](index.html "Back to the Home Page")

Tips and Techniques for Lifestyle Design


Based in Bergamo, 🇮🇹. I <a href="https://www.goodreads.com/andreaazzola" target="_blank" title="My GoodReads profile">read</a>, listen to <a href="https://open.spotify.com/user/1166954579" target="_blank">music</a> (used to <a href="https://soundcloud.com/icaromusic/" target="_blank" title="My artist profile">make it</a>), I'm a <a href="https://www.instagram.com/aa.cookingdiary/" target="_blank" title="My Instagram cooking blog">home cook</a>, and into fitness and diet. I work as a manager in an IT company, designing, building and managing Salesforce enterprise systems, check <a href="https://www.linkedin.com/in/andreaazzola/" target="_blank" title="Find me on LinkedIn">my LinkedIn page</a> to know more.

You can get in touch with me through the [contact form](/contact/) or my social accounts.

- <a href="http://instagram.com/andrea.azzola" target="_blank">Instagram</a>
- <a href="https://www.instagram.com/aa.cookingdiary/" target="_blank">Instagram — cooking account</a>
- <a href="https://twitter.com/AndreaAzzola" target="_blank">Twitter</a>
- <a href="http://www.linkedin.com/in/andreaazzola" target="_blank">LinkedIn</a>
- <a href="http://www.pinterest.com/andreaazzola" target="_blank">Pinterest</a>
- <a href="http://www.facebook.com/andrea.azzola" target="_blank">Facebook</a>
- <a href="https://www.goodreads.com/andreaazzola" target="_blank">Goodreads</a>
- <a href="https://open.spotify.com/user/1166954579" target="_blank">Spotify</a>
- <a href="https://soundcloud.com/icaromusic/" target="_blank">SoundCloud</a>
- <a href="https://trakt.tv/users/aazzola" target="_blank">Trakt</a>
- <a href="https://www.reddit.com/u/aazzola/" target="_blank">Reddit</a>

<a href="index.html" rel="author"></a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:__doPostBack(&#39;ctl00$stp1$lbLanguageEN&#39;,&#39;&#39;)" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:__doPostBack(&#39;ctl00$stp1$lbLanguageIT&#39;,&#39;&#39;)" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>