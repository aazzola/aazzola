---
title: "Books"
draft: false
date: 2016-10-22 12:16
---
# Books

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2016-10-22 12:16
\[[Permalink](/index/)\]

A list of what I believe to be the best books ever written, books that had a profound impact on my life. You can [follow me on GoodReads](https://www.goodreads.com/user/show/23362785-andrea-azzola) for more recommendations.

## Personal Development

### Essentialism: The Disciplined Pursuit of Less

#### by Greg McKeown

The Way of the Essentialist isn't about getting more done in less time. It's about getting only the right things done. It is not a time management strategy, or a productivity technique. It is a systematic discipline for discerning what is absolutely essential, then eliminating everything that is not, so we can make the highest possible contribution towards the things that really matter…

[Get a copy on Amazon](https://www.amazon.com/gp/product/0804137382/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=0804137382&amp;linkId=5744615c65c4f446385c87a9d1a762a6)

### How to Win Friends and Influence People

#### by Dale Carnegie

Since its release in 1936, How to Win Friends and Influence People has sold more than 15 million copies. Dale Carnegie's first book is a timeless bestseller, packed with rock-solid advice that has carried thousands of now famous people up the ladder of success in their business and personal lives.…

[Get a copy on Amazon](https://www.amazon.com/gp/product/0671027034/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=0671027034&amp;linkId=f32d00b1ecb1240c69871cfb158be9a5)

### Job Free: Four Ways to Quit the Rat Race

#### by Jake Desyllas

Whether you want to achieve financial independence and retire early, or simply never work for anyone else again, this book provides an essential guide to the different lifestyle-design strategies open to you.…

[Get a copy on Amazon](https://www.amazon.com/gp/product/1523680008/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=1523680008&amp;linkId=4ae6985133907ecb92ac9dbc4501a8b2)

### The Happiness Advantage

#### by Shawn Achor

Happiness fuels success, not the other way around. When we are positive, our brains become more engaged, creative, motivated, energetic, resilient, and productive at work. This isn’t just an empty mantra. This discovery has been repeatedly borne out by rigorous research in psychology and neuroscience, management studies, and the bottom lines of organizations around the globe…

[Get a copy on Amazon](https://www.amazon.com/gp/product/B003F3PMYI/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=B003F3PMYI&amp;linkId=8e5a2d6fe338016d3659aaa015a38974)

### Ego Is the Enemy

#### by Ryan Holiday

The Ego is the Enemy draws on a vast array of stories and examples, from literature to philosophy to history. We meet fascinating figures like Howard Hughes, Katharine Graham, Bill Belichick, and Eleanor Roosevelt, all of whom reached the highest levels of power and success by conquering their own egos. Their strategies and tactics can be ours as well…

[Get a copy on Amazon](https://www.amazon.com/gp/product/1591847818/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=1591847818&amp;linkId=223a4905c975ee90992a4291e5ec2658)

Categories:
[Books](/category/books/)

Share on:
[Twitter](https://twitter.com/intent/tweet?text=Book%20Recommendations&amp;url=http%3a%2f%2fandreaazzola.com%2fbooks%2f), 
[Facebook](http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fbooks%2f)

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- ))
- ))

#### Newsletter

 
 

[Books](/category/books/)
[Decision Fatigue](/category/decision-fatigue/)
[Diet](/category/diet/)
[Extreme Saving](/category/extreme-saving/)
[Finance](/category/finance/)
[Financial Independence](/category/financial-independence/)
[Fitness](/category/fitness/)
[Gears](/category/gears/)
[Geo Arbitrage](/category/geo-arbitrage/)
[Goal Setting](/category/goal-setting/)
[Nutrition](/category/nutrition/)
[Personal Branding](/category/personal-branding/)
[Personal Development](/category/personal-development/)
[Productivity](/category/productivity/)
[Time Management](/category/time-management/)
