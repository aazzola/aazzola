---
title: "Index"
draft: false
---

[Andrea Azzola](../index.html "Back to the Home Page")

Tips and Techniques for Lifestyle Design


Posted on
2016-10-22 12:16
\[<a href="index.html" target="_self" title="Permalink to Book Recommendations">Permalink</a>\]

A list of what I believe to be the best books ever written, books that had a profound impact on my life. You can <a href="https://www.goodreads.com/user/show/23362785-andrea-azzola" target="_black" title="My profile on GoodReads">follow me on GoodReads</a> for more recommendations.

## Personal Development

### Essentialism: The Disciplined Pursuit of Less

#### by Greg McKeown

The Way of the Essentialist isn't about getting more done in less time. It's about getting only the right things done. It is not a time management strategy, or a productivity technique. It is a systematic discipline for discerning what is absolutely essential, then eliminating everything that is not, so we can make the highest possible contribution towards the things that really matter…

<a href="https://www.amazon.com/gp/product/0804137382/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=0804137382&amp;linkId=5744615c65c4f446385c87a9d1a762a6" target="_blank" rel="nofollow" title="Essentialism: The Disciplined Pursuit of Less on Amazon">Get a copy on Amazon</a>

### How to Win Friends and Influence People

#### by Dale Carnegie

Since its release in 1936, How to Win Friends and Influence People has sold more than 15 million copies. Dale Carnegie's first book is a timeless bestseller, packed with rock-solid advice that has carried thousands of now famous people up the ladder of success in their business and personal lives.…

<a href="https://www.amazon.com/gp/product/0671027034/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=0671027034&amp;linkId=f32d00b1ecb1240c69871cfb158be9a5" target="_blank" rel="nofollow" title="How to Win Friends and Influence People on Amazon">Get a copy on Amazon</a>

### Job Free: Four Ways to Quit the Rat Race

#### by Jake Desyllas

Whether you want to achieve financial independence and retire early, or simply never work for anyone else again, this book provides an essential guide to the different lifestyle-design strategies open to you.…

<a href="https://www.amazon.com/gp/product/1523680008/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=1523680008&amp;linkId=4ae6985133907ecb92ac9dbc4501a8b2" target="_blank" rel="nofollow" title="Job Free: Four Ways to Quit the Rat Race on Amazon">Get a copy on Amazon</a>

### The Happiness Advantage

#### by Shawn Achor

Happiness fuels success, not the other way around. When we are positive, our brains become more engaged, creative, motivated, energetic, resilient, and productive at work. This isn’t just an empty mantra. This discovery has been repeatedly borne out by rigorous research in psychology and neuroscience, management studies, and the bottom lines of organizations around the globe…

<a href="https://www.amazon.com/gp/product/B003F3PMYI/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=B003F3PMYI&amp;linkId=8e5a2d6fe338016d3659aaa015a38974" target="_blank" rel="nofollow" title="The Happiness Advantage on Amazon">Get a copy on Amazon</a>

### Ego Is the Enemy

#### by Ryan Holiday

The Ego is the Enemy draws on a vast array of stories and examples, from literature to philosophy to history. We meet fascinating figures like Howard Hughes, Katharine Graham, Bill Belichick, and Eleanor Roosevelt, all of whom reached the highest levels of power and success by conquering their own egos. Their strategies and tactics can be ours as well…

<a href="https://www.amazon.com/gp/product/1591847818/ref=as_li_tl?ie=UTF8&amp;tag=aazzola00-20&amp;camp=1789&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=1591847818&amp;linkId=223a4905c975ee90992a4291e5ec2658" target="_blank" rel="nofollow" title="Ego Is the Enemy on Amazon">Get a copy on Amazon</a>

Categories:
<a href="../category/books.html" class="tag">Books</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Book%20Recommendations&amp;url=http%3a%2f%2fandreaazzola.com%2fbooks%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fbooks%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>