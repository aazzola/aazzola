---
title: "Downsizing your Home to Earn Back Time and Money"
draft: false
date: 2016-11-02 21:30
---
# Downsizing your Home to Earn Back Time and Money

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2016-11-02 21:30
\[<a href="index.html" target="_self" title="Permalink to Downsizing your Home to Earn Back Time and Money">Permalink</a>\]

Luxury cars, a cumbersome ski gear, guest rooms, a very spruced up guest bathroom, the second TV… these are only a few of the ways in which you can demonstrate your own success, the belonging to a ‘better’ social class. Collecting thousands of objects which are losing their value throughout time, possessing some spaces that require a full day maintenance, *a wellbeing which is often misleading.*

Downsizing is applied when families own a house that is above their necessities. Nowadays, it is not uncommon to see that, depending on the occasion, families tend to move in larger houses: a significant sale, an unexpected inheritance; in most cases, ‘to expand oneself’ is emotionally satisfying, but rationally speaking, it is less convenient and justifiable.

Buying a very big house straight away, a place where to grow a lot of children, might seem a prudent choice, but the family’s economic resources, the neighbourhood, the market opportunities can change by turning all projects upside down.

## The Downsizing Advantage

When we talk about **downsizing**, we mean the *transition towards a smaller-sized house*. The issue is particularly discussed in the United States and Australia, where the dimensions of the houses may exceed 200 square meters; Italy is more moderate with its 81 m2, although a lot of Italians would like bigger households.

First of all, selling a large house in favour of a modest one, can generate a ‘tidy sum’ to invest. Supposing we sold a house for 300.000 euro, and we bought another one for 180.000 euro, and cautiously considering 20.000 euro for practice, fees and relocation expenses, we would earn a whopping 100.000 euro, whose 3% of interest yields a *monthly 250-euro income*an amount which would be useful to many families. And a house valued less is usually more resalable.

Moreover, a smaller-sized house requires less energy for the heating and cooling system, has fewer insurance costs, is subject to fewer state fees, fewer waste disposal fees; but most of all, maintenance: the renewal of door and windows, a bigger heater, painting, garden maintenance, etc…

We also see an impact on a hypothetic mortgage, taking into account the houses from the previous example: a 250.000-euro mortgage, considering a deposit of 50.000 euro for 20 years, consists of a monthly payment of about 925 euro; a 130.000-euro mortgage (same deposit and duration conditions) consists of a payment of 428 euro, *46% of the commitment*. Besides, as well as being an amount which “is useful” to have in this case too, it also prevents the risks of a missed payment.

## A Perfect House

But, which is the perfect house? The perfect house is not needed to make an impression on your friends, it does not need to exceed the family’s economic resources, also it does not need to be the result of a social expectation. It must have the adequate dimensions, in order to provide the family with some comfortable space, according to the long-term needs (10 years), and it needs to be sustainable, both economic and timewise.

Of course, there needs to be some space to contain “all the stuff”, but it is better to get rid of the superfluous first; stealing some other time from maintenance and renovation to better employ it in *enjoying life*.

Categories:
<a href="../category/financial-independence.html" class="tag">Financial Independence</a><a href="../category/extreme-saving.html" class="tag">Extreme Saving</a><a href="../category/finance.html" class="tag">Finance</a><a href="../category/decluttering.html" class="tag">Decluttering</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Downsizing%20your%20Home%20to%20Earn%20Back%20Time%20and%20Money&amp;url=http%3a%2f%2fandreaazzola.com%2fdownsizing-home-and-earn-time-money%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fdownsizing-home-and-earn-time-money%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>