---
title: "The Goalodicy Trap"
draft: false
date: 2016-05-14 09:16
---
# The Goalodicy Trap

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2016-05-14 09:16
\[<a href="index.html" target="_self" title="Permalink to The Goalodicy Trap">Permalink</a>\]

## The Goalodicy

The *goalodicy* is the obsession in pursuing a goal, a compulsion such that the individual often ignores its own context. The term, coined by <a href="http://business.gwu.edu/profiles/d-christopher-kayes/" target="_blank" title="Academic profile of D. Christopher Kayes">D. Christopher Kayes</a> of the University of Washington, is a merge of the English words *goal* and *theodicy*, which etymology suggests a similarity to "divine justice" in Greek. Another common term for goalicity is *goal-blindness*

## The Everest Disaster

In May 1996, 34 climbers departed to the conquest of Mount Everest, the planet highest summit. The team was preparing at field IV, 7900 meters of altitude, the last checkpoint before the final goal at 8848 meters.

But the latest vertical meters are the most difficult—nicknamed "death zone", where severe weather conditions can strike suddenly, that climbers face with a limited number of oxygen tanks. A mishap can make the difference between life and death, coordination and teamwork are therefore essential.

On day 26, the New Zealand and the American teams departed for the last ascent. The Taiwanese team also departs, without appropriate notice, maybe due to a misunderstanding or a last-minute quarrel. A bottleneck forms at the Hillary Step, a leap of rock of about 10 meters, causing a two hours delay to the teams, such that the point of no return for the oxygen passes.

The climbers successfully reach the top. At come back time, they're caught by a sudden storm. Weakened muscles and adverse weather conditions make it for an impossible descent, as well as for any rescue operation. *Eight people died that day*.

The whole story is narrated in great detail in <a href="https://www.amazon.com/gp/product/0385494785/ref=as_li_qf_asin_il_tl?ie=UTF8&amp;tag=aazzola00-20&amp;creative=9325&amp;linkCode=as2&amp;creativeASIN=0385494785&amp;linkId=2f0e38ab2eff38bfc2ac4a378be6f2cc" target="_blank" rel="nofollow" title="Into Thin Air book description">Jon Krakauer's assay "Into Thin Air"</a>, the author took part in the expedition. The book was also made into a movie, <a href="http://amzn.to/2eTQJoV" target="_blank" rel="nofollow" title="Everest movie description">Everest (2015)</a>, which I recommend.

## The Lesson

According to the D. Kayes analysis, passion in pursuing an objective can become an obsession and lead to disaster, a real *destructive goal* as the doctor puts it in the omonimous book. While passion is therefore characterized by awareness of context and focused on the pleasure of doing, the obsession is blind.

This condition can be favored by many factors:

1.  **Limiting goals**: climb the Everest without focus on a safe comeback;
2.  **Social expectations**: the group pressure;
3.  **Idealization**: romantic notion and the seeking for identity in success;
4.  **Stress**: impairment of rational thought in favor to emotion;
5.  **Leadership**: unconditional acceptance of other people choices.

## Life & Work

In recent years we have witnessed a growth in the practice of *goal setting*, a science that was born to support the planning and the achievement of goals. Goal setting could be seen as a project management reinterpretation but oriented to the individual.

In goal setting studies the psychological component is often placed in second place, as a result goals set by individuals can be badly designed and misaligned with a bigger goal for life quality improvement. This can lead to loss of motivation or, on the opposite side to a blind compulsion to reach a dangerous goal, as the Everest teaches us.

It become fundamental to introduce and repeat introspection for situational awareness in ragards to the outcome, accept uncertainty in which the ability to respond, hides the true enrichment.

## Conclusion

Before establishing a goal, a preliminary torough examination is required, as a first repair from ill-conceived and potentially harmful goals. The <a href="https://en.wikipedia.org/wiki/SMART_criteria" target="_blank" title="Definition of S.M.A.R.T. on Wikipedia">SMART criteria</a> comes in aid. Goals that does not meet these criteria should be discarded or at least weighted. SMART stands for:

- **Specific**: focused on a specific aspect
- **Measurable**: quantifiable, both in terms of execution and progress
- **Assignable**: who would do it
- **Realistic**: realistic given the available resources
- **Time-related**: temporally bounded both terms of milestones and deadlines

Leverage fantasy, creativity and awareness. Constantly scan for priorities. Remeber to be individualist, essentialist and rational to establish true, useful and consisteng goals.

But especially be aware and self-examine in regard to the risk of goalodicy.

Categories:
<a href="../category/goal-setting.html" class="tag">Goal Setting</a><a href="../category/personal-development.html" class="tag">Personal Development</a><a href="../category/goalodicy.html" class="tag">Goalodicy</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=The%20Goalodicy%20Trap&amp;url=http%3a%2f%2fandreaazzola.com%2fgoal-blindness-goalodicy%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fgoal-blindness-goalodicy%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>