---
title: "Save Money with Traditional Wet Shaving"
draft: false
---
# Save Money with Traditional Wet Shaving

[Andrea Azzola](../index.html "Back to the Home Page")


### <a href="../saving-traditional-wet-shaving/index.html" target="_self" title="Permalink to Save Money with Traditional Wet Shaving">Save Money with Traditional Wet Shaving</a> 2018-04-07

The example shows how traditional wet shaving allows you to spend 8 times less in blades compared to a conventional cartridge multi-blade razor set up…

### <a href="../review-10x-rule-grant-cardone/index.html" target="_self" title="Permalink to Book Review: The 10X Rule by Grant Cardone">Book Review: The 10X Rule by Grant Cardone</a> 2016-12-04

The 10X Rule is a book about productivity within the business world, it underlines the importance of not limiting goals and taking 10 times higher levels of action to achieve them…

### <a href="../downsizing-home-and-earn-time-money/index.html" target="_self" title="Permalink to Downsizing your Home to Earn Back Time and Money">Downsizing your Home to Earn Back Time and Money</a> 2016-11-02

When we talk about downsizing your home, we mean the transition towards a smaller-sized house, stealing some other time from maintenance and renovation to better enjoy life…

### <a href="../robo-advisor-digital-portfolio-investing/index.html" target="_self" title="Permalink to Robo-advisors, When Investing Advice Becomes Digital and Efficient">Robo-advisors, When Investing Advice Becomes Digital and Efficient</a> 2016-10-31

Robot-advisors are software able to provide investment advises by operating through re-balancing algorithms for portfolio and capital management…

### <a href="../books/index.html" target="_self" title="Permalink to Book Recommendations">Book Recommendations</a> 2016-10-22

A list of what I believe to be the best books ever written, books that had a profound impact on my life.…

### <a href="../meal-prep-pouches-quick-easy/index.html" target="_self" title="Permalink to Quick and Easy Meal Prep Pouches">Quick and Easy Meal Prep Pouches</a> 2016-10-02

Meal prepping in advance and quantity is beneficial for 3 main reasons…

### <a href="../intermittent-fasting-diet-benefits/index.html" target="_self" title="Permalink to Intermittent Fasting Diet and Benefits">Intermittent Fasting Diet and Benefits</a> 2016-09-06

The purpose of the Intermittent Fasting diet is to concentrate meals in a small window: 8 hours or less (up to on meal a day, but not beyond) every day, in alternate days…

### <a href="../what-is-geo-arbitrage/index.html" target="_self" title="Permalink to A Lever Called Geo-Arbitrage">A Lever Called Geo-Arbitrage</a> 2016-06-20

The geo-arbitrage is the practice of economic-financial speculation based on disparity between geographic locations and markets…

### <a href="../goal-blindness-goalodicy/index.html" target="_self" title="Permalink to The Goalodicy Trap">The Goalodicy Trap</a> 2016-05-14

The goalodicy is the obsession in pursuing a goal, a compulsion such that the individual often ignores its own context…

### <a href="../waking-up-early-get-things-done/index.html" target="_self" title="Permalink to Waking Up Early And Getting Things Done">Waking Up Early And Getting Things Done</a> 2016-03-26

The simple act of waking up early in the morning can be one of the best productivity techniques…

### <a href="../path-to-financial-independence/index.html" target="_self" title="Permalink to The Path to Financial Independence">The Path to Financial Independence</a> 2016-03-20

The term financial independence indicates a state for which an individual can sustain itself without the need of an employment…

### <a href="../getupandcode-podcast-review/index.html" target="_self" title="Permalink to Get Up And Code Podcast Review">Get Up And Code Podcast Review</a> 2015-01-17

The show focuses on fitness and nutrition. The main host John Somnez is an enterpreneur, developer, personal development coach……

### <a href="../luck-surface-area/index.html" target="_self" title="Permalink to The Luck Surface Area Principle">The Luck Surface Area Principle</a> 2014-12-26

The Luck Surface Area principle states that increments of luck in a certain field of interest, can be achieved by doing and telling…

### <a href="../aspnet-vnext-mac-os-omnisharp-kulture/index.html" target="_self" title="Permalink to How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp">How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp</a> 2014-12-20

How to run ASP.NET on Mac OS X. The solution leverages on Sublime Text, Kulture and OmniSharp…

### <a href="../ergodox-ergonomic-keyboard-review/index.html" target="_self" title="Permalink to ErgoDox split Ergonomic Keyboard Review">ErgoDox split Ergonomic Keyboard Review</a> 2014-12-09

The ErgoDox is a fully programmable, DIY, split ergonomic keyboard compatible with Windows, Mac OS, \*nix…

### <a href="../personal-branding-introduction/index.html" target="_self" title="Permalink to Personal Branding, a Brief Introduction">Personal Branding, a Brief Introduction</a> 2014-06-07

Personal branding is a branch of marketing and a set of techniques for nurturing the public perception of self, like common brands…

### <a href="../review-filco-majestouch2-tenkeyless-ninja/index.html" target="_self" title="Permalink to Filco Majestouch-2 Tenkeyless Ninja Mechanical Keyboard Review">Filco Majestouch-2 Tenkeyless Ninja Mechanical Keyboard Review</a> 2014-05-29

The Filco Majestouch-2 Tenkeyless Ninja is a japanese mechanical keyboard that sport semi-blank keys, n-key rollover and it's built like a tank…

### <a href="../logging-nlog-sqlite/index.html" target="_self" title="Permalink to Logging with NLog and SQLite">Logging with NLog and SQLite</a> 2014-05-06

This article explains how to achieve a portable and elegant logging solution with NLog and SQLite, the solution targets the .NET platform and only requires a few configurations…

### <a href="../mavensmate-unable-github-windows/index.html" target="_self" title="Permalink to MavensMate unable to reach GitHub on Windows">MavensMate unable to reach GitHub on Windows</a> 2014-04-06

MavensMate setup may fail on Microsoft Windows machines due to a 'installer being unable to reach GitHub' error. Here a possible solution…

### <a href="../search-email-inbox-csharp/index.html" target="_self" title="Permalink to Search Email Inbox with C#">Search Email Inbox with C#</a> 2014-03-27

A C# snippet based on the AE.NET.Mail library, for searching an email inside a mailbox Inbox, through the IMAP protocol…

### <a href="../pomodoro-apps/index.html" target="_self" title="Permalink to A few handy Pomodoro Timer Apps for Mac and Windows">A few handy Pomodoro Timer Apps for Mac and Windows</a> 2014-03-27

The best apps for applying the Pomodoro technique on Windows or Mac: Pomodairo, Focus Booster, Tomighty, Tomato.ist…

### <a href="../human-multitasking/index.html" target="_self" title="Permalink to Humans and Multitasking">Humans and Multitasking</a> 2014-01-30

Is it possible to achieve true multitasking? The capability of performing multiple tasks concurrently and still obtain optimal results?…

### <a href="../javascript-date-handling-format/index.html" target="_self" title="Permalink to Manage and format Dates with JavaScript">Manage and format Dates with JavaScript</a> 2013-11-14

There are a couple of options for dealing with Javascript dates, the JS Date object is usually the way to go, and if you're looking for an alternative solution…

### <a href="../ichigo-asp-net-blogging-engine/index.html" target="_self" title="Permalink to Ichigo, an ASP.NET Blogging Engine">Ichigo, an ASP.NET Blogging Engine</a> 2013-11-12

A brief intro to the Ichigo ASP.NET blogging engine, a minimalistic Azure enabled Web forms application…

### <a href="../salesforce-backup-organization-svn-git/index.html" target="_self" title="Permalink to Automate SVN/Git Backups of Entire Salesforce.com Organizations">Automate SVN/Git Backups of Entire Salesforce.com Organizations</a> 2013-10-17

The solution shows a way to version entire Salesforce.com organizations. It involves two popolar SCMs (SVN and Git), an always-on server and a few free tools…

### <a href="../table-size-space-sql-server/index.html" target="_self" title="Permalink to Get Size of Tables with SQL Server">Get Size of Tables with SQL Server</a> 2013-10-16

A snippet for retrieving the size of all tables in a SQL Server database that might prove useful for understanding where most of your data is going…

### <a href="../salesforce-debug-log-apex/index.html" target="_self" title="Permalink to Dealing with Salesforce Maximum Debug Log Size">Dealing with Salesforce Maximum Debug Log Size</a> 2013-07-18

When you have Apex code that iterates a lot, you might obtain truncated log files and an error: MAXIMUM DEBUG LOG SIZE REACHED…

### <a href="../havisi-magic-emi/index.html" target="_self" title="Permalink to New Remix Out! Magic Emi by Havisi">New Remix Out! Magic Emi by Havisi</a> 2012-02-21

I'm happy to announce that Magic Emi by Havisi is now available on Beatport, including my remix (Icaro)…

### <a href="../future-count-apex/index.html" target="_self" title="Permalink to Future count with Apex Code">Future count with Apex Code</a> 2011-07-14

A simple snippet for counting @future calls in a 24 hours timespan, may be useful for monitoring peaks and act accordingly…

### <a href="../requiredfieldvalidator-radcombobox/index.html" target="_self" title="Permalink to Simulating a RequiredFieldValidator when using a RadComboBox">Simulating a RequiredFieldValidator when using a RadComboBox</a> 2010-10-22

Telerik's RadComboBox does not behave like a traditional DropDownList. You may consider to use a CustomValidator…

### <a href="../transform-sentence-slug-js/index.html" target="_self" title="Permalink to Turn Sentences into Slugs with JavaScript">Turn Sentences into Slugs with JavaScript</a> 2010-10-20

The script allows you to turn a text string into a proper URL slug with jQuery…

### <a href="../remix-nanni-hannibal-invasion/index.html" target="_self" title="Permalink to New Remix Out! Hannibal Invasion by NaNni">New Remix Out! Hannibal Invasion by NaNni</a> 2010-10-16

I'm happy to announce that Hannibal Invasion by NaNni is now available on Beatport, including my remix (Icaro)…

### <a href="../set-september-2010/index.html" target="_self" title="Permalink to New DJ Set! September 2010 for MaGmA Radio Sho">New DJ Set! September 2010 for MaGmA Radio Sho</a> 2010-09-04

Here's my DJ set aired in September 2010 for the MaGmA Radio Show, enjoy.…

### <a href="../set-june-2010/index.html" target="_self" title="Permalink to New DJ Set! June 2010 for the MaGmA Radio Sho">New DJ Set! June 2010 for the MaGmA Radio Sho</a> 2010-06-14

Here's my DJ set aired in June 2010 for the MaGmA Radio Show, enjoy.…

### <a href="../web-service-reference-vs/index.html" target="_self" title="Permalink to Import Web service References in .NET">Import Web service References in .NET</a> 2010-06-09

You need to consume Web services from client applications. There's a tool for design just to do that , it's called wsdl.exe…

### <a href="../log-http-requests/index.html" target="_self" title="Permalink to How to log HTTP requests with PHP">How to log HTTP requests with PHP</a> 2010-05-27

Sometimes you need to understand precisely how the HTTP request is submitted to the server. That, can be also be achieved with PHP…

### <a href="../set-april-2010/index.html" target="_self" title="Permalink to April 2010 - MaGmA Radio Show">April 2010 - MaGmA Radio Show</a> 2010-05-27

### <a href="../set-february-2010/index.html" target="_self" title="Permalink to New DJ Set! February 2010 for the MaGmA Radio Show">New DJ Set! February 2010 for the MaGmA Radio Show</a> 2010-02-07

Here's my DJ set aired in February 2010 for the MaGmA Radio Show, enjoy!…

### <a href="../seo-asp-net-routing/index.html" target="_self" title="Permalink to Improve ASP.NET SEO by using System.Web.Routing">Improve ASP.NET SEO by using System.Web.Routing</a> 2010-01-18

ASP.NET offers a great resource called 'System.Web.Routing' that support routes.
Routes translates both the pattern and context parameters…

### <a href="../asus-eeepc-1201ha/index.html" target="_self" title="Permalink to Asus EeePC 1201HA review">Asus EeePC 1201HA review</a> 2010-01-09

The EeePC 1201HA is part of a new generation of big netbooks, in fact, this particular one sports a 12.1 inch monitor…

### <a href="../remix-francois-le-roy-mosquito/index.html" target="_self" title="Permalink to New Remix Out! Mosquito by Francois Le Roy">New Remix Out! Mosquito by Francois Le Roy</a> 2009-12-22

Twerok Records is proud to present a new label artist, Francois Le Roy and his debut single Mosquito…

### <a href="../set-november-2009/index.html" target="_self" title="Permalink to New DJ Set! November 2009 for the MaGmA Radio Show">New DJ Set! November 2009 for the MaGmA Radio Show</a> 2009-12-22

Here's my DJ set aired in November 2009 for the MaGmA Radio Show, enjoy!…

### <a href="../call-async-method/index.html" target="_self" title="Permalink to Call async methods with C#">Call async methods with C#</a> 2009-10-15

This article help you in delegating work to an asynchronous thread in C#, thus allowing for code execution and App responsitivity…

### <a href="../post-data-js/index.html" target="_self" title="Permalink to POST data with JavaScript">POST data with JavaScript</a> 2009-07-07

In this scenario, form data are restricted to ASCII codes. If the method is "post" --, the user agent conducts an HTTP post transaction…

### <a href="../sennheiser-hd-25-review/index.html" target="_self" title="Permalink to Sennheiser HD 25-II headphones review">Sennheiser HD 25-II headphones review</a> 2009-06-12

I first heard about the Sennheiser HD-II from a professional producer a while ago, still one of the best DJ/producer headphone you can get…

### <a href="../js-notification-panel-gmail/index.html" target="_self" title="Permalink to JavaScript Auto-collapsing Notification Panel">JavaScript Auto-collapsing Notification Panel</a> 2009-05-29

In almost all web applications comes the moment when it becomes necessary to show some notifications to the user…

### <a href="../get-radio-checked-js/index.html" target="_self" title="Permalink to Get and Set Radio controls checked value with JavaScript">Get and Set Radio controls checked value with JavaScript</a> 2009-03-20

The getElementsByName method allows you to obtain a collection of controls from the (X)HTML DOM, by specifying the common name value…

### <a href="../clean-sp-cache-sql-server/index.html" target="_self" title="Permalink to Clean Up Stored Procedures Cache with SQL Server">Clean Up Stored Procedures Cache with SQL Server</a> 2009-03-06

When deploying a stored procedure, a clean up the db's cache might go a long way in order to apply changes immediately…

### <a href="../multiple-columns-dynamic-data/index.html" target="_self" title="Permalink to Handle Multiple Columns as One with Dynamic Data">Handle Multiple Columns as One with Dynamic Data</a> 2008-11-02

I decided to deeply customize the FieldTemplateUserControl of Dynamic Data, to display and save multiple Columns I needed…

### <a href="../upload-large-files-asp-net/index.html" target="_self" title="Permalink to Allow the Upload of Large Files with ASP.NET">Allow the Upload of Large Files with ASP.NET</a> 2008-06-24

This Web.config setting allows for a bigger size on uploaded files by tuning both the execution time and max request length parameters…

### <a href="../check-metamodel-existence-dynamic-data-application/index.html" target="_self" title="Permalink to Check the MetaModel Existence while Running a Dynamic Data Application">Check the MetaModel Existence while Running a Dynamic Data Application</a> 2008-06-18

In the web application that I'm developing using Dynamic Data, I set the DataContext at runtime because the application might bind different contexts.…

### <a href="../set-connectionstring-runtime-dynamicdata/index.html" target="_self" title="Permalink to Set the ConnectionString at Runtime with DynamicData">Set the ConnectionString at Runtime with DynamicData</a> 2008-06-16

The following snippet customizes the .NET ConnectionString property at runtime in a Dynamic Data application…

### <a href="../consuming-net-web-services-using-php-nusoap/index.html" target="_self" title="Permalink to Consuming .NET Webservices Using PHP and NuSoap">Consuming .NET Webservices Using PHP and NuSoap</a> 2007-10-23

A .NET webservice offers particular encrypting capabilities. I need to consume the webservice with PHP…

### <a href="../using-ajax-modalpopup-targetcontrol/index.html" target="_self" title="Permalink to Using an ajax:ModalPopup Without a TargetControl">Using an ajax:ModalPopup Without a TargetControl</a> 2007-09-25

Sometimes you may want to show and hide the panel programmatically. All you need, is a fake activator like following…

### <a href="../issues-ajax-custom-httpmodule/index.html" target="_self" title="Permalink to Issues With AJAX and a Custom HttpModule">Issues With AJAX and a Custom HttpModule</a> 2005-06-18

While implementing an HttpModule that handle URLs in a SEO friendly way, the AJAX script module gets in the way…

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:__doPostBack(&#39;ctl00$stp1$lbLanguageEN&#39;,&#39;&#39;)" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:__doPostBack(&#39;ctl00$stp1$lbLanguageIT&#39;,&#39;&#39;)" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>
