---
title: "Content"
draft: false
---
# Content

[Andrea Azzola](index.html "Back to the Home Page")


Based in Bergamo, 🇮🇹. I [read](https://www.goodreads.com/andreaazzola), listen to [music](https://open.spotify.com/user/1166954579) (used to [make it](https://soundcloud.com/icaromusic/)), I'm a [home cook](https://www.instagram.com/aa.cookingdiary/), and into fitness and diet. I work as a manager in an IT company, designing, building and managing Salesforce enterprise systems, check [my LinkedIn page](https://www.linkedin.com/in/andreaazzola/) to know more.

You can get in touch with me through the [contact form](/contact/) or my social accounts.

- [Instagram](http://instagram.com/andrea.azzola)
- [Instagram — cooking account](https://www.instagram.com/aa.cookingdiary/)
- [Twitter](https://twitter.com/AndreaAzzola)
- [LinkedIn](http://www.linkedin.com/in/andreaazzola)
- [Pinterest](http://www.pinterest.com/andreaazzola)
- [Facebook](http://www.facebook.com/andrea.azzola)
- [Goodreads](https://www.goodreads.com/andreaazzola)
- [Spotify](https://open.spotify.com/user/1166954579)
- [SoundCloud](https://soundcloud.com/icaromusic/)
- [Trakt](https://trakt.tv/users/aazzola)
- [Reddit](https://www.reddit.com/u/aazzola/)

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/category/books/)
[Decision Fatigue](/category/decision-fatigue/)
[Diet](/category/diet/)
[Extreme Saving](/category/extreme-saving/)
[Finance](/category/finance/)
[Financial Independence](/category/financial-independence/)
[Fitness](/category/fitness/)
[Gears](/category/gears/)
[Geo Arbitrage](/category/geo-arbitrage/)
[Goal Setting](/category/goal-setting/)
[Nutrition](/category/nutrition/)
[Personal Branding](/category/personal-branding/)
[Personal Development](/category/personal-development/)
[Productivity](/category/productivity/)
[Time Management](/category/time-management/)
