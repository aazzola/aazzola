---
title: "ErgoDox split Ergonomic Keyboard Review"
draft: false
date: 2014-12-09 19:30
---
# ErgoDox split Ergonomic Keyboard Review

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2014-12-09 19:30
\[<a href="index.html" target="_self" title="Permalink to ErgoDox split Ergonomic Keyboard Review">Permalink</a>\]

The **ErgoDox** is a DIY ergonomic keyboard, featuring a *split design*—each half, one hand. The two halves are connected with a *phone TRRS connector cable*, while the connection to the PC—or Mac or Unix—is obtained trough a detachable mini USB.

## History

The project <a href="https://geekhack.org/index.php?topic=22780.0" target="_blank" title="GeekHack.org forum">has been initiated</a> by Dominic Beauchamp—aka Dox, from which the keyboard name derives—on the GeekHack.org forum; the design has been largerly inspired by the <a href="http://www.key64.org/" target="_blank" title="Key64 keyboard">Key64</a> project by Nestor Diaz.

The ErgoDox keyboard is licensed with GNU GPL v3, everybody can make their own modifications, with the only constraint that the original name *ErgoDox* is protected.

## The keyboard

The keyboard itself accomodates approximately 76 keys. The size of keycaps may vary according to function and position. Keycaps can be repositioned according to preference and keys itself—thanks to a <a href="https://www.pjrc.com/store/teensy.html" target="_blank" data-="teensy="" data-2.0="" data-page"="">Teensy 2.0 AVR Microcontroller</a>—can be remapped to accomplish different layouts—QWERTY, Dvorak, Colemak, etc...—and/or personal preferences.

The typical ErgoDox sports **Cherry MX** switches. It can, of course, mount any type of commercial Cherry MX. **ALP** switches are another option. As for keys, the most popular are <a href="http://keyshop.pimpmykeyboard.com/products/full-keysets/dsa-blank-sets-1" target="_blank" title="DSA PTB blanks page">Signature Plastics PBT DSA keycaps</a>, which are characterized by their rounded shape, a low profile, nice textured surface and no legend—commonly referred to as *ninja* or *stealth*.

There are three casings for sale that I personally know about:

1.  The <a href="http://ergodox.org/Downloads.aspx" target="_blank" title="ErgoDox case by Dox">original case designed by Dox</a>, it is the most refined version but also the less popular due to the 3D printing costs.
2.  The *acrylic case by lilster*, is the one you see in the pictures, it is made by sheets of acrylic stacked together, and it is completly trasparent. On mine there's a top aluminum plate, but just for a more minimalistic/rugged look.
3.  The *PVC case by Falbatech*, available both in <a href="http://falbatech.pl/prestashop/index.php?id_product=9&amp;controller=product" target="_blank" title="ErgoDox PVC white case by Falbatech">white</a> and <a href="http://falbatech.pl/prestashop/index.php?id_product=23&amp;controller=product" target="_blank" title="ErgoDox PVC black case by Falbatech">black</a>, probably one of the best compromises in terms of better look/price ratio right now.

## Feel

The fingers, can *spread horizontally* and stay relaxed, benefiting from a more open and natural course of movement, each key is within reach. Partly of that is thanks to the fact that keycaps are distributed in **columns** instead of rows. Thumbs, *have their own set of keys*, and being the thumbs, the most powerful and usually neglected fingers, this is big deal—normally you would use just one and just for hitting the spacebar. Wrists, won't move much like they would on a normal one—except for a few key combos—resulting in dimished/absent wrist pain over prolonged periods of use.

I would definitely reccomend it to a 9-to-5 computer user, it may take some effort to adapt, but it pays back with interests. Expecially if you're a typist, writing a book or articles, the ErgoDox feels like the fountain pen of keyboards. *Software developers* and *gamers* might find it a little bit limitating, because of the missing function keys which many IDE and games take advantage of, and although keys can be remapped, I do see some difficulties with more intricate patterns. It can even backfire as a collaboration deterrent—I advise to keep a normal keyboard always connected to the workstation, as a courtesy to colleagues

## How to buy

The *ErgoDox* can't be purchased from any official store or retailer, it must be built, unless someone is willing to sell his own, which is pretty rare. Luckily, there are few people that offer assembly as a service.

Electronic parts, can be bought trough <a href="https://www.massdrop.com/r/KEP8XC" target="_blank" title="Massdrop website">Massdrop</a>. Massdrop is a company focused on *group buys*, users can commit to buy a certain item, and if enough committers are reached, the group buy—aka *drop*—gets submitted to the supplier. Multiple suppliers may be involved, but worry not! Massdrop will take care of all the logistics, charge you one single payment and ship the whole package.

It should be noted that *drops*, because of their crowdsourced nature, are not always open, instead, they're based on the sum of *user requests* for the item. Typically—at the time of writing—new drops for ErgoDoxes are opened *every few months*.

But shipping costs and import taxes from U.S. might spike the deal, a more budget friendly alternative for **europeans** would be <a href="http://falbatech.pl" target="_blank" title="Falbatech website">Falbatech</a>, a Polish company started by two brothers, it sells pretty much all the parts plus, optional assembly.

## Ergodox assembly

Parts:

- 1x Teensy 2.0 AVR Microcontroller
- 2 Cases (PVC/Layered acrylic/3D) and screws
- 2 PCB
- 76-80 x Cherry MX switch
- 76-80 x 1N4148W-7-F diode (in-hole/smd)
- 1 x MCP23018 I/O expander
- 2 x 3.5mm TRRS connectors
- 1 x TRRS cable
- 1 x USB mini B plug
- 1 x 0.1uF ceramic capacitor
- 1 x 2.2k ohm resistor
- 3 x 3mm T1 LED
- 2 x 220 ohm resistor
- 2 x USB cable Male A to male mini B

First thing to consider is **soldering**, if you're new to this, <a href="https://www.youtube.com/results?search_query=smd+soldering+tutorial" target="_blank" title="Soldering tutorials on YouTube">I would reccomend to start on YouTube</a>, then you'll need at minimum:

- **SMD solder iron**—fine tip, scalpel even better
- **Solder wire**
- **Solder wick** for cleaning excees of solder or for reworks

The following two resources describe all the process in detail. **WhiteFireLion's video** in particular, is very comprehensive:

# Si è verificato un errore.

Impossibile eseguire JavaScript

Another great resource is the **<a href="https://www.massdrop.com/ext/ergodox/assembly" target="_blank" title="Massdrop Assembly Instructions">Massdrop Assembly Instructions</a>** page

## References

- <a href="https://www.massdrop.com/r/KEP8XC" target="_blank" title="Massdrop">Massdrop</a> ErgoDox group buys
- [Deskthority](http://deskthority.net/wiki/ErgoDox "ErgoDox on Deskthority") in-depth review
- <a href="http://geekhack.org" target="_blank" title="GeekHack community">GeekHack.org</a> community of keyboards enthusiasts.
- <a href="http://ergodox.org" target="_blank" title="ErgoDox project page">ErgoDox</a> project page

Categories:
<a href="../category/ergonomic.html" class="tag">Ergonomic</a><a href="../category/ergonomic.html" class="tag">Ergonomic</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=ErgoDox%20split%20Ergonomic%20Keyboard%20Review&amp;url=http%3a%2f%2fandreaazzola.com%2fergodox-ergonomic-keyboard-review%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fergodox-ergonomic-keyboard-review%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>