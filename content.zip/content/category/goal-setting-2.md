---
title: "Goal Setting 2"
draft: false
---

[Andrea Azzola](../index.html "Back to the Home Page")

Tips and Techniques for Lifestyle Design


- [Book Review: The 10X Rule by Grant Cardone](/review-10x-rule-grant-cardone/) 
  //2016-12-04
- [The Goalodicy Trap](/goal-blindness-goalodicy/) 
  //2016-05-14

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/books/)
[Decision Fatigue](/decision-fatigue/)
[Diet](/diet/)
[Extreme Saving](/extreme-saving/)
[Finance](/finance/)
[Financial Independence](/financial-independence/)
[Fitness](/fitness/)
[Gears](/gears/)
[Geo Arbitrage](/geo-arbitrage/)
[Goal Setting](/goal-setting/)
[Nutrition](/nutrition/)
[Personal Branding](/personal-branding/)
[Personal Development](/personal-development/)
[Productivity](/productivity/)
[Time Management](/time-management/)