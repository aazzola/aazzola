---
title: "Productivity"
draft: false
---
# Productivity

[Andrea Azzola](../../index.html "Back to the Home Page")


- [Quick and Easy Meal Prep Pouches](/../meal-prep-pouches-quick-easy/) 
  //2016-10-02
- [Waking Up Early And Getting Things Done](/../waking-up-early-get-things-done/) 
  //2016-03-26
- [A few handy Pomodoro Timer Apps for Mac and Windows](/../pomodoro-apps/) 
  //2014-03-27
- [Humans and Multitasking](/../human-multitasking/) 
  //2014-01-30

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/books/)
[Decision Fatigue](/decision-fatigue/)
[Diet](/diet/)
[Extreme Saving](/extreme-saving/)
[Finance](/finance/)
[Financial Independence](/financial-independence/)
[Fitness](/fitness/)
[Gears](/gears/)
[Geo Arbitrage](/geo-arbitrage/)
[Goal Setting](/goal-setting/)
[Nutrition](/nutrition/)
[Personal Branding](/personal-branding/)
[Personal Development](/personal-development/)
[Productivity](/index/)
[Time Management](/time-management/)
