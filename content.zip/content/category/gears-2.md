---
title: "Gears 2"
draft: false
---

[Andrea Azzola](../index.html "Back to the Home Page")

Tips and Techniques for Lifestyle Design


- [Asus EeePC 1201HA review](/asus-eeepc-1201ha/) 
  //2010-01-09
- [Sennheiser HD 25-II headphones review](/sennheiser-hd-25-review/) 
  //2009-06-12

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/books/)
[Decision Fatigue](/decision-fatigue/)
[Diet](/diet/)
[Extreme Saving](/extreme-saving/)
[Finance](/finance/)
[Financial Independence](/financial-independence/)
[Fitness](/fitness/)
[Gears](/gears/)
[Geo Arbitrage](/geo-arbitrage/)
[Goal Setting](/goal-setting/)
[Nutrition](/nutrition/)
[Personal Branding](/personal-branding/)
[Personal Development](/personal-development/)
[Productivity](/productivity/)
[Time Management](/time-management/)