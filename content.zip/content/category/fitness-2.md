---
title: "Fitness 2"
draft: false
---

[Andrea Azzola](../index.html "Back to the Home Page")

Tips and Techniques for Lifestyle Design


- [Quick and Easy Meal Prep Pouches](/meal-prep-pouches-quick-easy/) 
  //2016-10-02
- [Intermittent Fasting Diet and Benefits](/intermittent-fasting-diet-benefits/) 
  //2016-09-06
- [Get Up And Code Podcast Review](/getupandcode-podcast-review/) 
  //2015-01-17

Author's portrait

[My Twitter profile](http://twitter.com/AndreaAzzola)[My LinkedIn profile](http://www.linkedin.com/in/andreaazzola)[My Facebook profile](http://www.facebook.com/andrea.azzola)[My Pinterest profile](http://www.pinterest.com/andreaazzola)[My Instagram profile](http://instagram.com/andrea.azzola)


- )
- )

#### Newsletter

 
 

[Books](/books/)
[Decision Fatigue](/decision-fatigue/)
[Diet](/diet/)
[Extreme Saving](/extreme-saving/)
[Finance](/finance/)
[Financial Independence](/financial-independence/)
[Fitness](/fitness/)
[Gears](/gears/)
[Geo Arbitrage](/geo-arbitrage/)
[Goal Setting](/goal-setting/)
[Nutrition](/nutrition/)
[Personal Branding](/personal-branding/)
[Personal Development](/personal-development/)
[Productivity](/productivity/)
[Time Management](/time-management/)