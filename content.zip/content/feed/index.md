---
title: "Andrea Azzola"
draft: false
---# Andrea Azzola

http://andreaazzola.comen-usSun, 15 Feb 2009 12:00:00 GMT

Save Money with Traditional Wet Shaving

http://andreaazzola.com/saving-traditional-wet-shaving/I own a Gillette "Fusion ProGlide" (amazon link), a very effective multi-blade razor, equipped with a movable head that allows for reaching all face's nooks and crannies quickly, pretty much without risks. It features a vibrating mechanism, which makes it very comfortable. But the cost of cartridges, no less than 11 euros for 4, is not cheap.
For some years now I've been interested in…\I own a Gillette "Fusion ProGlide" (\<a href="https://amzn.to/2QK1ot3" target="\_blank" title="Gillette Fusion5 ProGlide Men’s Razor, Handle & 2 Blade Refills"\>amazon link\</a\>), a very effective multi-blade razor, equipped with a movable head that allows for reaching all face's nooks and crannies quickly, pretty much without risks. It features a vibrating mechanism, which makes it very comfortable. But the cost of cartridges, no less than 11 euros for 4, is not cheap.\</p\>
\For some years now I've been interested in minimalism, especially from a financial point of view, simply trying to reason where money can be spent consciously. There's no guarantee in the path of the "becoming man" for "shaving orientation": when the first beard appears, our fathers usually direct us towards the multi-blade as a practical and rarely dangerous option. With the passing of years it becomes as a plateau for many men.\</p\>
\\![](/images/resource)\</p\>
\<h2\>The Safety Razor\</h2\>
\Safety razors usually have two components, handle and blade holder. The blade needs to be mounted in the blade holder, it is used at an inclination of 30 degrees, inclination which might slightly change depending on the razor. Two sharp sides allows for more passings and less rinsing. Both razor sides are usually equipped with combs (closed or opened), that stretch the skin before blade's passage. Replacing the blade is as easy as unscrewing the parts and opening the blade holder. Other models may have a TTO (twist-to-open) or "butterfly" opening system, a handy version that opens by "screwing" the bottom part of the handle.\</p\>
\First safety razors in their traditional T-shape were produced in Sheffield, England, around the middle of the fourteenth century. In 1880 the American brothers Kampfe had the design patented, their version had a single blade meant to be removed and sharpened like we usually do with knives; in 1900 are the first disposable razor blades are born. It was the 1918 when the United States decided to equip soldiers with razors: the beard made the gas mask ineffective. Gillette wins the procuremnt bid of 3.5 million razors,and 32 million razor blades. The T-shape of has since remained unchanged.\</p\>
\Price of blades makes this type of razors extremely convenient: quality razor blades can be found at a price of 3 cents each, while the "Fusion ProGlide" multi-blade cartridges cost no less than 2.75 euro each, but comes with a longer life span. The comparison does not acquire a sense until the costs of the two setups are compared. Below a project based on 182 annual shaves.\</p\>
\<h3\>Gillette Fusion ProGlide\</h3\>
\

\- Razor's cost=12 &euro; (\<a href="https://amzn.to/2QK1ot3" target="\_blank" title="Gillette Fusion5 ProGlide Men’s Razor, Handle & 2 Blade Refills"\>amazon link\</a\>)\</li\>
\- \<strong\>Start-up=12 &euro;\</strong\>\</li\>
\

\

\- Price for each cartridge 11/4=2.75 &euro;\</li\>
\- Each cartridge is lasts about 10 shaves, cost per shave=.275 &euro;\</li\>
\- \<strong\>182 shaves cost=50 &euro;\</strong\>\</li\>
\

\<h3\>Edwin Jagger DE89bl\</h3\>
\

\- Razor's cost=16 &euro; (\<a href="https://amzn.to/2rtqTAA" target="\_blank" title="Edwin Jagger Double Edge Safety Razor"\>amazon link\</a\>)\</li\>
\- Brush's cost=15 &euro; (sintetic that emulates badger, \<a href="https://amzn.to/2Pzv5bw" target="blank" title="RazoRock Plissoft Disruptor Synthetic Shaving Brush"\>amazon link\</a\>)\</li\>
\- \<strong\>Start-up=31 &euro;\</strong\>\</li\>
\

\

\- Cost for each blade 10 &euro;/100=0.1 &euro;\</li\>
\- Each blade lasts about 3 shave, cost per shave=.0333 &euro;\</li\>
\- \<strong\>182 shaves cost=6.06 &euro;\</strong\>\</li\>
\

\<h2\>Considerations\</h2\>
\The start-up costs of the traditional setup are basically double, they are however compensated by razor and brush life span, several years at least. The example demonstrates how you can spend up to 8 times less with the traditional setup.\</p\>
\Paradoxically, ther's a well-developed market niche for traditional shaving aficionados, rich with a variety of products from the most exotic artisinal and luxurious manufacture. According to modern masculine style rules in fact, traditional shaving is a plus.\</p\>
\I personally come from more than two years of traditional shaving, to is a moment of wellness, I spent time experimenting different razor blades&mdash;which might differ in hardness and sharpening&mdash;or appreciating the softness the density and the aroma of a new soap .... All this while still saving money.\</p\>
\<h2\>Subscriptions\</h2\>
\A small side note... many services now offer cartridge supplies subscriptions, meaning that you can automatically get multiblades delivered to your home. These offers aim to gain space in a monopolized market leaded by a few companies by distrupting the business model, committing the customer to the volumes, while choosing alternative suppliers and technologies, in order to offer competitive prices.\</p\>
\Personally I appreciate the existence of these alternatives, unfortunately I do not see a real competion to traditional shaving due to the recurring costs these subscription exercise.\</p\>Sat, 07 Apr 2018 10:02:00 GMThttp://andreaazzola.com/saving-traditional-wet-shaving

Book Review: The 10X Rule by Grant Cardone

http://andreaazzola.com/review-10x-rule-grant-cardone/Among the bestsellers of the self-help category on Audible.com, The 10X Rule is a book about productivity within the business world, it underlines the importance of not limiting goals and taking 10 times higher levels of action in order to achieve them, placing the success as an essential milestone: "if you're not first, you're last".
The book's author is Greg Cardone, an American…\\![](/images/resource)\</p\>
\Among the bestsellers of the self-help category on Audible.com, \<strong\>The 10X Rule\</strong\> is a book about productivity within the business world, it underlines the importance of not limiting goals and \<em\>taking 10 times higher levels of action\</em\> in order to achieve them, placing the success as an essential milestone: \<em\>"if you're not first, you're last"\</em\>.\</p\>
\The book's author is Greg Cardone, an American entrepreneur with an estimated networth of 500 million dollars. He began his career as a car salesman, soon CEO of Freedom Motorsports Group Inc., he worked on a television series for the National Geographic channel named Turnaround King, where he helps small businesses to get back on their feet. Author of 10 books, now directs his companies \<i\>Cardone Acquisitions\</i\>, \<i\>Cardone Enterprises\</i\> and \<i\>The Cardone Group\</i\>; Cardone has been choosen by Forbes as the most promising Marketing Influencer for 2017.\</p\>
\<h2\>Book Review\</h2\>
\The beginning of the book was a bit disappointing: a little bit irrational, full of hyperboles, not what I hoped from a five-starred best seller. Cardone uses \<em\>an aggressive salesman style\</em\>, sometimes \<em\>challenging the reader's values in a subtly disrespectful way\</em\>. I soon stopped reading and was ready to discard it.\</p\>
\There was some potential in the ideas though, so I spoke about it to a friend, he read the book, agreed on my objections and in the end he was fairly optimistic. So I felt compelled to finish considered that after all, the narration was quite enjoyable. One thing that particularly set me off: Cardone stresses that commitment to success is a duty owed to the simple fact the we exists. He discredits the values of a modest/frugal life, stating they are values taught by some kind of propaganda to keep people under control. But of course that's one of Cardone's opinion on which no one is oblidged to embrace.\</p\>
\As today however, this book is one the most mentioned in our conversations, for one simple reason. It talks about a single fundamental rule that people sometimes don't know or forget: \<strong\>if you to want to get 100, go for 1000\</strong\>&mdash;\<em\>an Italian saying\</em\>.\</p\>
\Most people might tend to look at the "once blue moon successes" and forget that statistically for every success there are countless failures and only increasing the amount of effort one can streghten her skills and increase her chances. Throughout the book there are many clever ideas and interpretations to credit this principle, making it a worthwhile reading.\</p\>
\This controversial concepts had surely gained the book a lot of attention, which has become a New York Time best seller. And like Cardone reminds us: there's no such thing as bad publicity.\</p\>
\<h2\>My 6 Key Takeaways\</h2\>
\

\- set goals that are ten time more ambitious\</li\>
\- act 10 times greater than what you consider normal\</li\>
\- to compete is wrong, one must dominate\</li\>
\- obsession is not a disease, it's a blessing\</li\>
\- getting clients is more important than supporting them\</li\>
\- commit and take opportunities, figure out &quot;stuff&quot; later\</li\>
\

\
\<a href="https://amzn.to/2NnPD60" class="btn btn-warning" role="button" target="\_blank" title="The 10X Rule on Amazon.com" rel="nofollow"\>All editions of \<strong\>The 10X Rule\</strong\> on Amazon.com\</a\>
\</p\>Sun, 04 Dec 2016 17:03:00 GMThttp://andreaazzola.com/review-10x-rule-grant-cardone

Downsizing your Home to Earn Back Time and Money

http://andreaazzola.com/downsizing-home-and-earn-time-money/Luxury cars, a cumbersome ski gear, guest rooms, a very spruced up guest bathroom, the second TV… these are only a few of the ways in which you can demonstrate your own success, the belonging to a ‘better’ social class. Collecting thousands of objects which are losing their value throughout time, possessing some spaces that require a full day maintenance, a wellbeing which is often…\\![](/images/resource)\</p\>
\Luxury cars, a cumbersome ski gear, guest rooms, a very spruced up guest bathroom, the second TV… these are only a few of the ways in which you can demonstrate your own success, the belonging to a ‘better’ social class. Collecting thousands of objects which are losing their value throughout time, possessing some spaces that require a full day maintenance, \<em\>a wellbeing which is often misleading.\</em\>\</p\>
\Downsizing is applied when families own a house that is above their necessities. Nowadays, it is not uncommon to see that, depending on the occasion, families tend to move in larger houses: a significant sale, an unexpected inheritance; in most cases, ‘to expand oneself’ is emotionally satisfying, but rationally speaking, it is less convenient and justifiable.\</p\>
\Buying a very big house straight away, a place where to grow a lot of children, might seem a prudent choice, but the family’s economic resources, the neighbourhood, the market opportunities can change by turning all projects upside down.\</p\>
\<h2\>The Downsizing Advantage\</h2\>
\When we talk about \<strong\>downsizing\</strong\>, we mean the \<em\>transition towards a smaller-sized house\</em\>. The issue is particularly discussed in the United States and Australia, where the dimensions of the houses may exceed 200 square meters; Italy is more moderate with its 81 m2, although a lot of Italians would like bigger households.\</p\>
\First of all, selling a large house in favour of a modest one, can generate a ‘tidy sum’ to invest. Supposing we sold a house for 300.000 euro, and we bought another one for 180.000 euro, and cautiously considering 20.000 euro for practice, fees and relocation expenses, we would earn a whopping 100.000 euro, whose 3% of interest yields a \<em\>monthly 250-euro income\</em\>an amount which would be useful to many families. And a house valued less is usually more resalable.\</p\>
\Moreover, a smaller-sized house requires less energy for the heating and cooling system, has fewer insurance costs, is subject to fewer state fees, fewer waste disposal fees; but most of all, maintenance: the renewal of door and windows, a bigger heater, painting, garden maintenance, etc&hellip;\</p\>
\We also see an impact on a hypothetic mortgage, taking into account the houses from the previous example: a 250.000-euro mortgage, considering a deposit of 50.000 euro for 20 years, consists of a monthly payment of about 925 euro; a 130.000-euro mortgage (same deposit and duration conditions) consists of a payment of 428 euro, \<em\>46% of the commitment\</em\>. Besides, as well as being an amount which “is useful” to have in this case too, it also prevents the risks of a missed payment.\</p\>
\<h2\>A Perfect House\</h2\>
\But, which is the perfect house? The perfect house is not needed to make an impression on your friends, it does not need to exceed the family’s economic resources, also it does not need to be the result of a social expectation. It must have the adequate dimensions, in order to provide the family with some comfortable space, according to the long-term needs (10 years), and it needs to be sustainable, both economic and timewise.\</p\>
\Of course, there needs to be some space to contain “all the stuff”, but it is better to get rid of the superfluous first; stealing some other time from maintenance and renovation to better employ it in \<em\>enjoying life\</em\>.\</p\>
Wed, 02 Nov 2016 21:30:00 GMThttp://andreaazzola.com/downsizing-home-and-earn-time-money

Robo-advisors, When Investing Advice Becomes Digital and Efficient

http://andreaazzola.com/robo-advisor-digital-portfolio-investing/Robot-advisors are software able to provide investment advices by operating through rebalancing algorithms. They can limit themselves to advice, giving the investor the duty and the freedom to manage the investment; or they can lean on some bank accounts to get the whole portfolio management automated. They guarantee the capital diversification, and can be fed through random deposits…\\![](/images/resource)\</p\>
\Robot-advisors \<strong\>are software able to provide investment advices\</strong\> by operating through rebalancing algorithms. They can \<em\>limit themselves to advice\</em\>, giving the investor the duty and the freedom to manage the investment; or they can lean on some bank accounts to get \<em\>the whole portfolio management\</em\> automated. They guarantee the capital diversification, and can be fed through random deposits and \<em\>dollar cost averaging (DCA)\</em\>.\</p\>
\<h2\>About my experience\</h2\>
\I found out about robot-advisors while I was extricating myself in the world of swing trading; at that time, I was studying and investing my first amounts of money. The results were pretty decent, but on the other hand I had to \<em\>spend most of my time in analysis and following news\</em\>, and I also realized that my modest capital was being poorly diversified. So, I decided to ask a professional for an advice.\</p\>
\Since I didn’t know what to do, I started, like many others did in the beginning, with Google: I found out about the independent consultants (fee-only) and then the robot-advisors. In the past, my knowledge as a developer already led me to think about some short algorithms to make a few calculations easier, to learn about firms that were able to diversify and automatically invest, but still with “bold” risk, by removing the human component of the equation; I got convinced to put my project aside and, temporarily at least, delegate the exhausting \<em\>investments matter\</em\>.\</p\>
\<h2\>Pros e cons\</h2\>
\The first benefit of robot-advisors is related to \<em\>management costs\</em\>. About a yearly 1-1,5% of the invested capital is due to the consultant, while the robot-advisor gets less than the 1%; traditional consulting firms require a minimum investment of about &#36;50000, while some robot-advisors can even decrease down to &#36;500.\</p\>
\This drastic decrease of costs is due to robot-advisors’ ability to work large-scale, by managing thousands of clients at the same time. So, the costs get reduced depending on the invested capitals, and then, there are some free robot-advisors that get benefits from extra services only. But, whereas traditional consultants work with a certain dynamism over the market, robot-advisors predict rebalancing mechanisms of cadenced or extraordinary investments, making them appropriate for those who’re looking for low reactivity solutions, so long term ones.\</p\>
\The second benefit is related to \<em\>greater independence\</em\>. Many of the robot-advisor firms were born in the fintech scenery and outside the financial monopolies, therefore they’re free to invest with creativity and in the best interests of the client. Although the “independent” system is present in the traditional consultancy too, through \<em\>the fee-only system\</em\>, robot-advisors’ higher accessibility made the entry level of the independence be within everyone's reach.\</p\>
\The portfolio management, then, takes place typically via web or mobile app; own investments can be looked up or edited 24h/24h. The apps let you build portfolios by customizing the level of risk and the asset class: if oriented, for example, towards the debenture, then more conservative and less profitable; if towards the stock and active management funds, riskier but with a higher potential profit. The main appeal of these tools, is obviously their ease of use.\</p\>
\Whereas the financial regulation permits it, like it happens in the USA, robot-advisors can get to \<em\>optimize the payment of taxes\</em\>, guaranteeing further savings. And naturally, like every other subject related to financing management, they’re institutionally regulated and supervised.\</p\>
\But robot-advisors, compared to the traditional consultancy, nowadays, are not able to satisfy highly customized necessities. Robot-advisors, then, are not really meant to replace the consultant function, but to work as alternative or supplementary investment tools, regarding the disappointing bank deposit, or the risky do-it-yourself approach.\</p\>
\<h2\>Best robot-advisories of 2016\</h2\>
\I've been with Moneyfarm for about 2 years now and I consider myself satisfied, and in particular, the portfolio got to bear the market’s instability moments pretty well. It is possible to sign in through \<a href="http://andreaazzola.com/out/moneyfarm/" target="\_blank" title="Subscribe to Moneyfarm" rel="nofollow"\>this link\</a\>; by choosing \<i\>Why Moneyfarm \> Yields\</i\> there’s also the opportunity to check the trend of the investment profiles available over the years.\</p\>Mon, 31 Oct 2016 08:51:00 GMThttp://andreaazzola.com/robo-advisor-digital-portfolio-investing

Book Recommendations

http://andreaazzola.com/books/A list of what I believe to be the best books ever written, books that had a profound impact on my life. You can follow me on GoodReads for more recommendations.
Personal Development
Essentialism: The Disciplined Pursuit of Less
by Greg McKeown
The Way of the Essentialist isn't about getting more done in less time. It's about getting only the right things done.…\A list of what I believe to be the best books ever written, books that had a profound impact on my life. You can \<a href="https://www.goodreads.com/user/show/23362785-andrea-azzola" target="\_black" title="My profile on GoodReads"\>follow me on GoodReads\</a\> for more recommendations.\</p\>
\<h2\>Personal Development\</h2\>
\

\
\![](/images/books/essentialism-disciplined-pursuit-greg-mckeown_150.png)\

\

\<h3\>Essentialism: The Disciplined Pursuit of Less\</h3\>
\<h4\>by Greg McKeown\</h4\>
\The Way of the Essentialist isn't about getting more done in less time. It's about getting only the right things done. It is not a time management strategy, or a productivity technique. It is a systematic discipline for discerning what is absolutely essential, then eliminating everything that is not, so we can make the highest possible contribution towards the things that really matter&hellip;\</p\>
\
\<a href="https://www.amazon.com/gp/product/0804137382/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=0804137382&linkId=5744615c65c4f446385c87a9d1a762a6" target="\_blank" title="Essentialism: The Disciplined Pursuit of Less on Amazon" rel="nofollow"\>Get a copy on Amazon\</a\>\

\

\

\

\
\![](/images/books/how-win-friends-influence-people_150.png)\

\

\<h3\>How to Win Friends and Influence People\</h3\>
\<h4\>by Dale Carnegie\</h4\>
\Since its release in 1936, How to Win Friends and Influence People has sold more than 15 million copies. Dale Carnegie's first book is a timeless bestseller, packed with rock-solid advice that has carried thousands of now famous people up the ladder of success in their business and personal lives.&hellip;\</p\>
\
\<a href="https://www.amazon.com/gp/product/0671027034/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=0671027034&linkId=f32d00b1ecb1240c69871cfb158be9a5" target="\_blank" title="How to Win Friends and Influence People on Amazon" rel="nofollow"\>Get a copy on Amazon\</a\>\

\

\

\

\
\![](/images/books/job-free-achieve-financial-freedom_150.png)\

\

\<h3\>Job Free: Four Ways to Quit the Rat Race\</h3\>
\<h4\>by Jake Desyllas\</h4\>
\Whether you want to achieve financial independence and retire early, or simply never work for anyone else again, this book provides an essential guide to the different lifestyle-design strategies open to you.&hellip;\</p\>
\
\<a href="https://www.amazon.com/gp/product/1523680008/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=1523680008&linkId=4ae6985133907ecb92ac9dbc4501a8b2" target="\_blank" title="Job Free: Four Ways to Quit the Rat Race on Amazon" rel="nofollow"\>Get a copy on Amazon\</a\>\

\

\

\

\
\![](/images/books/happiness-advantage-principles-psychology-performance-ebook_150.png)\

\

\<h3\>The Happiness Advantage\</h3\>
\<h4\>by Shawn Achor\</h4\>
\Happiness fuels success, not the other way around. When we are positive, our brains become more engaged, creative, motivated, energetic, resilient, and productive at work. This isn’t just an empty mantra. This discovery has been repeatedly borne out by rigorous research in psychology and neuroscience, management studies, and the bottom lines of organizations around the globe&hellip;\</p\>
\
\<a href="https://www.amazon.com/gp/product/B003F3PMYI/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=B003F3PMYI&linkId=8e5a2d6fe338016d3659aaa015a38974" target="\_blank" title="The Happiness Advantage on Amazon" rel="nofollow"\>Get a copy on Amazon\</a\>\

\

\

\

\
\![](/images/books/ego-enemy-ryan-holiday_150.png)\

\

\<h3\>Ego Is the Enemy\</h3\>
\<h4\>by Ryan Holiday\</h4\>
\The Ego is the Enemy draws on a vast array of stories and examples, from literature to philosophy to history. We meet fascinating figures like Howard Hughes, Katharine Graham, Bill Belichick, and Eleanor Roosevelt, all of whom reached the highest levels of power and success by conquering their own egos. Their strategies and tactics can be ours as well&hellip;\</p\>
\
\<a href="https://www.amazon.com/gp/product/1591847818/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=1591847818&linkId=223a4905c975ee90992a4291e5ec2658" target="\_blank" title="Ego Is the Enemy on Amazon" rel="nofollow"\>Get a copy on Amazon\</a\>\

\

\

Sat, 22 Oct 2016 12:16:00 GMThttp://andreaazzola.com/books

Quick and Easy Meal Prep Pouches

http://andreaazzola.com/meal-prep-pouches-quick-easy/Meal prepping in advance and quantity is beneficial for 3 main reasons:
Save time: cooking, shopping and washing dishes
Diet control: a batch of strategic meals helps fight junk food
Save money: buying in quantity is cheaper, traveling to the supermarket only once is cheaper as well, you save on cleaning materials too
Specifically, In this article I’ll teach you how to…\Meal prepping in advance and quantity is beneficial for 3 main reasons:\</p\>
\

\- \<strong\>Save time\</strong\>: cooking, shopping and washing dishes\</li\>
\- \<strong\>Diet control\</strong\>: a batch of strategic meals helps fight junk food\</li\>
\- \<strong\>Save money\</strong\>: buying in quantity is cheaper, traveling to the supermarket only once is cheaper as well, you save on cleaning materials too\</li\>
\

\\![](/images/resource)\</p\>
\Specifically, In this article I’ll teach you how to prepare meals for several months using a practical technique that’s very easy to implement.\</p\>
\<h2\>Meal Prep Pouches\</h2\>
\The advantage of meal prep pouches, as opposed to classic plastic containers, are the \<em\>compact space\</em\> and the \<em\>lesser air stored\</em\> (less air equals less bacteria). The less space our meal prep pouches use the more we'll be able to store and benefit without cooking again.\</p\>
\As for the air that gets stored in the pouch, common sense applies: fresh food needs to be stored and frozen immediately after cooking. You can of course opt for a \<a href="https://www.amazon.com/gp/search/ref=as_li_qf_sp_sr_il_tl?ie=UTF8&tag=aazzola-20&keywords=vacuum sealer&index=aps&camp=1789&creative=9325&linkCode=xm2&linkId=91358781b4f838274ed34999629890be" target="\_blank" title="Vacuum Sealers system" rel="nofollow"\>vacuum sealer system\</a\> if you like, some people find them impractical because of the machine cost, the more expensive pouch&mdash;not all are compatible, and the long idle periods they need in order to cool down, which can be quite annoying if you're bulk sealing.\</p\>
\\![](/images/resource)\</p\>
\<h2\>How It Works\</h2\>
\This method requires:\</p\>
\

\- one \<a href="http://amzn.to/2eTMtG2" target="\_blank" title="Manual Impulse Sealer description" rel="nofollow"\>manual impulse sealer\</a\>\</li\>
\- many \<a href="http://amzn.to/2edqb28" target="\_blank" title="Food Sealer Rolls description"\>food sealer rolls\</a\> for cutting out pouches\</li\>
\

\I choose to buy a 12" (30 cm) food sealer&mdash;\<i\>shown in the picture\</i\>, if you (like me, in retrospective) don't think you'll need to make particularly large portions or objects, an 8" (20 cm) would be more than enough and also easier to put away. The price for an impulse sealer is usually around \$30 shipping included.\</p\>
\The machine is very simple to operate: plug it into the power outlet and set the intensity thanks to the only knob available. Usually the range goes from 1 to 10, we will use 5 for standard poly tubes, while 8 for high quality rolls which usually are thicker. I encourage you to make a few attempts before beginning bulk sealing.\</p\>
\\![](/images/resource)\</p\>
\Food sealing rolls can be found at a discount price on most on-line generic retail sites, I recommend an 8" width for single portions, a size that is usually best for weights between 3 oz. (100 g) and 7 oz. (200 g). Smaller or larger widths may result in pouches with weird proportions that are more difficult to carry and store.\</p\>
\There are many roll lengths available, from 100" (3 m) to very long sizes, usually for industrial sealing. One of the most common lengths for home use is 50" (15 m) and often found in packs of 2.\</p\>
\I recommend starting with a couple of roll packs 8" x 50': this will help us absorb delivery costs&mdash;where provided, evaluate the roll brand and overall have a better understanding of the system and if it works for you.\</p\>
\You can save money by purchasing rolls at industrial length, over 200’ (60 m). Pouches built with this method, as resealing is not practical.\</p\>
\Rolls should also be food-grade guaranteed. If they're intended for vacuum uses, conceded that we're not strictly talking about vacuum here, they are mostly fine. Many films also support extreme high and low temperature, from freezing to microwave and boiling water level heat. I recomend taking an accurate look at product description before buying and using.\</p\>
\\![](/images/resource)\</p\>
\Create the first pouches singularly to practice and to avoid wasting material. Once you acquire more confidence you should be able to create them serially&mdash;as pictured above, this will save you time.\</p\>
\One tip for speeding up cutting: insted of cutting all the way from one side of the roll to the other, make a small incision and drag the open scissors to the other end. Be careful to not cut the seal. The poly tube is quite ductile and won't oppose much resistance.\</p\>
\<h2\>Foods and Other Uses\</h2\>
\Thanks to this approach it becomes very easy to manage food and quantities for a diet. If you like, you can create portions for each macro-nutrient group:\</p\>
\

\- \<em\>chicken breast in curry and ginger variant\</em\> as a protein source\</li\>
\- \<em\>brown rice\</em\> as an energy source with low glycemic index\</li\>
\- \<em\>broccoli, peas and carrots\</em\> for vitamins and mineals\</li\>
\- \<i\>nuts and seeds\</i\>, a healthy superfoods snack\</li\>
\

\\![](/images/resource)\</p\>
\These are just a few examples. I also use this method for preparing shake powders to be used in my post workout, I prepare them for a month, in exact quantities and improving the formula. In this way I reduce the chance to forget to take them and I can carry them with me anywhere anytime.\</p\>
\You can also store leftovers, a succulent meal that you want to taste a second time. Also create ice bags, waterproofing electronical devices and cardboard items, painting items, quilting materials, parts etc...\</p\>
Sun, 02 Oct 2016 19:53:00 GMThttp://andreaazzola.com/meal-prep-pouches-quick-easy

Intermittent Fasting Diet and Benefits

http://andreaazzola.com/intermittent-fasting-diet-benefits/I have always found difficult to lose weight slowly, I'm a hearty eater and sometimes I also see food as a reward at the end of a stressful day. Self-control once bitten the first mouthful comes difficult, but ironically absolute abstention is much easier. Still I'm not obese, thanks to my habit of always practicing some sport; anyway, with the of the "beach-body readiness-test"…\\![](/images/resource)\</p\>
\I have always found difficult to lose weight slowly, I'm a hearty eater and sometimes I also see food as a reward at the end of a stressful day. Self-control once bitten the first mouthful comes difficult, but ironically absolute abstention is much easier. Still I'm not obese, thanks to my habit of always practicing some sport; anyway, with the of the "beach-body readiness-test" pretext, I decided to shread a few extra kilos.\</p\>
\<h2\>The Intermittent Fasting Diet\</h2\>
\So a few weeks ago I chose to adopt the \<em\>intermittent fasting\</em\> diet (IS). I ain't new to this: I eat once a day so between a meal and the other, I wait an average of 23 hours. The purpose of this diet is to concentrate meals in a small window: 8 hours or less (up to on meal a day, but not beyond) every day, in alternate days or only in certain days of the week. The approach means emulate natural cycles of food abundance and shortage: an adult man in nature in fact, would obtain a main meal per day and maybe throw in some snacks, but hardly could prepare the 6 balanced meals that some diets claims indispensible.\</p\>
\The concepts that follows represent my personal experience, before adopting the IS I strongly recommend that you consult a doctor.\</p\>
\<h2\>Benefits\</h2\>
\The main benefit of adopting a small window on meals is that allows for the body and in particular for the digestive system to &quot;heal itself&quot;. The food that we ingest, since chemically altered through physical processes such as cooking, is often a source of micro-infection, not such to be noted but sufficient to contribute to a generalized feeling of heaviness and energy deprivation. Being this a state of habit, first improvements can only be perceived after some effort.\</p\>
\But the main benefit sought from "fasters" is certainly weight loss: the IS is usually accompanied with a calorie restriction more or less drastic depending on oneself psycho-physical condition and objectives. The caloric restriction might require a a few sessions to kick in. It is important to understand that the body consume reserves in the following macro order:\</p\>
\

\- food in the digestive tract\</li\>
\- glycogen reserves in muscles and live\</li\>
\- fat reserves\</li\>
\- muscles, lean mass and tissues\</li\>
\

\In order to achieve a sculpted physique, it would be necessary adopt IS fast and being careful of never reach stage 4, which not only would provoke an undesirable loss of lean mass but also be extremely dangerous to health, since the body would literally start eating itself. These stages are however to be considered an indication, a minimum loss of lean mass is to be expected during stage 3 and 2, still additional proteins and amino acids can be supplemented to compensate for the loss.\</p\>
\Calorie loss during fasting, as during any caloric restriction, is mainly due to the sum basal metabolism (BMR) and physical activities performed. After about a couple of days stage 3 is reached, the liver passes from a diet based on glucose metabolism to the production of ketone bodies, accepted by the brain as a source of alternative nourishment, other tissues are instead able to assimilate fatty acids obtained from the synthesis of the adipose tissue.\</p\>
\<h2\>Day by day\</h2\>
\As for committing to an IS regime, it is necessary to understand the correlation between calorie expenditure, metabolism and weight. My basal metabolism (BMR) is estimated at 3105 kcal/day: this number can be estimated online although I personally preferred to entrust a fitness tracker (such as the \<a href="https://www.amazon.com/gp/product/B07FTN21JL/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=B07FTN21JL&linkId=e0e6d082257aec961ca51179f1b1afeb" target="\_blank" title="Fitbit Charge HR product description" rel="nofollow"\>Fitbit Charge HR\</a\>) that is also capable to take into account the extra activities of the day.\</p\>
\Consider that approximately 1 pound of body fat equals 3500 kcal: a day without introducing any food in a body eg. like mine could mean a weight loss of almost half a pound. Although calorie is still not a well defined measure unit and considering that the energy expenditure is \<em\>estimated\</em\>, it is important to carefully monitor weight, physical form, the energy levels in order to draw some conclusions.\</p\>
\During extended periods of IS (more than a week) the basal metabolism may lower activities: this is the response of the body to the caloric deficit. This mechanism exists naturally to increase efficiency in response to food unavailability. Fortunately the effect can be countered maintaining a high calorie expenditure through the assumption of temorgenic substances such as caffeine and green tea extract containing EGCG (Epigallocatechin Gallate).\</p\>
\The lower BMR constitutes a double-edged sword, in fact, stopping the fasting while the body works in \<em\>power saving\</em\> mode encourages the storage of every calorie introduced in the form of fat, obtaining the dreaded yo-yo effect. The fasting interruption therefore must be gradual and provide both a progressive increase of caloric intake, and an extension of the meal "window" and meal frequency. Luckily, the habit of fasting itself has the effect of promoting the habit of abstention from too much food.\</p\>
\In my daily meal, I strive for introducing only quality food (home-made, genuine and there shall be always vegetables) and reach at least 1000 calories, sometimes by supplementing with vitamin C, Vitamin D3, magnesium and phosphorus, Omega 3; the purpose of this is to replenish vitamins and mineral salts. It is also important to have a good percentage of proteins (at least 30%) to partially remedy to muscle catabolism that naturally occurs, although to a lesser extent, during fasting. It is also appropriate to avoid toxins stagnation and compensate for the hydration which normally would be introduced with food during the IS, so it's necessary to drink a lot.\</p\>
\My long term goal is to reach 10% or less of body fat, for a man typically means a well defined, toned body. For a woman the same result would at 15-20% of body (doesn't mean it would be easier though), while a body builder (male) would focus on 6-7%. I monitor regularly this data some impedance devices: a \<a href="https://www.amazon.com/gp/product/B00BKRQ4E8/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=B00BKRQ4E8&linkId=5259a259080477656a6f2b5a3deb9c05" title="Withing WS 50 product description" target="\_blank" rel="nofollow"\>Withing Smart Body Analyzer scale\</a\>, but also a \<a href="https://www.amazon.com/gp/product/B01DDX0B2W/ref=as_li_tl?ie=UTF8&tag=aazzola00-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=B01DDX0B2W&linkId=1aaad7a43dfff01ee2fa7b6c6e2ea331" rel="nofollow" target="\_blank" title="Skulpt Pulse product description"\>Skulpt Pulse\</a\> for more accuracy. The latter in particular makes it possible to carry out measurements on specific body areas.\</p\>
\<h2\>It's Personal\</h2\>
\There are many fasting variations, some aim to maximize body recovery, hormonal and circadian cycles, while others try not to be invasive and easy to adopt, others require fasting only on alternate or predetermined days (es: 5:2, 5 normal days and 2 of fasting). The formula is customizable to the individual's needs but the basic principle remains: skip the meal. Once learned how to properly fasting, it can be customized.\</p\>
\To obtain drastic results in less time I've chosen prolonged periods of abstention from food, very low caloric intakeand at a daily physical activity, but I still have two meals in special occasions. This allowed me to lose about 8kg in one month. When the "cutting" phase will be concluded, I'll switch to a 5:2 formula for the sake of maintenance.\</p\>Tue, 06 Sep 2016 06:20:00 GMThttp://andreaazzola.com/intermittent-fasting-diet-benefits

A Lever Called Geo-Arbitrage

http://andreaazzola.com/what-is-geo-arbitrage/Geo-Arbitrage
The geo-arbitrage (geographic arbitration) is the practice of economic-financial speculation based on disparity between geographic locations and different markets. The term was devised by the author Tim Ferris in the bestseller book The 4-Hour Workweek. In the following two paragraphs I'll analyze ways in which an individual could benefit from geo-arbitrage.
Digital…\\![](/images/resource)\</p\>
\<h2\>Geo-Arbitrage\</h2\>
\The geo-arbitrage (geographic arbitration) is the practice of economic-financial speculation based on disparity between geographic locations and different markets. The term was devised by the author Tim Ferris in the bestseller book \<a href="https://www.amazon.com/gp/product/0307465357/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=aazzola00-20&creative=9325&linkCode=as2&creativeASIN=0307465357&linkId=b2415b234e27b70a4d047b1a8d5a63ae" title="The 4-Hour Workweek: Escape 9-5, Live Anywhere, and Join the New Rich on Amazon" target="\_blank" rel="nofollow"\>The 4-Hour Workweek\</a\>. In the following two paragraphs I'll analyze ways in which an individual could benefit from geo-arbitrage.\</p\>
\<h2\>Digital Nomadism\</h2\>
\The number of job offerings with a decent salary and the option of telework is increasing. The \<em\>digital nomadism exploits this combination\</em\> by moving to countries with a low cost of living and therefore maximize purchasing power.\</p\>
\Let's say a Swiss software programmer that earns 60000 EUR/year moves to Bulgaria. In Bulgaria, with the cost of living at a third of the Switzerland (\<a href="http://www.numbeo.com/cost-of-living/rankings_by_country.jsp" title="Cost of Living Index for Country 2016 Mid Year" target="\_blank"\>source\</a\>), the same employee would gain with a purchasing power exceeding 180,000 EUR.\</p\>
\<h2\>Outsourcing\</h2\>
\When hear the word "outsourcing", we often think of a western megacompany, that contracts manufacturing and services to emerging countries, obtaining advantageous prices thanks to the lower cost of living and lower labor costs.\</p\>
\But outsourcing can be a precious resource also for freelances or private people: e.g. the same software developer could rely on a language translator to export its own App abroad; or a couple of professionals in career could hire a party planner for the son's birthday.\</p\>
\In general, you delegate activities deemed "secondary" to focus better on what for you is more productive.\</p\>Mon, 20 Jun 2016 18:18:00 GMThttp://andreaazzola.com/what-is-geo-arbitrage

The Goalodicy Trap

http://andreaazzola.com/goal-blindness-goalodicy/The Goalodicy
The goalodicy is the obsession in pursuing a goal, a compulsion such that the individual often ignores its own context. The term, coined by D. Christopher Kayes of the University of Washington, is a merge of the English words goal and theodicy, which etymology suggests a similarity to "divine justice" in Greek. Another common term for goalicity is goal-blindness
The…\\![](/images/resource)\</p\>
\<h2\>The Goalodicy\</h2\>
\The \<em\>goalodicy\</em\> is the obsession in pursuing a goal, a compulsion such that the individual often ignores its own context. The term, coined by \<a href="http://business.gwu.edu/profiles/d-christopher-kayes/" target="\_blank" title="Academic profile of D. Christopher Kayes"\>D. Christopher Kayes\</a\> of the University of Washington, is a merge of the English words \<em\>goal\</em\> and \<em\>theodicy\</em\>, which etymology suggests a similarity to "divine justice" in Greek. Another common term for goalicity is \<em\>goal-blindness\</em\>\</p\>
\<h2\>The Everest Disaster\</h2\>
\In May 1996, 34 climbers departed to the conquest of Mount Everest, the planet highest summit. The team was preparing at field IV, 7900 meters of altitude, the last checkpoint before the final goal at 8848 meters.\</p\>
\But the latest vertical meters are the most difficult&mdash;nicknamed "death zone", where severe weather conditions can strike suddenly, that climbers face with a limited number of oxygen tanks. A mishap can make the difference between life and death, coordination and teamwork are therefore essential.\</p\>
\On day 26, the New Zealand and the American teams departed for the last ascent. The Taiwanese team also departs, without appropriate notice, maybe due to a misunderstanding or a last-minute quarrel. A bottleneck forms at the Hillary Step, a leap of rock of about 10 meters, causing a two hours delay to the teams, such that the point of no return for the oxygen passes.\</p\>
\The climbers successfully reach the top. At come back time, they're caught by a sudden storm. Weakened muscles and adverse weather conditions make it for an impossible descent, as well as for any rescue operation. \<em\>Eight people died that day\</em\>.\</p\>
\The whole story is narrated in great detail in \<a href="https://www.amazon.com/gp/product/0385494785/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=aazzola00-20&creative=9325&linkCode=as2&creativeASIN=0385494785&linkId=2f0e38ab2eff38bfc2ac4a378be6f2cc" target="\_blank" title="Into Thin Air book description" rel="nofollow"\>Jon Krakauer's assay "Into Thin Air"\</a\>, the author took part in the expedition. The book was also made into a movie, \<a href="http://amzn.to/2eTQJoV" target="\_blank" title="Everest movie description" rel="nofollow"\>Everest (2015)\</a\>, which I recommend.\</p\>
\<h2\>The Lesson\</h2\>
\According to the D. Kayes analysis, passion in pursuing an objective can become an obsession and lead to disaster, a real \<em\>destructive goal\</em\> as the doctor puts it in the omonimous book. While passion is therefore characterized by awareness of context and focused on the pleasure of doing, the obsession is blind.\</p\>
\This condition can be favored by many factors:\</p\>
\

\- \<strong\>Limiting goals\</strong\>: climb the Everest without focus on a safe comeback;\</li\>
\- \<strong\>Social expectations\</strong\>: the group pressure;\</li\>
\- \<strong\>Idealization\</strong\>: romantic notion and the seeking for identity in success;\</li\>
\- \<strong\>Stress\</strong\>: impairment of rational thought in favor to emotion;\</li\>
\- \<strong\>Leadership\</strong\>: unconditional acceptance of other people choices.\</li\>
\

\<h2\>Life &amp; Work\</h2\>
\In recent years we have witnessed a growth in the practice of \<em\>goal setting\</em\>, a science that was born to support the planning and the achievement of goals. Goal setting could be seen as a project management reinterpretation but oriented to the individual.\</p\>
\In goal setting studies the psychological component is often placed in second place, as a result goals set by individuals can be badly designed and misaligned with a bigger goal for life quality improvement. This can lead to loss of motivation or, on the opposite side to a blind compulsion to reach a dangerous goal, as the Everest teaches us.\</p\>
\It become fundamental to introduce and repeat introspection for situational awareness in ragards to the outcome, accept uncertainty in which the ability to respond, hides the true enrichment.\</p\>
\<h2\>Conclusion\</h2\>
\Before establishing a goal, a preliminary torough examination is required, as a first repair from ill-conceived and potentially harmful goals. The \<a href="https://en.wikipedia.org/wiki/SMART_criteria" target="\_blank" title="Definition of S.M.A.R.T. on Wikipedia"\>SMART criteria\</a\> comes in aid. Goals that does not meet these criteria should be discarded or at least weighted. SMART stands for:\</p\>
\

\- \<strong\>Specific\</strong\>: focused on a specific aspect\</li\>
\- \<strong\>Measurable\</strong\>: quantifiable, both in terms of execution and progress\</li\>
\- \<strong\>Assignable\</strong\>: who would do it\</li\>
\- \<strong\>Realistic\</strong\>: realistic given the available resources\</li\>
\- \<strong\>Time-related\</strong\>: temporally bounded both terms of milestones and deadlines\</li\>
\

\Leverage fantasy, creativity and awareness. Constantly scan for priorities. Remeber to be individualist, essentialist and rational to establish true, useful and consisteng goals.\</p\>
\But especially be aware and self-examine in regard to the risk of goalodicy.\</p\>Sat, 14 May 2016 09:16:00 GMThttp://andreaazzola.com/goal-blindness-goalodicy

Waking Up Early And Getting Things Done

http://andreaazzola.com/waking-up-early-get-things-done/The simple wake up early can be a very simple and effective productivity technique. In fact, it is one of the best approaches in my arsenal, explanation follows.
Draw from Willpower
It's 8 am, some would say not exactly early, but it is saturday and for me this is the proverbial "stay in bed"… Normally I would wake up at 6 am, despite my job doesn't require my presence before 9 am. At this…\\![](/images/resource)\</p\>
\The simple wake up early can be a very simple and effective productivity technique. In fact, it is one of the best approaches in my arsenal, explanation follows.\</p\>
\<h2\>Draw from Willpower\</h2\>
\It's 8 am, some would say not exactly early, but it is saturday and for me this is the proverbial "stay in bed"… Normally I would wake up at 6 am, despite my job doesn't require my presence before 9 am. At this hour I can deal with something for which normally, in the evening I would not have the mental energy for, like writing this post.\</p\>
\The most beneficial aspect of the early rise is circumventing the \<em\>decision fatigue\</em\> mechanism; many studies show that \<strong\>we have a finite quantity of willpower\</strong\> each day, willpower that we are able to replenish thanks to sleep. It is at the highest on awakening and consumed throughout the day.\</p\>
\By fully exploiting the morning we can \<em\>employ our willpower toward our goals\</em\>, things that really matters to us and, frankly, mostly never gets done. Energies gests deducted from the end of the day where it is anyway biologically better to stop activities in preparation for sleep.\</p\>
\<h2\>Treasure the Morning\</h2\>
\The morning can be endearing: the clear sky, the clouds with tints of dawn's nuances, life that slowly awakens. Morning is quiet and energy.\</p\>
\
Some things I really appreciate of my mornings:
\

\- devote energies to care of the \<strong\>necessary\</strong\>\</li\>
\- don't fall prey of distractions\</li\>
\- the gym is undercrowded\</li\>
\- find small moments for meditation \</li\>
\- save from 10 to 20 minutes of car commute in traffic\</li\>
\- treat myself with a "state of the art" cappuccino at the café\</li\>
\

\</p\>
\<h2\>Build the Habit\</h2\>
\I know the task can be daunting, and if not sufficiently fueled with motivation, there are a big chances for giving up soon. Below some suggestions that might help in smoothing the transation.\</p\>
\<h3\>Exploit the evening\</h3\>
\It's chance in order to prepare for a top morning: prepare bags, suitcases, dedicate to personal hygiene, take a brief moment to recap next day commitments. The morning is meant to be dedicated to produce value, not to be spent on maintenance!\</p\>
\<h3\>Set an alarm for bedtime\</h3\>
\It is key to enjoy all necessary hours of sleep&mdash;6-9 depending according to preference&mdash;therefore becomes vital not postpone bedtime. Set an alarm to remind you of sleep time. My fitness tracker vibrates&mdash;a Fitbit HR&mdash; each evening at 10 pm.\</p\>
\<h3\>Be patient\</h3\>
\It wouldn't be fair to to expect ourselves to succeed immediately, in an habit that can seem very unpleasant at first&mdash;but becomes less discouraging with experience, in fact building habits requires time, months. It's important to patient, not take it personally. It's the circadian rhytms, our comfort zones that will resist the adjustment.\</p\>
\<h2\>Final Toughts\</h2\>
\If on one hand waking up early may require sacrifices, social interaction, evening outs, TV shows... On the other hand it can lead us to an active part on your life, who wouldn't like that? I personally like to think of it as a long term investment.\</p\>Sat, 26 Mar 2016 19:31:00 GMThttp://andreaazzola.com/waking-up-early-get-things-done

The Path to Financial Independence

http://andreaazzola.com/path-to-financial-independence/The term financial independence indicates a state o finances for which the individual can fulfill primary needs without participating in an employment. It is usually achieved when the difference between recurring revenue&mdash;corporate divends, product sales, real estate rentals etc…&mdash;and living expenses satisfies the basic quota for personal sustenance.
The path to financial independence…\\![](/images/resource)\</p\>
\The term \<em\>financial independence\</em\> indicates a state o finances for which the individual can fulfill primary needs without participating in an employment. It is usually achieved when the difference between \<em\>recurring revenue\</em\>&mdash;corporate divends, product sales, real estate rentals etc…&mdash;and \<em\>living expenses\</em\> satisfies the basic quota for personal sustenance.\</p\>
\The path to \<em\>financial independence\</em\> is usually undertaken by people with a strong desire for freedom, or people with big amounts of money available and looking for a smart ways to manage them. This goal is however rarely achieved by luck&mdash;like a lottery win, rather by a strong and developed management of personal finances, and with a pinch of entrepreneurial skills.\</p\>
\<h2\>Expense Reduction\</h2\>
\The expense reduction aspect is mainly oriented to the containment of the ongoing expenditure necessary for living. It is possibile to become more "cost conscious", by weighing simple daily choices at first, up to developing a more strategic and sophisticated awareness of "value".\</p\>
\Some individuals are capable to bring their own frugality to the extremes&mdash;\<em\>extreme saving\</em\>, by therefore saving plus then 75-80% of their salary. The possibilities are numerous, for example, one smart move may be relocate to a country with a lower cost of living&mdash;approach known as \<em\>geo-arbitrage\</em\>.\</p\>
\It is important to stress that being frugal does not necessarily imply a waiver on quality of life. Frugality is in fact often the cause to a much deeper improvement change, as it can contribute to detachment from consumerism and development of "make do" skills.
On the social side, frugality offers ample opportunities for self-gratification, restoring the very basic reasons for being part of a community (collaboration intended for sustanance) and encourages social spending&mdash;money spent for friends and family&mdash; that in the long run can be much more rewarding than physical goods.\</p\>
\<h2\>Passive Income\</h2\>
\\<em\>Passive income\</em\> is the gain of an economic value that doesn't requires active actions such as the provision of a service or the sale of some asset.\</p\>
\Passive income can obtained for example in two ways: the first one involes a capital to invest configured to guarantee a return of interests sufficient by itself to self-sustainment, through market instruments and long-term investments.
In the second scenario, the \<em\>early-retiree\</em\> uses hers/his skills to create new sources of passive income, such as: products to be sold, affiliate marketing, rental from real estates etc&hellip;\</p\>
\Of course both roads are possible. It is essential to stress managing a passive income activity usually demands a minimum amount of activities, like supervision.
Even a static deposit under the mattress, can be subject to devaluation.\</p\>
\<h2\>Conclusion\</h2\>
\I became aware of the financial freedom community in 2014, at the age of 29, while browsing in long and large among links and podcasts for futher personal development.
Thanks to the community, I understood that self-discipline and teachings are precious even without reaching the goal,
as they help to improve personal financial awareness and can radically eradicate wrong consumption habits.\</p\>Sun, 20 Mar 2016 15:45:00 GMThttp://andreaazzola.com/path-to-financial-independence

Get Up And Code Podcast Review

http://andreaazzola.com/getupandcode-podcast-review/I remember one time that I was under a pretty heavy barbell doing chest presses. I was listening to the podcast and the host made a very good joke, I lost my temper, I almost dropped the weight on myself and bursted out laughing in the middle of a otherwise very silent but also very populated gym. Luckily, I kept a bit of self control and saved possibly a few ribs. So be advised, and listen…\\<em\>I remember one time that I was under a pretty heavy barbell doing chest presses. I was listening to the podcast and the host made a very good joke, I lost my temper, I almost dropped the weight on myself and bursted out laughing in the middle of a otherwise very silent but also very populated gym. Luckily, I kept a bit of self control and saved possibly a few ribs. So be advised, and \<strong\>listen responsibly ;)\</strong\>.\</em\>\</p\>
\\![](/images/resource)\
\The discovery happened because I wanted to employ my daily commute to work to deepen my fitness knowledge amongst other things, confrontation is something that does not finds much space at the gym, people get there to workout and not much to talk. Scrolling through the \<em\>iTunes podcast directory\</em\>, health section, I found the \<strong\>Get Up and Code\</strong\> podcast and got intrigued. The description stated \<em\>fitness for developers\</em\> so I checked it out, hoping for a nicely tailored approach that might help me leverage some technical skills.\</p\>
\And I found that John (and Iris) teachings, were just what I needed:\</p\>
\

\- \<em\>No medical jargon\</em\> that I wouldn't have understood\</li\>
\- \<em\>Valuable tips\</em\> from \<em\>grounded people\</em\> with proven track record\</li\>
\- Talks between \<em\>friendly people\</em\> I could identify with\</li\>
\

\<h2\>The Show\</h2\>
\The show focuses on \<strong\>fitness\</strong\> and \<strong\>nutrition\</strong\>. \<em\>Life hacks\</em\>, \<em\>wereables\</em\> are also part of the conversation. Being a developer&mdash;I would dare to say&mdash;is not a strict requirement, some might miss a few jokes or have a blurry understanding of few episodes at most.\</p\>
\The main host is \<strong\>John Somnez\</strong\>, an \<a href="http://entreprogrammers.com/" title="The Entreprogrammers Podcast" target="\_blank"\>enterpreneur, \<a href="http://www.pluralsight.com/author/john-sonmez" title="John Somnez on Pluralsight"\>Pluralsight author\</a\>, \<a href="http://simpleprogrammer.com" title="Simple Programmer" target="\_blank"\>developer\</a\>, personal development coach, real estate investor and father. He also manages to produce Get Up And Code. \<strong\>\<a href="http://irisclasson.com/" title="Iris Classon's blog" target="\_blank"\>Iris Classon\</a\>\</strong\>, another expert developer (and nutritionist) co-hosted a significative percentage of the early episodes.\</p\>
\The show started in May 2013, since then John had managed to pull out episodes with a good consistency&mdash;74 at \<em\>17 Jan 2015\</em\>. Episodes lasts about 50 minutes average, there might be Somnez speaking solo, or they might involve a guest. Guests are usually athletes, coders, nutrion experts, niche experts, ranging from enthusiast to professional level. Few episodes also involves listeners as coaching subjects.\</p\>
\<h2\>Benefits of a Healthy Lifestyle\</h2\>
\There are things going on in a person's body, at any given time: cell repair, hormonal response, immune reactions, termoregulation etc. The effectinevess of these functions is credited, by science, in small part to our genetic inheritance and in greater part to our state of health. Those processes are invisible, but have a huge impact on day-to-day life, I can personally vouch for a few:\</p\>
\

\- Wake up early in the morning without feeling groggy\</li\>
\- Costant energy flow throughout the day\</li\>
\- Improved cardiovascular system\</li\>
\- Improvements of posture, diminishing aches\</li\>
\- Faster recovery from injuries and diseases\</li\>
\

\Being healthy means being overall a better version of yourself, people often don't realize how much fitness and nutrition have impact on life. The body is a complex system, and should be handled in such regard, \<em\>Get Up and Code has demonstrate to be a very good medium in learning \<strong\>how\</strong\>\</em\>.\</p\>
\<h2\>Health is a Habit, not a Goal\</h2\>
\One of the reason why I appreciate podcasts, is because they have a schedule, and due to how our brain works&mdash;I warmly suggest the \<a href="https://www.goodreads.com/book/show/11468377-thinking-fast-and-slow" title="Thinking, Fast and Slow by Daniel Kahneman" target="\_blank"\>Thinking Fast and Slow by Daniel Kahneman\</a\> book for more insights&mdash;they may act as motivational nudge and habit builder.\
\If this is your first attempt toward a healthier lifestyle, I suggest, subscribe and help yourself making it an habit. Short burst of dedication, won't do any good and might also backfire&mdash;read: discouragement, pain. Start small and build from there, remember \<q\>divide et impera\</q\>!\</p\>
\<h2\>How to Subscribe\</h2\>
\

\- iTunes \<a href="https://itunes.apple.com/us/podcast/get-up-and-code!/id646958161" target="\_blank" title="Get Up and Code on iTunes"\>https://itunes.apple.com/us/podcast/get-up-and-code!/id646958161\</a\>\</li\>
\
Sat, 17 Jan 2015 08:22:00 GMThttp://andreaazzola.com/getupandcode-podcast-review

The Luck Surface Area Principle

http://andreaazzola.com/luck-surface-area/Luck Surface Area principle, credited to Jason Roberts, states that increments of luck in a certain field of interest, can be achieved by doing and telling about it.
The Formula
The recipe may not sound new to many&mdash;the concept is ABC for influence and advertising&mdash;but what I found interesting, is its simplicity, that makes it easy to rememeber and explain, and its applicability…\\<strong\>Luck Surface Area\</strong\> principle, credited to Jason Roberts, states that increments of \<strong\>luck\</strong\> in a certain field of interest, can be achieved by \<strong\>doing\</strong\> and \<strong\>telling\</strong\> about it.\</p\>
\\![](/images/resource)\</p\>
\<h2\>The Formula\</h2\>
\The recipe may not sound new to many&mdash;the concept is ABC for \<em\>influence\</em\> and \<em\>advertising\</em\>&mdash;but what I found interesting, is its simplicity, that makes it easy to rememeber and explain, and its applicability to \<a href="/post/personal-branding-introduction" title="Personal Branding, a Brief Introduction" target="\_new"\>personal branding\</a\>.\</p\>
\
> L = D \* T\</blockquote\>
\<h3\>Doing\</h3\>
\Doing not only gets stuff done, but builds \<em\>credibility\</em\>. It also favors skills development and stamina. Achievements obtained by doing, help sustain high levels of motivation.\</p\>
\<h3\>Telling\</h3\>
\Telling clearly expose our interests to advice, praise, criticism. Not everyone needs to buy in, but in my belief genuine interest over gratuitous endorsment has some clear \<em\>emotional\</em\> advantages. You likely won't blame a person for being enthusiast, she will remain consistent and therefore attract other like-minded people. Enthusiasm is one of the most powerful way to win people attention.\</p\>
\Expect a \<em\>return in opportunities\</em\>. Someone may be interested in your work, you migh get in touch with other's work, new edges may arise, on which to work on. The business benefits either way.\</p\>
\Roberts in this regard uses a wise adjective for telling: \<em\>effectively\</em\>. There are many aspects to take into account for communicating effectively, explaining them would require an entire book. For instance, you don't want to focus on the wrong target, you might loose them at all.\</p\>
\<h2\>Connecting the dots\</h2\>
\The nice thing about personal development principles, is that you can mash them up and make assumptions.\</p\>
\You might be familiar with the \<a href="http://en.wikipedia.org/wiki/1%25_rule\_(Internet_culture)" target="\_blank" title="1% rule (Internet culture)"\>1% rule\</a\>. It states that only 1% of people on the Internet are \<em\>creators\</em\>, 9% are \<em\>contributors\</em\> and the rest are \<em\>lurkers\</em\>. This applied to the \<em\>Luck Surface Area\</em\> principle, are themselves enough to explain the importance that bloggers, youtubers and influencers, had in the latest years.\</p\>Fri, 26 Dec 2014 10:19:00 GMThttp://andreaazzola.com/luck-surface-area

How to run ASP.NET vNext on Mac OS with Kulture and OmniSharp

http://andreaazzola.com/aspnet-vnext-mac-os-omnisharp-kulture/The article will describe how to run ASP.NET vNext on Mac OS X. The process, requires multiple configurations and therefore some patience. Luckily, OS X already includes one of the pre-requirements, Ruby, 2.0 on Mavericks and Yosemite, 1.8.7 on Mountain Lion, Lion, and Snow Leopard.
Sublime Text
One very popular IDE or advanced text editor for Mac OS X is Sublime Text. I use it on both OS X…\The article will describe \<strong\>how to run ASP.NET vNext\</strong\> on \<strong\>Mac OS X\</strong\>. The process, requires multiple configurations and therefore some patience. Luckily, OS X already includes one of the pre-requirements, \<strong\>Ruby\</strong\>, 2.0 on Mavericks and Yosemite, 1.8.7 on Mountain Lion, Lion, and Snow Leopard.\</p\>
\<h2\>Sublime Text\</h2\>
\One very popular IDE or \<em\>advanced text editor\</em\> for Mac OS X is \<strong\>\<a href="http://www.sublimetext.com/" title="Sublime Text official website" target="\_blank"\>Sublime Text\</a\>\</strong\>. I use it on both OS X and Windows, for developing \<a href="http://andreaazzola.com/category/salesforcecom" target="\_blank" title="Salesforce.com posts"\>Salesforce.com\</a\> applications, to take notes or authoring this very article in pure HTML, and I'm very happy with it\<!-- &mdash;\<q cite="http://tolkiengateway.net/wiki/Free_peoples"\>One Ring to rule them all, One Ring to find them,
One Ring to bring them all, and in the darkness bind them\</q\> --\>. Other supported IDEs&mdash;at the moment of writing&mdash;are:
\

\- Atom - \<a href="https://atom.io/" title="Atom editor" target="\_blank"\>https://atom.io/\</a\>\</li\>
\- Emacs - \<a href="http://www.gnu.org/software/emacs/" title="Emacs editor" target="\_blank"\>http://www.gnu.org/software/emacs/\</a\>\</li\>
\- Brackets - \<a href="http://brackets.io/" title="Brackets editor" target="\_blank"\>http://brackets.io/\</a\>\</li\>
\- Vim - \<a href="http://www.vim.org/" title="Vim editor" target="http://www.vim.org/"\>http://www.vim.org/\</a\>\</li\>
\

\</p\>
\<h2\>Homebrew\</h2\>
\\<a href="http://brew.sh/" target="\_blank" \>Homebrew\</a\> is an open source package manager for Mac OS X, it leverages mostly on \<em\>git\</em\> and \<em\>ruby\</em\>. If you're not sure to have it installed, just open the \<em\>Terminal\</em\> and issue the command \<code\>brew doctor\</code\>. If the response is \<code\>command not found\</code\> well, it's not installed, so run the following command:\<code\>ruby -e "\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"\</code\>\</p\>
\<h2\>KVM, Mono and KRE\</h2\>
\The \<strong\>K Version Manager\</strong\>&mdash;KVM&mdash;is a tool for installing different versions of the \<strong\>ASP.NET vNext runtime\</strong\> and switch between them. To install the KVM and Mono, run the command \<code\>brew tap aspnet/k\</code\>, this will only \<em\>tap\</em\>&mdash;reference&mdash;ASP.NET vNext repos, therefore launch \<code\>brew install kvm\</code\> to install the KVM package. This, will also install the latest K Runtime Environment&mdash;KRE.\</p\>
\<h2\>OmniSharp and Kulture\</h2\>
\A prerequisite for this step is the \<a href="https://sublime.wbond.net/installation" target="\_blank" title="Package Control install"\>setup of Package Control\</a\>, please refer to the link for more details. Then, proceed to install the two following packages:\</p\>
\\<strong\>Kulture\</strong\>, is a Sublime Text package for ASP.NET vNext that brings the build system into the Sublime. To install it, press \<code\>CTRL+SHIFT+P\</code\>, then type \<code\>Install Package\</code\>, then \<code\>Kulture\</code\>, select it and press \<code\>Return\</code\>:\</p\>
\\![](/images/posts/aspnet_sublime_pkgmng_kulture.png)\</p\>
\\<strong\>OmniSharp\</strong\> is a platform for enabling \<em\>C# cross-platform .NET development\</em\> for the IDE of your choice. In other words, \<em\>OmniSharp\</em\> plugs all the plumbing needed by the \<q\>Mac OS X based\</q\> IDE to behave like a proper .NET IDE. It supports both \<em\>Mac OS X\</em\>, \<em\>Linux\</em\> and \<em\>Windows\</em\>, and brings very useful features like \<em\>Auto Completion\</em\>, \<em\>Syntax/Semantic error highlighting\</em\>, \<em\>Build/ReBuild/Clean solution\</em\>, etc..\</p\>
\To install, follow the same procedure but type \<code\>OmniSharp\</code\> for the package name this time:\</p\>
\\![](/images/posts/aspnet_sublime_pkgmng_omnisharp.png)\</p\>
\<h2\>Hello World\</h2\>
\Let's check out the new setup:
\

\- Clone the \<a href="https://github.com/aspnet/Home" target="\_blank" title="ASP.NET vNext Home repository"\>Home\</a\> repository: \<code\>git clone https://github.com/aspnet/Home\</code\>\</li\>
\- Browse the \<code\>/samples/HelloWeb/\</code\> folder\</li\>
\- Run \<code\>kpm restore\</code\> to restore dependencies, this may take a while\</li\>
\- Run \<code\>k kestrel\</code\>, aka the Mono \<em\>web server\</em\>\</li\>
\- Navigate you app at \<code\>http://localhost:5004\</code\>\</li\>
\

And that should be it!
\</p\>
\\![](/images/posts/aspnet_sublime_helloweb.png)\</p\>
\<h2\>References\</h2\>
\

\- \<a href="http://www.omnisharp.net/" target="\_blank" title="OmniSharp official website"\>OmniSharp\</a\> official page\</li\>
\- \<a href="https://github.com/aspnet/home#getting-started" target="\_blank" title="ASP.NET vNext quickstart"\>Getting Started\</a\> on ASP.NET GitHub page\</li\>
\
Sat, 20 Dec 2014 07:15:00 GMThttp://andreaazzola.com/aspnet-vnext-mac-os-omnisharp-kulture

ErgoDox split Ergonomic Keyboard Review

http://andreaazzola.com/ergodox-ergonomic-keyboard-review/The ErgoDox is a DIY ergonomic keyboard, featuring a split design&mdash;each half, one hand. The two halves are connected with a phone TRRS connector cable, while the connection to the PC&mdash;or Mac or Unix&mdash;is obtained trough a detachable mini USB.
History
The project has been initiated by Dominic Beauchamp&mdash;aka Dox, from which the keyboard name derives&mdash;on the…\\![](/images/ergodox_side.jpg)\</p\>
\The \<strong\>ErgoDox\</strong\> is a DIY ergonomic keyboard, featuring a \<em\>split design\</em\>&mdash;each half, one hand. The two halves are connected with a \<em\>phone TRRS connector cable\</em\>, while the connection to the PC&mdash;or Mac or Unix&mdash;is obtained trough a detachable mini USB.\</p\>
\<h2\>History\</h2\>
\The project \<a href="https://geekhack.org/index.php?topic=22780.0" target="\_blank" title="GeekHack.org forum"\>has been initiated\</a\> by Dominic Beauchamp&mdash;aka Dox, from which the keyboard name derives&mdash;on the GeekHack.org forum; the design has been largerly inspired by the \<a href="http://www.key64.org/" target="\_blank" title="Key64 keyboard"\>Key64\</a\> project by Nestor Diaz.\</p\>
\The ErgoDox keyboard is licensed with GNU GPL v3, everybody can make their own modifications, with the only constraint that the original name \<em\>ErgoDox\</em\> is protected.\</p\>
\\![](/images/ergodox_front.jpg)\</p\>
\<h2\>The keyboard\</h2\>
\The keyboard itself accomodates approximately 76 keys. The size of keycaps may vary according to function and position. Keycaps can be repositioned according to preference and keys itself&mdash;thanks to a \<a href="https://www.pjrc.com/store/teensy.html" target="\_blank" ="Teensy 2.0 page"\>Teensy 2.0 AVR Microcontroller\</a\>&mdash;can be remapped to accomplish different layouts&mdash;QWERTY, Dvorak, Colemak, etc...&mdash;and/or personal preferences.\</p\>
\The typical ErgoDox sports \<strong\>Cherry MX\</strong\> switches. It can, of course, mount any type of commercial Cherry MX. \<strong\>ALP\</strong\> switches are another option. As for keys, the most popular are \<a href="http://keyshop.pimpmykeyboard.com/products/full-keysets/dsa-blank-sets-1" target="\_blank" title="DSA PTB blanks page"\>Signature Plastics PBT DSA keycaps\</a\>, which are characterized by their rounded shape, a low profile, nice textured surface and no legend&mdash;commonly referred to as \<em\>ninja\</em\> or \<em\>stealth\</em\>.\</p\>
\There are three casings for sale that I personally know about:
\

\- The \<a href="http://ergodox.org/Downloads.aspx" title="ErgoDox case by Dox" target="\_blank"\>original case designed by Dox\</a\>, it is the most refined version but also the less popular due to the 3D printing costs.\</li\>
\- The \<em\>acrylic case by lilster\</em\>, is the one you see in the pictures, it is made by sheets of acrylic stacked together, and it is completly trasparent. On mine there's a top aluminum plate, but just for a more minimalistic/rugged look.\</li\>
\- The \<em\>PVC case by Falbatech\</em\>, available both in \<a href="http://falbatech.pl/prestashop/index.php?id_product=9&controller=product" target="\_blank" title="ErgoDox PVC white case by Falbatech"\>white\</a\> and \<a href="http://falbatech.pl/prestashop/index.php?id_product=23&controller=product" title="ErgoDox PVC black case by Falbatech" target="\_blank"\>black\</a\>, probably one of the best compromises in terms of better look/price ratio right now.
\
\</p\>
\<h2\>Feel\</h2\>
\The fingers, can \<em\>spread horizontally\</em\> and stay relaxed, benefiting from a more open and natural course of movement, each key is within reach. Partly of that is thanks to the fact that keycaps are distributed in \<strong\>columns\</strong\> instead of rows. Thumbs, \<em\>have their own set of keys\</em\>, and being the thumbs, the most powerful and usually neglected fingers, this is big deal&mdash;normally you would use just one and just for hitting the spacebar. Wrists, won't move much like they would on a normal one&mdash;except for a few key combos&mdash;resulting in dimished/absent wrist pain over prolonged periods of use.\</p\>
\I would definitely reccomend it to a 9-to-5 computer user, it may take some effort to adapt, but it pays back with interests. Expecially if you're a typist, writing a book or articles, the ErgoDox feels like the fountain pen of keyboards. \<em\>Software developers\</em\> and \<em\>gamers\</em\> might find it a little bit limitating, because of the missing function keys which many IDE and games take advantage of, and although keys can be remapped, I do see some difficulties with more intricate patterns. It can even backfire as a collaboration deterrent&mdash;I advise to keep a normal keyboard always connected to the workstation, as a courtesy to colleagues\</p\>
\\![](/images/ergodox_aerial.jpg)\</p\>
\<h2\>How to buy\</h2\>
\The \<em\>ErgoDox\</em\> can't be purchased from any official store or retailer, it must be built, unless someone is willing to sell his own, which is pretty rare. Luckily, there are few people that offer assembly as a service.\</p\>
\Electronic parts, can be bought trough \<a href="https://www.massdrop.com/r/KEP8XC" title="Massdrop website" target="\_blank"\>Massdrop\</a\>. Massdrop is a company focused on \<em\>group buys\</em\>, users can commit to buy a certain item, and if enough committers are reached, the group buy&mdash;aka \<em\>drop\</em\>&mdash;gets submitted to the supplier. Multiple suppliers may be involved, but worry not! Massdrop will take care of all the logistics, charge you one single payment and ship the whole package.\</p\>
\It should be noted that \<em\>drops\</em\>, because of their crowdsourced nature, are not always open, instead, they're based on the sum of \<em\>user requests\</em\> for the item. Typically&mdash;at the time of writing&mdash;new drops for ErgoDoxes are opened \<em\>every few months\</em\>.\</p\>
\But shipping costs and import taxes from U.S. might spike the deal, a more budget friendly alternative for \<strong\>europeans\</strong\> would be \<a href="http://falbatech.pl" target="\_blank" title="Falbatech website"\>Falbatech\</a\>, a Polish company started by two brothers, it sells pretty much all the parts plus, optional assembly.\</p\>
\<h2\>Ergodox assembly\</h2\>
\\![](/images/ergodox_connectivity.jpg)\</p\>
\Parts:
\

\- 1x Teensy 2.0 AVR Microcontroller\</li\>
\- 2 Cases (PVC/Layered acrylic/3D) and screws\</li\>
\- 2 PCB\</li\>
\- 76-80 x Cherry MX switch\</li\>
\- 76-80 x 1N4148W-7-F diode (in-hole/smd)\</li\>
\- 1 x MCP23018 I/O expander\</li\>
\- 2 x 3.5mm TRRS connectors\</li\>
\- 1 x TRRS cable\</li\>
\- 1 x USB mini B plug\</li\>
\- 1 x 0.1uF ceramic capacitor\</li\>
\- 1 x 2.2k ohm resistor\</li\>
\- 3 x 3mm T1 LED\</li\>
\- 2 x 220 ohm resistor\</li\>
\- 2 x USB cable Male A to male mini B\</li\>
\

\</p\>
\First thing to consider is \<strong\>soldering\</strong\>, if you're new to this, \<a href="https://www.youtube.com/results?search_query=smd+soldering+tutorial" target="\_blank" title="Soldering tutorials on YouTube"\>I would reccomend to start on YouTube\</a\>, then you'll need at minimum:
\

\- \<strong\>SMD solder iron\</strong\>&mdash;fine tip, scalpel even better\</li\>
\- \<strong\>Solder wire\</strong\>\</li\>
\- \<strong\>Solder wick\</strong\> for cleaning excees of solder or for reworks\</li\>
\

\</p\>
\The following two resources describe all the process in detail. \<strong\>WhiteFireLion's video\</strong\> in particular, is very comprehensive:\</p\>
\<iframe class="video-container" width="700" height="393" src="//www.youtube.com/embed/x1irVrAl3Ts" frameborder="0" allowfullscreen\>\</iframe\>
\Another great resource is the \<strong\>\<a href="https://www.massdrop.com/ext/ergodox/assembly" target="\_blank" title="Massdrop Assembly Instructions"\>Massdrop Assembly Instructions\</a\>\</strong\> page\</p\>
\<h2\>References\</h2\>
\

\- \<a href="https://www.massdrop.com/r/KEP8XC" title="Massdrop" target="\_blank"\>Massdrop\</a\> ErgoDox group buys\</li\>
\- \<a href="http://deskthority.net/wiki/ErgoDox" title="ErgoDox on Deskthority" \>Deskthority\</a\> in-depth review\</li\>
\- \<a href="http://geekhack.org" title="GeekHack community" target="\_blank"\>GeekHack.org\</a\> community of keyboards enthusiasts.\</li\>
\- \<a href="http://ergodox.org" title="ErgoDox project page" target="\_blank"\>ErgoDox\</a\> project page\</li\>
\
Tue, 09 Dec 2014 19:30:00 GMThttp://andreaazzola.com/ergodox-ergonomic-keyboard-review

Personal Branding, a Brief Introduction

http://andreaazzola.com/personal-branding-introduction/Personal branding is a branch of marketing and a set of techniques for nurturing the public perception of self. I&#39;m a software developer with interest in personal development and entrepreneurship, the article discuss a few key principles I&#39;ve learn over time and literature.
It&#39;s a matter of survival
We all live in times when big corporations are in the web, when stability of…\Personal branding is a branch of marketing and a set of techniques for \<em\>nurturing\</em\> the public \<em\>perception of self\</em\>. I&#39;m a software developer with interest in personal development and entrepreneurship, the article discuss a few key principles I&#39;ve learn over time and literature.\</p\>
\\![](/images/resource)\</p\>
\<h2\>It&#39;s a matter of survival\</h2\>
\We all live in times when big corporations are in the web, when stability of work contracts is challenged everyday by competition and outsourcing to to the cheapest. Information is a first class citizen, HR departments can conduct pretty much of all of their research through \<em\>LinkedIn and Google\</em\>. Change might be subtle but it&#39;s unrelentingly pulling the levers.\</p\>
\<h2\>The Brand Called You\</h2\>
\A brand, is an \<em\>identity\</em\> composed by a \<em\>singularity of values\</em\>. Apply this concept to people and you get a basic principle: being \<em\>distinguishable\</em\>. And you want to get the \<em\>positive\</em\> type of distinction, of course.\</p\>
\For everyone of us, even if unwillingly, we always carry a brand, everyday. The way we appear, behave and communicate: \<strong\>the entire experience of self, given to others\</strong\>.\</p\>
\We can decide to \<em\>leverage\</em\> this perception, on various degrees, or we can decide to ignore it. Although not everybody is comfortable marketing himself, it is also true that nobody want to be a target in hunting season ant that&#39;s where the excess negligence leads to.\</p\>
\<h2\>It&#39;s passive income\</h2\>
\
> \\<em\>Don&#39;t try to do everything yourself. Find a horse to ride ~Jack Trout\</em\>\</p\>
\</blockquote\>
\Advertising is the Soul of commerce. Sure, but it can be expensive, invasive and overwhelming too. Some of us, are developing anti-corps, to advertising.\</p\>
\You might have heard the phrase \<em\>SEO is dead\</em\> and while this is not entirely true, Google&#39;s new algorithm \<a href="http://en.wikipedia.org/wiki/Google_Hummingbird"\>Hummingbird\</a\> tend to \<em\>care less about keywords\</em\> but much more about the surrounding \<a href="https://www.youtube.com/watch?v=xQmQeKU25zg&amp;list=TLe6b5U3IbZbxyiAAWxi52RUtRXUBaxm-S#t=280" target="\_blank"\>\<em\>network of trust\</em\>\</a\>. Google&#39;s business after all is to provide users with more effective answers and increase its own conversion rate.\</p\>
\Put that into perspective and we may come to the conclusion that \<em\>content is king\</em\>. You can choose to go to every single contact of your list, ring the bell, hope to make a sale, hope they not mark you as &quot;spam&quot;. Or you can have them coming to you, because of the \<em\>network of trust\</em\> you&#39;ve built with \<strong\>true value\</strong\> over time. That&#39;s \<strong\>the brand working for you\</strong\>.\</p\>
\Personal branding can be used for many purposes:\</p\>
\

\- Attract customers\</li\>
\- Career improvement\</li\>
\- Boost a new project\</li\>
\- Get more revenues out of an existing business\</li\>
\- Control on-line reputation\</li\>
\- Get in touch with experts\</li\>
\- Grow a social capital\</li\>
\

\<h2\>But I already work for a company \<em\>(and I like it)\</em\>\</h2\>
\Personal branding in a company is good!\</p\>
\

\- \\<em\>Companies are made of people\</em\>. The higher the reputation of a company is, so are the chances of landing opportunities. Famous people tend to bring prestige to a company, not misfortune.\</p\>
\</li\>
\- \We might be doing an \<em\>excellent job right now\</em\>, it might amount to nothing if nobody, other than us, knows about it. On the other hand, someone else might be doing an &quot;ok&quot; job, communicate it effectively and get rewarded.\</p\>
\</li\>
\- \\<em\>It strengthens the team cohesion\</em\>, colleagues and professionals that gravitates around you, if earned, will grant trust. Plus, they may feel inspired by what you&#39;re doing and step up they&#39;re game too, which would be a huge win for the company.\</p\>
\</li\>
\

\<h2\>Conclusion\</h2\>
\The path of true personal branding is not for everyone, it lead to exposure, it requires perseverance. It is a tool and like all tools requires knowledge and must be used properly and if needed. Of course, it can lead to enormous benefits.\</p\>Sat, 07 Jun 2014 16:00:00 GMThttp://andreaazzola.com/personal-branding-introduction

Filco Majestouch-2 Tenkeyless Ninja Mechanical Keyboard Review

http://andreaazzola.com/review-filco-majestouch2-tenkeyless-ninja/The Filco Majestouch-2 Tenkeyless Ninja is a japanese mechanical keyboard that sport semi-blank keys, n-key rollover and it&#39;s built like a tank... plus, it&#39;s ninja!
Here is why I love it and why I think you should do too:
It&#39;s mechanical
For those who don&#39; t know: mechanicals keyboards engage physical switches when keys are pressed, whilst rubber domes on the…\\<a href="http://amzn.to/1NW62IY" target="\_blank" Title="Buy Filco Majestouch-2 on Amazon"\>\![Filco Majestouch-2 Ninja Tenkeyless black](/images/posts/filcomajestouch_side.jpg)\</a\>\</p\>
\The \<strong\>Filco Majestouch-2 Tenkeyless Ninja\</strong\> is a \<strong\>japanese mechanical keyboard\</strong\> that sport semi-blank keys, n-key rollover and it&#39;s built like a tank... plus, \<strong\>it&#39;s ninja\</strong\>!\</p\>
\Here is why I love it and why I think you should do too:\</p\>
\<h2\>It&#39;s mechanical\</h2\>
\For those who don&#39; t know: \<strong\>mechanicals keyboards\</strong\> engage \<em\>physical switches\</em\> when keys are pressed, whilst \<strong\>rubber domes\</strong\> on the counterpart, engage\<em\> rubber membranes\</em\> which close the electrical circuit. Latest are cheaper, spill-resistant, usually do not provide a significant tactile feedback; the foremost does, mechanicals are famous for providing a distinctive &#39;clicky&#39; sound. This helps to relate the action and therefore acknowledge or autocorrect the key press .\</p\>
\Should you bother? Well, if you&#39;re going to spend a bit chunk of your career typing, my advice would be to least give a try. Most people I heard of never turned back, me ain&#39;t going either. Maybe it won&#39;t change your life, it won&#39;t increased you productivity significantly except for typing skills. In my perception, each mechanical key pressure tend to feel slightly more significant.\</p\>
\The \<em\>Filco Majestouch-2\</em\> comes with a choice of \<a href="http://www.keyboardco.com/blog/index.php/2012/12/an-introduction-to-cherry-mx-mechanical-switches/" target="\_blank"\>Cherry MX\</a\> switches:\</p\>
\

\- \<strong\>Blu\</strong\>: tactile action, very clicky sound\</li\>
\- \<strong\>Brown\</strong\>: tactile action, moderately clicky\</li\>
\- \<strong\>Black\</strong\>: linear action (no feedback), silent\</li\>
\- \<strong\>Red\</strong\>: linear action (no feedback), silent, requires less force to actuate\</li\>
\

\I got the \<em\>brown\</em\>, in an office environment the blues sound \<em\>could annoy other people\</em\>, and due to my typist nature, I preferred a tactile action, with feedback.\</p\>
\<h2\>Tenkeyless layout\</h2\>
\It&#39;s called a \<strong\>tenkeyless\</strong\> layout, because it lacks a few keys: \<em\>the numeric pad\</em\>. This layout tops at \<strong\>87 keys\</strong\>, while the classic version of the \<em\>Majestouch-2\</em\>, tops at 104 keys. The reason for a tenkeyless layout to exist is to allow movement of the mouse closer to your front-center, and portability.\</p\>
\Less keys shouldn&#39;t be a problem to the majority of people other than those who use the numeric pad often. Still, separated numeric pads for intensive or occasional numeric typing are also available (yep, Filco makes them too). I find the \<em\>tenkeyless \</em\>layout to be \<strong\>very focused\</strong\> and I&#39;m very happy with the choice.\</p\>
\<h2\>Ninjaaa!\</h2\>
\When it comes to \<em\>keyboards\</em\>, \<strong\>ninja \</strong\>means \<strong\>without prints on the keys\</strong\>. The justification for this is: no wear on the letters, letters won&#39;t disappear entirely nor partially, which can be aesthetically annoying. Then often unspoken reason (big revelation here) is that \<em\>ninjas\</em\> are bragging instuments, a person that uses a \<em\>ninja\</em\> is supposed to know the location of each character and therefore states to be power user. I&#39;m personally in for the design, but I think also the second category applies.\</p\>
\<h2\>The keyboard\</h2\>
\\<em\>Shell \</em\>may be plastic, but \<em\>the entire keyboard it&#39;s quite sturdy\</em\>, in fact, it is quite heavy. It has a nice \<em\>matte finish\</em\> (mine&#39;s black, but it also comes in white), details like borders around keys, are well refined. Windows caps are th\<em\>e only caps with printing on top\</em\>, but the package includes \<em\>ninja \</em\>style replacements for your convenience.\</p\>
\Cable is \<em\>not gold coated\</em\>, which \<em\>imho \</em\>should be no problem at all, it is \<strong\>not detachable\</strong\>, this something I would have expected for easier transportation... butif you&#39;re not moving it around to much, should also be no big deal; it is normal/rigid though, not \<em\>soft \</em\>or \<em\>braided\</em\>, which is a little bit unpractical. The package also includes a \<strong\>Filco strap\</strong\>.\</p\>
\\![Filco Majestouch-2 back](/images/posts/filcomajestouch_back.jpg)\</p\>
\Keyboard has \<strong\>four rubber feets\</strong\>, they must have used some &quot;grand-prix rubber&quot; here because once down,\<strong\> it won&#39;t move\</strong\>, and that&#39;s very nice, you definitely don&#39;t want your keyboard to move around when typing. There are also \<strong\>two additional feet on the back\</strong\>, they allow the keyboard to be lifted a bit and they&#39;re also \<strong\>generously rubberized \</strong\>with the same material. \</p\>
\\![Filco Majestouch-2 rubber foot](/images/posts/filcomajestouch_foot.jpg)\</p\>
\The only branding is a nice and discreet \<em\>Filco \</em\>print on the front (glossy black on matte black), two \<em\>blue standard and plain LEDs\</em\> on the top-right to signal if \<em\>CapsLock\</em\> or \<em\>ScrollLock\</em\> are turned on. The Majestouch-2 also supports \<strong\>N-Key rollover\</strong\> via the PS/2 adapter (that&#39;s included). N-Key rollever it&#39;s a feature that allows detection of multiple fast consecutive key press or multiple key press (combinations of six keys and above).\</p\>
\\![Filco Majestouch-2 CapsLock and ScrollLock](/images/posts/filcomajestouch_lights.jpg)\</p\>
\<h2\>About Filco\</h2\>
\\<em\>Filco \</em\>is the brand name for a division of the \<a href="https://www.diatec.co.jp/en/aboutus.php" target="\_blank"\>Diatec Corporation\</a\>. Established in 1982, \<em\>Diatec \</em\>also sells power supplies, AC adapters and accessories. The main distributor for Europe is \<a href="http://www.keyboardco.com/" target="\_blank"\>The Keyboard Company\</a\>, while for the U.S. is \<a href="http://www.amazon.com" target="\_blank"\>Amazon\</a\>. Other suppliers can be found \<a href="http://www.keyboardco.com/fil/suppliers.asp" target="\_blank"\>here\</a\>.\</p\>
\<h2\>Conclusion\</h2\>
\This kind of keyboard \<strong\>is not cheap\</strong\> and will \<strong\>attract attention\</strong\>. I love it, it is definitely quality gear, it will last you a lot of years. \<a href="http://amzn.to/1NW62IY" target="\_blank" Title="Filco Majestouch-2 on Amazon"\>Click here to know current price options and reviews\</a\>. In the following picture the \<em\>Majestouch-2\</em\> sits right next to my \<em\>Zowie AM \</em\>mouse, a beautiful duo ain&#39;t it?\</p\>
\\![Filco Majestouch-2 workstation](/images/posts/filcomajestouch_workstation.jpg)\</p\>Thu, 29 May 2014 11:58:00 GMThttp://andreaazzola.com/review-filco-majestouch2-tenkeyless-ninja

Logging with NLog and SQLite

http://andreaazzola.com/logging-nlog-sqlite/This article explains how to achieve a portable and elegant logging solution with NLog and SQLite, the solution targets the .NET platform and only requires a few configurations.
NLog
NLog is a free and lightweight logging library, supports .NET, Silverlight and Windows Phone http://nlog-project.org/. It is an excellent option for a wide range of scenarios: from simple day-to-day…\\![Introductory image](/images/nlogsqlite_love.png)\</p\>
\This article explains how to achieve a portable and elegant \<em\>logging \</em\>solution with NLog and SQLite, the solution targets the .NET platform and only requires a few configurations.\</p\>
\<h2\>NLog\</h2\>
\NLog is a free and lightweight logging library, supports .NET, Silverlight and Windows Phone \<a href="http://nlog-project.org/"\>http://nlog-project.org/\</a\>. It is an excellent option for a wide range of scenarios: from simple day-to-day utilities, to critical production services. It also enables your application to have multiple and diverse targets, both files, databases, output consoles, networks, email and so on are supported.\</p\>
\\<strong\>Setup\</strong\>\</p\>
\Package Manager Console:\</p\>
\
\<code\>PM&gt; Install-Package NLog\</code\>\</pre\>
\NuGet browser:\</p\>
\\![NLog on NuGet packet manager](/images/nlogsqlite_nlog.png)\</p\>
\<h2\>SQLite\</h2\>
\\<a href="http://www.sqlite.org/"\>SQLite\</a\> is a simple \<em\>database engine\</em\>, it became famous in the mobile world because of its qualities: a server deamon is not required nor any particular configuration. The database is usually represented by a simple file (usually .db3), read and writes are handled by platform-specific libraries, which usually are available for free.\</p\>
\\<strong\>Setup\</strong\>\</p\>
\The most famous interface for .NET is \<em\>System.Data.SQLite\</em\>\</p\>
\Package Manager Console\</p\>
\
\<code\>PM&gt; Install-Package System.Data.SQLite\</code\>\</pre\>
\NuGet browser\</p\>
\\![SQlite on NuGet packet manager](/images/nlogsqlite_sqlite.png)\</p\>
\<h2\>The NLog configuration file\</h2\>
\This is optional, but warmly suggested: have a separate file for \<em\>NLog\</em\> configurations. Suppose someone screws up the configurations, wouldn&#39;t be safer to have just the logging part of your application failing? Separation of concerns, when possibile, is a good thing.\</p\>
\\<strong\>Setup\</strong\>\</p\>
\Package Manager Console\</p\>
\
\<code\>PM&gt; Install-Package NLog.Config\</code\>\</pre\>
\NuGet browser\</p\>
\\![NLog Configuration on NuGet packet manager](/images/nlogsqlite_nlog-cfg.png)\</p\>
\<h2\>Get them to work together\</h2\>
\

\- \\<strong\>Get the SQLite database ready\</strong\>, use \<a href="http://sourceforge.net/projects/sqlitebrowser/"\>SQLite Database Browser\</a\> or your client of choice to create the database, then execute the following T-SQL statement to create the \<em\>Log\</em\> table:\</p\>
\
\<code\> CREATE TABLE Log (Timestamp TEXT, Loglevel TEXT, Logger TEXT,
Callsite TEXT, Message TEXT) \</code\>\</pre\>
\</li\>
\- \\<strong\>Connect your App to the database\</strong\>, change the NLog configuration as follows:\</p\>
\
\<code\> &lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot; ?&gt;
&lt;nlog xmlns=&quot;http://www.nlog-project.org/schemas/NLog.xsd&quot;
xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot;
throwExceptions=&quot;false&quot;&gt;
&lt;targets&gt;
&lt;target name=&quot;db&quot; xsi:type=&quot;Database&quot;
dbProvider=&quot;System.Data.SQLite&quot; keepConnection=&quot;false&quot;
connectionString=&quot;Data Source=\${basedir}\Log.db3;Version=3;&quot;
commandText=&quot;INSERT into Log(Timestamp, Loglevel, Logger, Callsite, Message)
values(@Timestamp, @Loglevel, @Logger, @Callsite, @Message)&quot;&gt;
&lt;parameter name=&quot;@Timestamp&quot; layout=&quot;\${longdate}&quot;/&gt;
&lt;parameter name=&quot;@Loglevel&quot; layout=&quot;\${level:uppercase=true}&quot;/&gt;
&lt;parameter name=&quot;@Logger&quot; layout=&quot;\${logger}&quot;/&gt;
&lt;parameter name=&quot;@Callsite&quot; layout=&quot;\${callsite:filename=true}&quot;/&gt;
&lt;parameter name=&quot;@Message&quot; layout=&quot;\${message}&quot;/&gt;
&lt;/target&gt;
&lt;/targets&gt;
&lt;rules&gt;
&lt;logger name=&quot;\*&quot; minlevel=&quot;Warn&quot; writeTo=&quot;db&quot; /&gt;
&lt;/rules&gt;
&lt;/nlog&gt;\</code\>\</pre\>
\</li\>
\- \\<strong\>Start logging\</strong\>\</p\>
\
\<code\>class Program {
static Logger log = LogManager.GetCurrentClassLogger();
static void Main(string\[\] args)
{
log.Info(&quot;Logging like a boss&quot;);
}
}\</code\>
\</pre\>
\</li\>
\

\<h2\>Done!\</h2\>
\You can review the source code and download the sample project here:\<br /\>
\<a href="https://github.com/aazzola/nlog-sqlite/" target="\_blank"\>https://github.com/aazzola/nlog-sqlite/\</a\>\</p\>Tue, 06 May 2014 14:29:00 GMThttp://andreaazzola.com/logging-nlog-sqlite

MavensMate unable to reach GitHub on Windows

http://andreaazzola.com/mavensmate-unable-github-windows/MavensMate is a great plugin for the Force.com platform, built on the Sublime Text IDE. It is provided by the community (with Joe Ferraro as the creator and main contributor) as a free alternative to the well known Force.com IDE shipped by Salesforce.com.
Now, if you install the plugin on a Microsoft Windows 7 o 8 workstation, under certain conditions (usually proxy or firewalling, however…\
\<a href="http://mavensmate.com/" target="\_blank" title="Mavens Mate page"\>MavensMate\</a\> is a great plugin for the Force.com platform, built on the \<a href="http://www.sublimetext.com/" target="\_blank" title="Sublime Text page"\>Sublime Text IDE\</a\>. It is provided by the community (with \<a href="http://www.joe-ferraro.com/" target="\_blank" title="Joe Ferraro personal website"\>Joe Ferraro\</a\> as the creator and main contributor) as a free alternative to the well known \<a href="https://wiki.developerforce.com/page/Force.com_IDE" target="\_blank" title="Force.com IDE official page"\>Force.com IDE\</a\> shipped by \<em\>Salesforce.com\</em\>.\</p\>
\
Now, if you install the plugin on a Microsoft Windows 7 o 8 workstation, under certain conditions (usually proxy or firewalling, however not my case) you may get the following error:\</p\>
\
\Installation of Sublime Text plugin failed. This is likely due to the installer being unable to reach GitHub. If you are behind a firewall or using a proxy, you should configure git accordingly (google: git config --global https.proxy) and ensure your HTTPS/HTTPS_PROXY environment variable(s) are set properly. Otherwise, please log an issue on the MavensMate GitHub project.\\</p\>
\
 \</p\>
\<center\>\![](/images/resource)\</center\>
\
 \</p\>
\
There&#39;s already an \<a href="https://github.com/joeferraro/MavensMate/issues/113" target="\_blank" title="MavensMate issue"\>issue\</a\> on GitHub for this, and a useful workaround by \<em\>Joe Ferraro\</em\> himself.\<br /\>
These are the lines that worked for me:\</p\>
\

\- Fire up the shell/bash and move to the MavensMate plugin directory (replace the \<em\>username \</em\>and \<em\>root \</em\>if needed)\<br /\>
\
\<code\>cd &quot;C:\Users\username\AppData\Roaming\Sublime Text 3\Packages&quot;\</code\>\</pre\>
\</li\>
\- Launch the following script\<br /\>
\
\<code\>git clone --recursive http://github.com/joeferraro/MavensMate-SublimeText.git MavensMate
cd MavensMate
git submodule init
git submodule update\</code\>\</pre\>
\</li\>
\

\
Supposedly, when you&#39;ll run \<em\>Sublime Text\</em\> again, \<em\>MavensMate \</em\>will be there.\<br /\>
But you&#39;re not done yet, remeber to configure the workspace through the menu \<em\>MavensMate - Setting\</em\>.\</p\>Sun, 06 Apr 2014 09:22:00 GMThttp://andreaazzola.com/mavensmate-unable-github-windows

Search Email Inbox with C#

http://andreaazzola.com/search-email-inbox-csharp/A few years ago I helped managing a radio and I needed a tool&mdash;an ASP.NET web page&mdash;for the periodical download of promo mixes. They were linked in some emails recognizable by a few keywords.
The following, is the stripped down C# snippet from the tool, it demonostrate how to perform both the search inside the email&#39;s subject and body, and the download, with the use of the…\
A few years ago I helped managing a \<a href="http://magmaglobalgroove.com" target="\_blank" title="Visit MaGmA Global Radio"\>radio\</a\> and I needed a tool&mdash;an \<em\>ASP.NET\</em\> web page&mdash;for the periodical download of promo mixes. They were linked in some emails recognizable by a few keywords.\</p\>
\
The following, is the stripped down \<strong\>C# snippet\</strong\> from the tool, it demonostrate how to perform both the \<em\>search inside the email&#39;s subject and body\</em\>, and the download, with the use of the \<strong\>\<a href="http://en.wikipedia.org/wiki/Internet_Message_Access_Protocol" target="\_blank" title="IMAP on wikipedia"\>IMAP\</a\>\</strong\> protocol:\</p\>
\
\<code class="cs"\>using (ImapClient ic = new ImapClient(&quot;imap.gmail.com&quot;, &quot;gmail@gmail.com&quot;, &quot;mypassword&quot;,
ImapClient.AuthMethods.Login, 993, true))
{
ic.SelectMailbox(&quot;INBOX&quot;);
MailMessage\[\] mm = ic.GetMessages(0, 100, false); // retrieves the latest 100 messages
foreach (MailMessage m in mm)
if (((m.From.Address == &quot;foo@bar.com&quot;) \|\| (m.Body.ToLower().Contains(&quot;episode&quot;)))
{
Regex regx = new Regex(&quot;(http\|https)://(\[\\w+?\\.\\w+\])+(\[a-zA-Z0-9\\~\\!\\@
\\#\\\$\\%\\^\\&amp;\\\*\\(\\)\_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\&#39;\\,\]\*)?&quot;,
RegexOptions.IgnoreCase);
MatchCollection matches = regx.Matches(m.Body);
Response.ClearContent();
Response.ContentType = &quot;audio/mpeg3&quot;;
Response.AddHeader(&quot;Content-Disposition&quot;, &quot;attachment; filename=Episode.mp3&quot;);
using (WebClient wc = new WebClient())
Response.BinaryWrite(wc.DownloadData(matches\[0\].Value));
Response.End();
}
}
\</code\>
\</pre\>
\
The script was based on the \<strong\>AE.NET.Mail library\</strong\>, which \<a href="http://andy.edinborough.org/" target="\_blank" title="Andy Edinborough's website"\>Andy Edinborough\</a\> made free to use and it is available on his \<a href="https://github.com/andyedinborough/aenetmail" target="\_blank" title="C# POP/IMAP Mail Client"\>GitHub\</a\> account.\</p\>Thu, 27 Mar 2014 17:23:00 GMThttp://andreaazzola.com/search-email-inbox-csharp

A few handy Pomodoro Timer Apps for Mac and Windows

http://andreaazzola.com/pomodoro-apps/It is same to assume, that if you landed on this page, you already know about the Pomodo Technique:
Work 25 minutes on a well defined activity, no distraction allowed
Rest 5 minutes, or 15 minutes after 4 pomos
Start over
Let&#39;s make just a short recap of the key benefits:
Work with time
The approach leads to regulatework pace, in fact people tend to…\
It is same to assume, that if you landed on this page, you already know about the \<strong\>\<a href="http://pomodorotechnique.com/" target="\_blank" title="The Pomodoro technique official website"\>Pomodo Technique\</a\>\</strong\>:\</p\>
\

\- \<strong\>Work \<u\>25 minutes\</u\> on a well defined activity, no distraction allowed\</strong\>\</li\>
\- \<strong\>Rest \<u\>5 minutes\</u\>, or \<u\>15 minutes after 4 pomos\</u\>\</strong\>\</li\>
\- \<strong\>Start over\</strong\>\</li\>
\

\
Let&#39;s make just a short recap of the key benefits:\</p\>
\

\- \<strong\>Work with time\</strong\>\<br /\>
The approach leads to regulatework pace, in fact people tend to consider just the deadlines\</li\>
\- \<strong\>Eliminate burnout\</strong\> \<br /\>
It gives a defined time to refocus, without a proper technique is an easy apect to be aware of\</li\>
\- \<strong\>Manage distraction\</strong\>\<br /\>
Everything not directly involved in the activity, should be left out or moved in other pomos\</li\>
\- \<strong\>Create a better work-life balance\</strong\>\<br /\>
When the line between work and spare time it&#39;s more clear, it&#39;s easier to switch\<br /\>
 \</li\>
\

\
So, here is the list of my favourite apps&mdash;\<em\>in order of preference\</em\>&mdash;for applying the technique on a Desktop environment:\</p\>
\<h2\>
\<a href="https://code.google.com/p/pomodairo/" target="\_blank" title="Go to Pomodairo's website"\>Pomodairo\</a\>\</h2\>
\
\![Pomodoro Client](/images/pomodoro_pomodairo.png)\</p\>
\
Collapsed view\<br /\>
\![](/images/pomodoro_pomodairo-collapsed.png)\</p\>
\
Link: \<a href="https://code.google.com/p/pomodairo/" target="\_blank" title="Go to Pomodairo's website"\>https://code.google.com/p/pomodairo/\</a\>\<br /\>
License: Free\<br /\>
Platforms: Windows, Mac (Adobe AIR)\<br /\>
\<br /\>
With its big timer and plain design it&#39;s my application of choice in a Windows environment. The main windows is collapsible so it is possible to embed it where it is visible but out of the mouse pointer way. I don&#39;t like the mandatory need of managing a list of activities in it, because I already have a few of those, but it&#39;s a minor issue, I just use a fake one.\</p\>
\<h2\>
\<a href="http://www.focusboosterapp.com/" target="\_blank" title="Go to Focus Booster's website"\>Focus Booster\</a\>\</h2\>
\
\![Focus Booster screenshot](/images/pomodoro_focusbooster.png)\</p\>
\
Collapsed view\<br /\>
\![Focus Booster collapsed screenshot](/images/pomodoro_focusbooster-collapsed.png)\</p\>
\
Link: \<a href="http://www.focusboosterapp.com/" target="\_blank" title="Go to Focus Booster's website"\>http://www.focusboosterapp.com/\</a\>\<br /\>
License: Free\<br /\>
Platforms: Windows, Mac (Adobe AIR)\</p\>
\
I use it mainly on my Mac environment. It&#39;s like a huge progress bar meant to represent the pomodoro time, like Pomodairo it turns to yellow or red as the end of the interval approaches. I like it beacause it&#39;s more adherent to the nature of a physical pomodoro timer. It requires manual update, ant the collapsed version, which I find most appealing, sometimes is too small to be noticed. Other fun aspect, because of its non-windows-style aspect I get a lot of questions about it, so at the end it can cause some distraction.\</p\>
\<h2\>
\<a href="http://www.tomighty.org/" target="\_blank" title="Go to Tomighty's website"\>Tomighty\</a\>\</h2\>
\
On Windows and Linux:\<br /\>
\![Tomighty screenshot](/images/pomodoro_tomighty-windows.png)\</p\>
\
On Mac OS\<br /\>
\![Tomighty for Mac screenshot](/images/pomodoro_tomighty-mac.png)\</p\>
\
Link: \<a href="http://www.tomighty.org/"\>http://www.tomighty.org/\</a\>\<br /\>
License: Free, Open source\<br /\>
Platforms: Windows, Mac, Linux\</p\>
\
This timer is a no brainer, it integrates with the system taskbars which is nice. \</p\>
\<h2\>
\<a href="http://tomatoi.st/" target="\_blank" title="Go to Tomatoi.st's website"\>Tomato.ist\</a\>\</h2\>
\
Link: \<a href="http://tomatoi.st/" target="\_blank" title="Go to Tomatoi.st's website"\>http://tomatoi.st/\</a\>\<br /\>
License: Free\<br /\>
Platforms: Browser based\<br /\>
\<br /\>
This is a browser based app. I like the idea of not needing an app to manage such a simple task, plus most of browser today allow pinning of pages. But you can miss notification which is pretty much the point of having a timer. At the end it&#39;s up to you and your way of interacting with web pages or desktop interfaces.\</p\>Thu, 27 Mar 2014 15:29:00 GMThttp://andreaazzola.com/pomodoro-apps

Humans and Multitasking

http://andreaazzola.com/human-multitasking/Multitasking
Multitasking means the capability of executing multiple tasks concurrently. The multitasking concept find its origins in the computer industry. Nowadays consumer computers, phones, tablets are perfectly capable of running multiple logics in the same time window, they&#39;ve become so good at this that some company are already focusing toward the next big step, anticipatory…\\![](/images/resource)\</p\>
\<h2\>Multitasking\</h2\>
\\<a href="http://it.wikipedia.org/wiki/Multitasking" target="\_blank"\>Multitasking\</a\> means the capability of executing multiple tasks concurrently. The \<em\>multitasking\</em\> concept find its origins in the computer industry. Nowadays consumer computers, phones, tablets are perfectly capable of running multiple logics in the same time window, they&#39;ve become so good at this that some company are already focusing toward the next big step, \<a href="http://en.wikipedia.org/wiki/Anticipation\_(artificial_intelligence)" target="\_blank"\>anticipatory computing\</a\> (eg: Google Now). Assisted \<em\>multitasking\</em\> brings huge benefits in terms of productivity, some computations can be anticipated and so them results, which is a huge win for everyone. But other than devices, can, our brain, multitask? The answer is apparently, \<em\>no\</em\>.\</p\>
\<h2\>Subconscious mind\</h2\>
\Technically speaking, we are constantly \<em\>multitasking\</em\>. Breathing, like heartbeat, belongs to a subset of tasks handled by our \<a href="http://www.2knowmyself.com/Subconscious_mind" target="\_blank"\>subconscious mind\</a\> and these tasks represent one exception.\</p\>
\Yes, sometimes you do drive home without even noticing while being in a call at the same time right? Isn&#39;t that \<em\>multitasking\</em\>? So and so. Our brain is capable of learning and when it comes to routine tasks, it is so good at perfecting them that so they can become part of our subconscious mind.\</p\>
\But \<em\>conscious \</em\>and \<em\>subconscious \</em\>are not black or white areas, there are &quot;shades of gray&quot;. While breathing is perfectly automatic, driving still requires a little bit of attention (hopefully, we dedicate a good amount). How much, varies from individual to individual and it&#39;s a matter of habits, brainpower and lots of other more scientific factors.\</p\>
\<h2\>Task switching\</h2\>
\For \<em\>human multitasking\</em\> however we usually refer to \<em\>our\</em\> capability of executing intensive tasks concurrently, such as sustaining a pretty dense conference call, while drawing a flow chart for a different project. That&#39;s, according to science, simply not possible.\</p\>
\ The thing is: brain can become pretty good at \<em\>switching tasks\</em\>, so good that can give you a perception of multitasking, but it&#39;s not what&#39;s happening, it&#39;s an illusion. Under the hood, it&#39;s like in the cartoons making process, when sheets are switched so fast that they gave you a sense of motion, but in the matter of facts, each of those are a single static drawings well distinguished between each other.\</p\>
\Lots of us are fantastic &quot;task switchers&quot;, &quot;perceived multitaskers&quot; and that&#39;s nontheless a good quality because the industry and our personal lifes demands it, but sustaining the illusion requires a huge toll on our energy, on our stress levels and subsequently, on our life quality.\</p\>
\<h2\>How to deal with it\</h2\>
\So the intent of this post is not discourage people from trying to achieve \<em\>multitasking\</em\>, but devoting energies to single, atomic, subsequent tasks, can be extremely productive! In fact, by allowing the allocation of all of our resources, &quot;computational power and memory&quot; to a single tasks, we get things done much faster. In a fast task switching context there&#39;s also a substancial factor that brings our brain resources to a faster drain and guess what it is, the task switching process! That&#39;s a task too!\</p\>
\A few advices I can derive from personal experience are:\</p\>
\

\- Take the risk, block distractions as soon as circumnstances allow it and prove your method, to yourself and to your boss if necessary. \</li\>
\- That stuff that knocks to you door continuosly? move it in your Inbox/Queue and, if not super urgent, fall back to resuming what you were doing. You can always review new stuff later, as soon as you finish. The book \<a href="https://www.amazon.com/gp/product/0142000280/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=aazzola00-20&creative=9325&linkCode=as2&creativeASIN=0142000280&linkId=93c5e69daf8f1470e228ae225f7ef169" target="\_blank"\>Gettings Things Done\</a\> from David Allen could give you some great advice in that area.\</li\>
\- Your subconscious can become even more of a resource, practice tasks you would want to be easier for you and your brain.\</li\>
\

\<h2\>Further Readings\</h2\>
\

\- Book: \<a href="https://www.amazon.com/gp/product/0393339750/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=aazzola00-20&creative=9325&linkCode=as2&creativeASIN=0393339750&linkId=07bca25468d6ae154439461757e6739a" target="\_blank"\>The Shallows: What the Internet Is Doing to Our Brains\</a\> by Nicholas Carr\</li\>
\- Blog post: \<a href="http://www.nytimes.com/2007/03/25/business/25multi.html?\_r=0" target="\_blank"\>Slow Down, Brave Multitasker, and Don&rsquo;t Read This in Traffic\</a\> by New York Times\</li\>
\- Blog post: \<a href="http://www.joelonsoftware.com/articles/fog0000000022.html" target="\_blank" target="\_blank"\>Human Task Switches Considered Harmful\</a\> by Joel on Software\</li\>
\
Thu, 30 Jan 2014 21:22:00 GMThttp://andreaazzola.com/human-multitasking

Manage and format Dates with JavaScript

http://andreaazzola.com/javascript-date-handling-format/JavaScript has a Date object wich you can use to handle dates. Supported constructors are:
new Date() // with current date and time
new Date(numeric) // by adding N milliseconds to the Unix epoch time (1970-01-01T00:00:00Z)
new Date(year, month, day, hour, minute, second, millisecond)
new Date(year, month, day) // the time part will equal &quot;00:00.000&quot;
There are some…\
JavaScript has a \<strong\>\<em\>Date\</em\> object\</strong\> wich you can use to handle dates. Supported \<em\>constructors\</em\> are:\</p\>
\
\<code class="javascript"\>new Date() // with current date and time
new Date(numeric) // by adding N milliseconds to the Unix epoch time (1970-01-01T00:00:00Z)
new Date(year, month, day, hour, minute, second, millisecond)
new Date(year, month, day) // the time part will equal &quot;00:00.000&quot;
\</code\>\</pre\>
\
There are some built-in methods that can be used to extract or set dateparts:\</p\>
\
\<code class="javascript"\>.getDate() // get the day part \[1-31\]
.getDay() // get the week day \[0-6\]
.getFullYear() // get the four digits year part
.getHours() // get the hour part
.getMinutes() // get the minutes part
.getSeconds() // get the seconds part
.getMilliseconds() // get the millisencond part
.setDate() // set the day part \[1-31\]
.setDay() // set the week day \[0-6\]
.setFullYear() // set the four digits year part
.setHours() // set the hour part
.setMinutes() // set the minutes part
.setSeconds() // set the seconds part
.setMilliseconds() // set the millisencond part
\</code\>\</pre\>
\
And their \<a href="http://en.wikipedia.org/wiki/Coordinated_Universal_Time" target="\_blank" title="Coordinated Universal Time definition on Wikipedia"\>\<strong\>UTC\</strong\>\</a\> variant:\</p\>
\
\<code class="javascript"\>.getDate() // get the UTC date day part \[1-31\]
.getUTCDay() // get the UTC week day \[0-6\]
.getUTCFullYear() // get the UTC four digits year part
.getUTCHours() // get the UTC hour part
.getUTCMinutes() // get the UTC minutes part
.getUTCSeconds() // get the UTC seconds part
.getUTCMilliseconds() // get the UTC millisecond part
.setUTCDate() // set the UTC day part \[1-31\]
.setUTCDay() // set the UTC week day \[0-6\]
.setUTCFullYear() // set the UTC four digits year part
.setUTCHours() // set the UTC hour part
.setUTCMinutes() // set the UTC minutes part
.setUTCSeconds() // set the UTC seconds part
.setUTCMilliseconds() // set the UTC millisecond part
\</code\>\</pre\>
\
As per formatting, there are two simple options:\</p\>
\
1) A combo of the aforementioned methods\</p\>
\
\<code class="javascript"\>var myDate = new Date();
alert(myDate.getFullYear() + &#39;-&#39; + myDate.getMonth() + &#39;-&#39; myDate.getDay());
\</code\>\</pre\>
\
2) A dedicated library like \<strong\>\<a href="http://momentjs.com/" target="\_blank" title="A javascript date library for parsing, validating, manipulating, and formatting dates"\>Moment.js\</a\>\</strong\>\</p\>
\
\<code class="javascript"\>var myDate = moment(new Date(1970, 1, 1));
myDate.format(&#39;MMMM Do YYYY, h:mm:ss a&#39;); // displays January 1st 1970, 1:00:00 pm
myDate.format(&#39;dddd&#39;); // displays Thursday
myDate.format(); // displays 1970-01-01T00:00:00+00:00\</code\>\</pre\>
\
\<strong\>Moment.js \</strong\>also supports \<em\>validations\</em\>, \<em\>UTC\</em\>, \<em\>timespans\</em\> and \<a href="http://momentjs.com/docs/" title="Moment.js documentation"\>many more\</a\>...\</p\>Thu, 14 Nov 2013 11:39:00 GMThttp://andreaazzola.com/javascript-date-handling-format

Ichigo, an ASP.NET Blogging Engine

http://andreaazzola.com/ichigo-asp-net-blogging-engine/With this post, I intend to leave a trace of the specs of this blog, I&#39;ve started this project in 2008 and never publicy mentioned it.
Codename is Ichigo, named after Kurosaki Ichigo which is the main character for the popular manga serie Bleach by Mr. Tite Kubo. There&#39;s no particular reason for the reference, I just like the manga.
Since then, the blog has been to me like some…\
With this post, I intend to leave a trace of the specs of this \<em\>blog\</em\>, I&#39;ve started this project in 2008 and never publicy mentioned it.\</p\>
\
Codename is \<em\>Ichigo\</em\>, named after \<a href="http://en.wikipedia.org/wiki/Ichigo_Kurosaki" target="\_blank" title="Kurosaki Ichigo Wikipedia page"\>\<em\>Kurosaki Ichigo\</em\>\</a\> which is the main character for the popular manga serie \<em\>\<a href="http://en.wikipedia.org/wiki/Bleach\_(manga)" target="\_blank" title="Bleach (Manga) Wikipedia page"\>Bleach\</a\> \</em\>by Mr. Tite Kubo. There&#39;s no particular reason for the reference, I just like the manga.\</p\>
\
Since then, the \<em\>blog\</em\> has been to me like some sort of playground, a place to experiment new technologies, I&#39;ll name just a few: \<a href="http://msdn.microsoft.com/en-us/data/ef.aspx" target="\_blank" title="Entity Framework official page"\>Entity Framework\</a\>, \<a href="http://msdn.microsoft.com/en-us/library/ee845452.ASPX" target="\_blank" title="Dynamic Data official page"\>Dynamic Data\</a\>, URL Routing, \<a href="http://www.asp.net/ajax" target="\_blank" title="ASP.net AJAX official page"\>AJAX\</a\>, \<a href="http://jquery.com/" target="\_blank" title="jQuery official website"\>jQuery\</a\>, @font-face, \<a href="http://oauth.net/" target="\_blank" title="OAuth official website"\>OAuth\</a\>...\</p\>
\
On the server side it is powered by:\</p\>
\

\- \<strong\>ASP .net Web form\</strong\> - master pages, web user controls, forms authentication\</li\>
\- \<strong\>.NET Framework 3.5\</strong\> - code base, entity framework\</li\>
\- \<strong\>Azure SQL Database\</strong\>\</li\>
\- \<strong\>Azure Web Sites\</strong\>\</li\>
\

\
At the client side:\</p\>
\

\- \<strong\>HTML 5 \</strong\>- \<strong\> \</strong\>W3C (at time of writing says) it&#39;s valid\</li\>
\- \<strong\>CSS3 \</strong\>- once again W3C blesses me with the green div\</li\>
\- \<strong\>jQuery\</strong\>\</li\>
\- \<strong\>highlight.js\</strong\>\<br /\>
 \</li\>
\- \<strong\>RSS\</strong\> - custom\</li\>
\- \<strong\>Sitemap\</strong\> - custom\</li\>
\- \<strong\>Taxonomy\</strong\> - custom\</li\>
\- \<strong\>Rich Text editor\</strong\> - \<a href="http://ckeditor.com/" target="\_blank" title="CKEditor official website"\>CK\</a\>\</li\>
\

\
Right now the engine it&#39;s not meant to be open or offered as a service, I&#39;m not sure I would have the perserverance to mantain it nor I can think of anybody that could be interested in making something with it.\</p\>
\
I personally like it the way it is: lightweight, minimal, modern, readable, distraction-free. The logo/favicon is something I made out of a cup of coffee picture with \<a href="http://inkscape.org/" target="\_blank" title="InkScape official website"\>InkScape\</a\>, because for many developers, coffee is a constant.\</p\>
\
The \<em\>theme\</em\> is custom, written line-by-line and I&#39;m pretty fond of it, I just can&#39;t find another blog theme that I like as much. The font is a \<em\>DejaVu Serif\</em\>. The \<a href="http://dejavu-fonts.org/wiki/Main_Page" target="\_blank" title="DejaVu font home page"\>DejaVu\</a\> font in the \<a href="http://en.wikipedia.org/wiki/Sans-serif" target="\_blank" title="Sans-serif definition at Wikipedia"\>sans-serif\</a\> variant is the font I use on all my Windows workstations.\</p\>
\
I still think I&#39;ll end up migrating to \<a href="http://wordpress.org" target="\_blank" title="WordPress official website"\>WordPress\</a\> or \<a href="http://ghost.org" target="\_blank" title="Ghost official website"\>Ghost\</a\>, which is (at time of writing) the latest hype and for good reasons\<em\> -\</em\> but I made no serious commitment to blogging so, it&#39;s still nice to have my very own place.\</p\>Tue, 12 Nov 2013 19:34:00 GMThttp://andreaazzola.com/ichigo-asp-net-blogging-engine

Automate SVN/Git Backups of Entire Salesforce.com Organizations

http://andreaazzola.com/salesforce-backup-organization-svn-git/The following solution involves two popolar SCM (SVN and Git), an always-on server (I use Windows, you may want to opt for the cloud) and a few free tools. You will need the Force.com Migration Tool, Apache Ant, and Java JDK. Start by setting things up with the following checklist:
Java JDK - http://www.oracle.com/technetwork/java/javase/downloads/index.html
Apache Ant -…\
The following solution involves two popolar \<abbr title="Source Control Management"\>SCM\</abbr\> (\<abbr title="Subversion"\>SVN\</abbr\> and Git), an always-on server (I use \<em\>Windows\</em\>, you may want to opt for the cloud) and a few free tools. You will need the \<em\>Force.com Migration Tool\</em\>, \<em\>Apache Ant\</em\>, and \<em\>Java JDK\</em\>. Start by setting things up with the following checklist:\</p\>
\

\- Java JDK - \<a href="http://www.oracle.com/technetwork/java/javase/downloads/index.html" title="Download Java JDK"\>http://www.oracle.com/technetwork/java/javase/downloads/index.html\</a\>\</li\>
\- Apache Ant - \<a href="http://ant.apache.org/manual/install.html" title="Download Apache Ant"\>http://ant.apache.org/manual/install.html\</a\>\</li\>
\- Force.com Migration Tool - \<a href="http://www.salesforce.com/us/developer/docs/daas/Content/forcemigrationtool_install.htm" title="Download Force.com Migration Tool"\>http://www.salesforce.com/us/developer/docs/daas/Content/forcemigrationtool_install.htm\</a\>\</li\>
\- Shell (or the Git Bash) - \<a href="http://cygwin.com/install.html" title="Download CygWin"\>http://cygwin.com/install.html\</a\>\</li\>
\

\
I&#39;m using \<abbr title="Subversion"\>SVN\</abbr\>, so an \<abbr title="Subversion"\>SVN\</abbr\> command line client that support the server version (which is above 1.7) is also necessary.\</p\>
\

\- \<abbr title="Subversion"\>SVN\</abbr\> Client - \<a href="http://www.sliksvn.com/en/download" title="Download SlikSVN"\>http://www.sliksvn.com/en/download\</a\>\</li\>
\

\
The next things is setting up working folder and scripts, you&#39;ll have:\</p\>
\
\<code\>myWorkingFolder
build.properties - Connection info
build.xml - Retrieve instructions
myScript.sh\</code\>\</pre\>
\
\<strong\>build.properties\</strong\> content:\</p\>
\
\<code\># build.properties
sf.serverurl = https://www.salesforce.com
sf.username = usr@domain.ext
sf.password = F4ncy!Pwd
sf.directory = Org\</code\>\</pre\>
\
\<strong\>build.xml\</strong\> content:\</p\>
\
\<code class="xml"\>&lt;project name=&quot;MyProject&quot; default=&quot;test&quot; basedir=&quot;.&quot; xmlns:sf=&quot;antlib:com.salesforce&quot;&gt;
&lt;property file=&quot;build.properties&quot;/&gt;
&lt;property environment=&quot;env&quot;/&gt;
&lt;target name=&quot;getOrg&quot;&gt;
&lt;mkdir dir=&quot;Org&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;AccountCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;AccountOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ApexClass&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ApexComponent&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ApexPage&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ApexTrigger&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;AssignmentRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CallCenter&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;CampaignCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CampaignOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CaseCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CaseOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Community&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;ContactCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ContactOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomApplication&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomApplicationComponent&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomLabels&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomObject&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;CustomObjectOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomObjectTranslation&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomPageWebLink&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomSite&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;CustomTab&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Dashboard&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Document&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;EmailTemplate&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Flow&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Group&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;HomePageComponent&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;HomePageLayout&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Layout&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;LeadCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;LeadOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Letterhead&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;OpportunityCriteriaBasedSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot;
metadataType=&quot;OpportunityOwnerSharingRule&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;PermissionSet&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Portal&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Profile&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Queue&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;RemoteSiteSetting&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Report&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;ReportType&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Role&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Scontrol&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;StaticResource&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Workflow&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;sf:bulkRetrieve username=&quot;\${sf.username}&quot; password=&quot;\${sf.password}&quot;
serverurl=&quot;\${sf.serverurl}&quot; metadataType=&quot;Settings&quot;
retrieveTarget=&quot;\${sf.directory}&quot;/&gt;
&lt;/target&gt;
&lt;/project&gt;\</code\>\</pre\>
\
\<strong\>run.cmd\</strong\> content:\</p\>
\
\<code class="dos"\>svn checkout https://localhost:81/svn/myorg/trunk/ Org --depth=infinity --username bot
--password POOr+9jC --non-interactive --trust-server-cert
call ant getOrg
cd Org
svn propedit svn:ignore \*.xml .
svn add --depth=infinity \*
svn commit -m &quot;Scheduled commit&quot; --username bot --password B0tP4\$\$:)
\</code\>\</pre\>
\<!--You can download an example here.--\>
\
Open the bash, run the the scripts, the results should be the following:\</p\>
\
\<code\>myWorkingFolder/
myOrg/ - Project
myOrg/.svn - SVN stuff (or .git for git stuff)
myOrg/\*.\* - Versioned metadata\</code\>\</pre\>
\
If you want to schedule the script in Windows, all you need to do is open the \<em\>command prompt\</em\>; and run the bash executable passing the script path as parameter, note that the whole process takes place in the working directory.\</p\>
\
\<strong\>Please note:\</strong\> the script is for demonstration purpose only and comes with no guarantees. Also, this may be out of date or I could have made mistakes Please leave a comment below and I&#39;ll be happy to fix it for you.\</p\>Thu, 17 Oct 2013 10:36:00 GMThttp://andreaazzola.com/salesforce-backup-organization-svn-git

Get Size of Tables with SQL Server

http://andreaazzola.com/table-size-space-sql-server/A snippet for getting the size for all tables in a SQL Server database that might prove useful for:
Get a better understanding where most of your data is going
Find database bottlenecks
Free up disk space
Reducing maintenance cost
WITH table_space_usage (schema_name, table_name, used, reserved, ind_rows, tbl_rows)
AS (SELECT s.Name, o.Name, p.used_page_count \* 8,…\ A snippet for getting the size for all tables in a \<em\>SQL Server\</em\> database that might prove useful for:\</p\>
\

\- Get a better understanding where most of your data is going\</li\>
\- Find database bottlenecks\</li\>
\- Free up disk space\</li\>
\- Reducing maintenance cost\</li\>
\

\
\<code class="sql"\>WITH table_space_usage (schema_name, table_name, used, reserved, ind_rows, tbl_rows)
AS (SELECT s.Name, o.Name, p.used_page_count \* 8, p.reserved_page_count \* 8, p.row_count,
CASE WHEN i.index_id in ( 0, 1 ) THEN p.row_count ELSE 0 END
FROM sys.dm_db_partition_stats p
INNER JOIN sys.objects as o ON o.object_id = p.object_id
INNER JOIN sys.schemas as s ON s.schema_id = o.schema_id
LEFT OUTER JOIN sys.indexes as i on i.object_id = p.object_id
and i.index_id = p.index_id
WHERE o.type_desc = &#39;USER_TABLE&#39; and o.is_ms_shipped = 0
)
SELECT t.schema_name, t.table_name, sum(t.used) as used_in_kb,
sum(t.reserved) as reserved_in_kb, sum(t.tbl_rows) as rows
FROM table_space_usage as t
GROUP BY t.schema_name , t.table_name
ORDER BY used_in_kb desc\</code\>\</pre\>Wed, 16 Oct 2013 11:07:00 GMThttp://andreaazzola.com/table-size-space-sql-server

Dealing with Salesforce Maximum Debug Log Size

http://andreaazzola.com/salesforce-debug-log-apex/When working with Apex code which iterates a lot, you may need to deal with a truncated log, the error looks like this:
MAXIMUM DEBUG LOG SIZE REACHED
At time of writing, the maximum allowed sized for a debug log is 2 megabytes.
The default monitoring level for Apex code in fact include a lot of clutter that most of the time you won&#39;t need (like METHOD_ENTRY, METHOD_EXIT), and…\
When working with \<em\>Apex code\</em\> which iterates a lot, you may need to deal with a truncated \<em\>log\</em\>, the error looks like this:\<br /\>
\<br /\>
\<strong\>MAXIMUM DEBUG LOG SIZE REACHED\</strong\>\</p\>
\
At time of writing, the maximum allowed sized for a \<em\>debug log\</em\> is 2 megabytes.\<br /\>
\<br /\>
The default \<em\>monitoring level\</em\> for \<em\>Apex code\</em\> in fact include a lot of clutter that most of the time you won&#39;t need (like METHOD_ENTRY, METHOD_EXIT), and by common practice, you should put a \<em\>log filter\</em\> on the \<em\>monitored user\</em\>, or the \<em\>classes \</em\>involved in the transaction by putting and \<em\>override flag\</em\> on them.\</p\>
\
Unluckily, at time of writing, the platform does not allow fine-tuning of \<em\>log levels\</em\>. Whilst the first is specific to your monitoring sessions, the second will affect every process or \<em\>user\</em\>. My advice is to remove any \<em\>class\</em\> level filter override after use.\<br /\>
\<br /\>
One approach I find particularly useful when trying to pop-up informations from a saturated result, consists in setting the \<em\>Apex code\</em\> filter level from DEBUG (which is default) to INFO and set the \<em\>System\</em\> to write my debugs in the less cluttered \<em\>logging level\</em\>, this way:\</p\>
\
\<code class="java"\>System.debug(LoggingLevel.INFO, myVar);\</code\>\</pre\>Thu, 18 Jul 2013 11:02:00 GMThttp://andreaazzola.com/salesforce-debug-log-apex

Future count with Apex Code

http://andreaazzola.com/future-count-apex/.A simple snippet for counting @future calls in a 24 hours timespan, may be useful for monitoring peaks and act accordingly.
Please note: supports up to 50000 future calls in a 24h timespan
public with sharing class AsyncApexJobUtils {
public static integer futureCount() {
integer c = \[select count() from AsyncApexJob
where JobType=&#39;Future&#39;
and CreatedDate &gt;=…\
.A simple snippet for counting @future calls in a 24 hours timespan, may be useful for monitoring peaks and act accordingly.\</p\>
\
\\\<strong\>Please note\</strong\>: supports up\ \to 50000\ f\uture\\ calls in a 24h timespan\</p\>
\
\<code class="java"\>public with sharing class AsyncApexJobUtils {
public static integer futureCount() {
integer c = \[select count() from AsyncApexJob
where JobType=&#39;Future&#39;
and CreatedDate &gt;= :Datetime.now().addDays(-1) limit 50000\];
system.debug(&#39;#futureCount: &#39; + c);
return c;
}
}\</code\>\</pre\>
\
 \</p\>Thu, 14 Jul 2011 11:06:00 GMThttp://andreaazzola.com/future-count-apex

Simulating a RequiredFieldValidator when using a RadComboBox

http://andreaazzola.com/requiredfieldvalidator-radcombobox/Telerik&#39;s RadComboBox does not behave like a traditional DropDownList. You may consider to use a CustomValidator instead, here is the code:
Step 1: Markup
&lt;asp:Label ID=&quot;lblExample&quot; runat=&quot;server&quot; AssociatedControlID=&quot;rcbExample&quot;
Text=&quot;Example&quot; /&gt;
&lt;telerik:RadComboBox ID=&quot;rcbExample&quot; runat=&quot;server&quot;…\
Telerik&#39;s \<a href="http://www.telerik.com/products/aspnet-ajax/combobox.aspx" target="\_blank"\>RadComboBox\</a\> does not behave like a traditional \<a href="http://msdn.microsoft.com/en-us/library/system.web.ui.webcontrols.dropdownlist.aspx" target="\_blank"\>DropDownList\</a\>. You may consider to use a \<a href="http://msdn.microsoft.com/en-us/library/system.web.ui.webcontrols.customvalidator.aspx" target="\_blank"\>CustomValidator \</a\>instead, here is the code:
\</p\>
\<h2\>Step 1: Markup\</h2\>
\
\<code class="html"\>&lt;asp:Label ID=&quot;lblExample&quot; runat=&quot;server&quot; AssociatedControlID=&quot;rcbExample&quot;
Text=&quot;Example&quot; /&gt;
&lt;telerik:RadComboBox ID=&quot;rcbExample&quot; runat=&quot;server&quot; /&gt;
&lt;asp:CustomValidator ID=&quot;cvlExample&quot; runat=&quot;server&quot; ControlToValidate=&quot;rcbExample&quot;
Text=&quot;\*&quot; ClientValidationFunction=&quot;cvlExampleValidate&quot;
OnServerValidate=&quot;cvlExample_ServerValidate&quot; /&gt;\</code\>\</pre\>
\
\<h2\>Step 2: Client-side validation:\</h2\>
\
\<code class="javascript"\>function cvlExampleValidate(source, args) {
args.IsValid = radComboValidate(&quot;&lt;%= rcbExample.ClientID %&gt;&quot;);
}
function radComboValidate(controlName) {
var combo = \$find(controlName);
var text = combo.get_text();
if (text.length &lt; 1)
return false;
else {
var node = combo.findItemByText(text);
if (node) {
var value = node.get_value();
if (value.length &gt; 0)
return true;
}
else
return false;
}
}\</code\>\</pre\>
\<h2\>Step 3: Server-side valitation:\</h2\>
\
\<code class="cs"\>protected void cvlStatus_ServerValidate(object source, ServerValidateEventArgs args)
{
args.IsValid = rcbStatus.SelectedValue.Length &gt; 0;
}\</code\>\</pre\>Fri, 22 Oct 2010 13:44:00 GMThttp://andreaazzola.com/requiredfieldvalidator-radcombobox

Turn Sentences into Slugs with JavaScript

http://andreaazzola.com/transform-sentence-slug-js/The script allows you to turn a text string into a proper URL slug. It&#39;s a mix of both jQuery and standard JavaScript, thought it can be easily turned into pure JS.
// Handles typing
\$(document).ready(function () {
// If the Title is specified, avoids overwrite
if (\$(&#39;controlId&#39;).val().length == 0) {
\$(&#39;controlId&#39;).keypress(function ()…\
The script allows you to turn a \<em\>text string\</em\> into a proper \<a href="http://en.wikipedia.org/wiki/Slug\_%28web_publishing%29" target="\_blank" title="Definition of URL slug"\>URL slug\</a\>. It&#39;s a mix of both \<a href="http://jquery.com" target="\_blank"\>jQuery\</a\> and standard \<a href="/category/javascript" target="\_blank" title="JavaScript posts"\>JavaScript\</a\>, thought it can be easily turned into pure JS.  \</p\>
\
\<code class="javascript"\>// Handles typing
\$(document).ready(function () {
// If the Title is specified, avoids overwrite
if (\$(&#39;controlId&#39;).val().length == 0) {
\$(&#39;controlId&#39;).keypress(function () {
\$(&#39;controlId&#39;).val(slugify(\$(&#39;controlId&#39;).val().toLowerCase()));
});
}
});
// Replacements
function slugify(text) {
text = text.replace(/\[^-a-zA-Z0-9,&amp;\s\]+/ig, &#39;&#39;);
text = text.replace(/-/gi, &quot;\_&quot;);
text = text.replace(/\s/gi, &quot;-&quot;);
return text;
}\</code\>\</pre\>Wed, 20 Oct 2010 15:56:00 GMThttp://andreaazzola.com/transform-sentence-slug-js

New DJ Set! September 2010 for MaGmA Radio Sho

http://andreaazzola.com/set-september-2010/Here's my DJ set aired in September 2010 for the MaGmA Radio Show:
September 2010 - MaGmA by Icaro on Mixcloud
Tracklist
Niala'kil - World Office (NK 2010 Edit) \[Big Mama's House Records\]
Davide Squillace - Cubism \[Desolat\]
Loco Dice - Definition \[Desolat\]
DJ Vibe, Carlos Fauvrelle, Alan T - Hot Room feat. Alan T (Oscar G Tropicasa Mix) \[Stereo Productions\]
Pablo Cahn -…\Here's my DJ set aired in September 2010 for the \<a href="http://www.magmaglobalgroove.com" target="\_blank" title="MaGmA Official Website"\>MaGmA Radio Show\</a\>:\</p\>
\<iframe width="660" height="180" src="https://www.mixcloud.com/widget/iframe/?feed=http%3A%2F%2Fwww.mixcloud.com%2Ficaro%2Fseptember-2010-magma%2F&amp;embed_uuid=b7135189-1035-4d8b-a3cc-56336aa8278e&amp;replace=0&amp;hide_cover=1&amp;embed_type=widget_standard&amp;hide_tracklist=1" frameborder="0"\>\</iframe\>\
\
\\<a href="http://www.mixcloud.com/icaro/september-2010-magma/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=resource_link" target="\_blank" style="color:#808080; font-weight:bold;"\>September 2010 - MaGmA\</a\>\ by \\<a href="http://www.mixcloud.com/icaro/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=profile_link" target="\_blank" style="color:#808080; font-weight:bold;"\>Icaro\</a\>\ on \\<a href="http://www.mixcloud.com/?utm_source=widget&amp;utm_medium=web&amp;utm_campaign=base_links&amp;utm_term=homepage_link" target="\_blank" style="color:#808080; font-weight:bold;"\> Mixcloud\</a\>\</p\>\
\

\<h2\>Tracklist\</h2\>
\

\- Niala'kil - World Office (NK 2010 Edit) \[Big Mama's House Records\]\</li\>
\- Davide Squillace - Cubism \[Desolat\]\</li\>
\- Loco Dice - Definition \[Desolat\]\</li\>
\- DJ Vibe, Carlos Fauvrelle, Alan T - Hot Room feat. Alan T (Oscar G Tropicasa Mix) \[Stereo Productions\]\</li\>
\- Pablo Cahn - Elle \[Cadenza\]\</li\>
\- Nick Curly - Aymara \[8bit\]\</li\>
\- Robyn - Hang With Me (Kaiserdisco Remix) \[Konichiwa Records\]\</li\>
\- Santos, Alex Dolby - No Walls (Maher Daniel Remix) \[Bedrock Records\]\</li\>
\- Forty Fingerz - Wizard \[Receive Records\]\</li\>
\- Marshall - Just Believe \[303Lovers\]\</li\>
\- Monika Kruse - Wavedancer (Pig & Dan Remix) \[Ministry Of Sound\]\</li\>
\

\<h2\>Contacts\</h2\>
\
Info &amp; Remix enquires: icaro \[at\] icaro.dj\<br /\>
Booking: icaro \[at\] icaro.dj
\</p\>Sat, 04 Sep 2010 08:00:00 GMThttp://andreaazzola.com/set-september-2010

New DJ Set! June 2010 for the MaGmA Radio Sho

http://andreaazzola.com/set-june-2010/Here's my DJ set aired in June 2010 on the MaGmA Radio Show:
June 2010 - MaGmA by Icaro on Mixcloud
Tracklist
Ben Watt, Stimming, Julia Biel - Bright Star \[Buzzin' Fly Records\]
Pleasurekraft - Tarantula \[Eklektisch\]
Findling, Lihab - Stay Down \[Kindish\]
Filthy Rich - Deeper (Original Club Mix) \[Toolroom\]
SKJG Project - Tenerife Y La Gomera \[Cr2 Records\]
Anil Chawla - Do…\Here's my DJ set aired in June 2010 on the \<a href="http://www.magmaglobalgroove.com" target="\_blank" title="MaGmA Official Website"\>MaGmA Radio Show\</a\>:\</p\>
\<iframe width="660" height="180" src="https://www.mixcloud.com/widget/iframe/?feed=http%3A%2F%2Fwww.mixcloud.com%2Ficaro%2Fjune-2010-magma%2F&amp;embed_uuid=d339c4ee-ff3b-4d9b-927b-e12d8fefbe0f&amp;replace=0&amp;hide_cover=1&amp;embed_type=widget_standard&amp;hide_tracklist=1" frameborder="0"\>\</iframe\>\
\
\\<a href="http://www.mixcloud.com/icaro/june-2010-magma/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=resource_link" target="\_blank" style="color:#808080; font-weight:bold;"\>June 2010 - MaGmA\</a\>\ by \\<a href="http://www.mixcloud.com/icaro/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=profile_link" target="\_blank" style="color:#808080; font-weight:bold;"\>Icaro\</a\>\ on \\<a href="http://www.mixcloud.com/?utm_source=widget&amp;utm_medium=web&amp;utm_campaign=base_links&amp;utm_term=homepage_link" target="\_blank" style="color:#808080; font-weight:bold;"\> Mixcloud\</a\>\</p\>\
\

\<h2\>Tracklist\</h2\>
\

\- Ben Watt, Stimming, Julia Biel - Bright Star \[Buzzin' Fly Records\]\</li\>
\- Pleasurekraft - Tarantula \[Eklektisch\]\</li\>
\- Findling, Lihab - Stay Down \[Kindish\]\</li\>
\- Filthy Rich - Deeper (Original Club Mix) \[Toolroom\]\</li\>
\- SKJG Project - Tenerife Y La Gomera \[Cr2 Records\]\</li\>
\- Anil Chawla - Do It \[Great Stuff Recordings\]\</li\>
\- Flavio Diaz, Kaiserdisco - Jaune \[Drumcode\]\</li\>
\- Afrojack, Bobby Burns - Ghettoblaster \[Tiger Records\]\</li\>
\- Disco Trek - Cuemba (Slicerboys Remix) \[Whitepromo\]\</li\>
\- Kaskade, Haley - Dynasty feat. Haley (Dada Life) \[Ultra\]\</li\>
\- Aaren San - Apes From Space (Dirtyloud Remix) \[Aelaektropopp\]\</li\>
\

\<h2\>Contacts\</h2\>
\
Info &amp; Remix enquires: icaro \[at\] icaro.dj\<br /\>
Booking: icaro \[at\] icaro.dj
\</p\>Mon, 14 Jun 2010 02:02:00 GMThttp://andreaazzola.com/set-june-2010

Import Web service References in .NET

http://andreaazzola.com/web-service-reference-vs/WARNING: the content of this post has been flagged as "out of date" by the author
You may need to consume Web services from client applications. Visual Studio provides tools for generating proxy classes, which in this case, however, may be ineffective.
The wsdl.exe tool
You can use the command prompt tool wsdl.exe included within the NET Framework 2.0 SDK. This tool accepts the…\WARNING: the content of this post has been flagged as "out of date" by the author\
\
You may need to consume \<a href="http://en.wikipedia.org/wiki/Web_service" target="\_blank"\>Web services\</a\> from  client applications. \<a href="http://msdn.microsoft.com/en-us/vstudio/default.aspx" target="\_blank"\>Visual Studio\</a\> provides tools for generating proxy classes, which in this case, however, may be ineffective.
\</p\>
\<h2\>The wsdl.exe tool\</h2\>
\
You can use the \<a href="http://en.wikipedia.org/wiki/Cmd" target="\_blank"\>command prompt\</a\> tool \<em\>wsdl.exe\</em\> included within the \<a href="http://www.microsoft.com/downloads/details.aspx?displaylang=en&amp;FamilyID=fe6f2099-b7b4-4f47-a244-c96d69c35dec" id="jnk9" target="\_blank" title="NET Framework 2.0 SDK"\>NET Framework 2.0 SDK\</a\>. This tool accepts the path to a \<a href="http://en.wikipedia.org/wiki/Web_Services_Description_Language" target="\_blank"\>WSDL\</a\> file and generates the proxy class automatically.
\</p\>
\<h2\>Example\</h2\>
\\<code\>&quot;C:\Program Files\Microsoft SDKs\Windows\v6.0A\bin\wsdl.exe&quot;\_
  &quot;C:\ServiceTest.wsdl&quot; /n:MyNameSpace.MyServices /o:&quot;C:\ServiceTest.cs&quot; /l:CS\</code\>\</pre\>
\In this example we're saying:\</p\>
\

\- The path of the WSDL\</li\>
\- &quot;/n&quot; - the target namespace of the proxy class\</li\>
\- &quot;/o&quot; - the path of output files\</li\>
\- &quot;/l&quot; - the target language\</li\>
\

\
A complete list of options is available at this Url:\<br /\>
\<a href="http://msdn.microsoft.com/en-gb/library/7h3ystb6%28v=VS.80%29.aspx" target="\_blank"\>http://msdn.microsoft.com/en-gb/library/7h3ystb6%28v=VS.80%29.aspx\</a\>\<br /\>
If you plan on generation more files related to classes in the same namespace, is useful to remember that some objects are implicitly declared many times, these duplicates must be removed manually.
\</p\>
\<h2\>Related articles:\</h2\>
\

\- \<a href="http://articles.techrepublic.com.com/5100-10878_11-5755966.html" target="\_blank" title="Testing a Web service with a proxy class"\>Testing a Web service with a proxy class\</a\>\</li\>
\
Wed, 09 Jun 2010 13:13:00 GMThttp://andreaazzola.com/web-service-reference-vs

How to log HTTP requests with PHP

http://andreaazzola.com/log-http-requests/The Problem
Sometimes you need to understand precisely how the HTTP request is submitted to the server. If you&#39;re working with Salesforce.com, you probably don&#39;t have easy or intuitive tools to understand how a message is serialized and sent by the runtime to the server.
The Solution
I&#39;ve put togheter this little script that allows you to draw all HTTP requests to a…\<h2\>The Problem\</h2\>
\
Sometimes you need to understand \<strong\>precisely \</strong\>how the \<a href="http://en.wikipedia.org/wiki/Http#Client_request" target="\_blank" title="See what HTTP request means on WikiPedia"\>HTTP request\</a\> is submitted to the \<strong\>server\</strong\>. If you&#39;re working with \<a href="http://www.salesforce.com" title="Go to Salesforce.com"\>Salesforce.com\</a\>, you probably don&#39;t have easy or intuitive tools to understand how a message is \<strong\>serialized \</strong\>and sent by the runtime to the \<strong\>server\</strong\>.
\</p\>
\<h2\>The Solution\</h2\>
\
I&#39;ve put togheter this little script that allows you to draw all \<a href="http://en.wikipedia.org/wiki/Http#Client_request" target="\_blank" title="See what HTTP request means on WikiPedia"\>HTTP request\</a\>s to a file. Becomes so much easier to verify the output sent to a \<a href="http://en.wikipedia.org/wiki/Web_service" target="\_blank" title="See what web service means on WikiPedia"\>web service\</a\>.\</p\>
\
\<code class="php"\>&lt;?php
\$myFile = &quot;requestslog.txt&quot;;
\$fh = fopen(\$myFile, &#39;a&#39;) or die(&quot;can&#39;t open file&quot;);
fwrite(\$fh, &quot;\n\n--------------------------------------
-------------------------\n&quot;);
foreach(\$\_SERVER as \$h=&gt;\$v)
if(ereg(&#39;HTTP\_(.+)&#39;,\$h,\$hp))
fwrite(\$fh, &quot;\$h = \$v\n&quot;);
fwrite(\$fh, &quot;\r\n&quot;);
fwrite(\$fh, file_get_contents(&#39;php://input&#39;));
fclose(\$fh);
echo &quot;&lt;html&gt;&lt;head /&gt;&lt;body&gt;&lt;iframe src=\\quot;\$myFile\\quot;
style=\\quot;height:100%; width:100%;\\quot;&gt;&lt;/iframe&gt;&lt;/body&gt;&lt;/html&gt;&quot;
?&gt;\</code\>\</pre\>
\
This applies to all requests that travel with the \<a href="http://en.wikipedia.org/wiki/Http" target="\_blank" title="See what HTTP protocol means on WikiPedia"\>HTTP protocol\</a\>, even \<a href="http://en.wikipedia.org/wiki/SOAP" target="\_blank" title="See what SOAP means on WikiPedia"\>SOAP\</a\> for instance.
\</p\>Thu, 27 May 2010 18:11:00 GMThttp://andreaazzola.com/log-http-requests

April 2010 - MaGmA Radio Show

http://andreaazzola.com/set-april-2010/Here's my DJ set aired in April 2010 on the MaGmA Radio Show:
April 2010 - MaGmA by Icaro on Mixcloud
Tracklist
Steed Lord - You (Keinekemusik Remix) \[Get Physical Music\]
Kaiserdisco - Amalfino \[MBF\]
Jay Lumen, Umek - Sinful Ladies \[Great Stuff Recordings\]
Kaiserdisco - Aguja \[MBF\]
Meat Katie - Lucia (Flavio Diaz Remix) \[LOT49\]
Lissat, Voltaxx - 8 Days In Kazantip…\Here's my DJ set aired in April 2010 on the \<a href="http://www.magmaglobalgroove.com" target="\_blank" title="MaGmA Official Website"\>MaGmA Radio Show\</a\>:\</p\>
\<iframe width="660" height="180" src="https://www.mixcloud.com/widget/iframe/?feed=http%3A%2F%2Fwww.mixcloud.com%2Ficaro%2Fapril-2010-magma%2F&amp;embed_uuid=b86bdb85-ecde-4833-92e2-93c46198a5a3&amp;replace=0&amp;hide_cover=1&amp;embed_type=widget_standard&amp;hide_tracklist=1" frameborder="0"\>\</iframe\>\
\
\\<a href="http://www.mixcloud.com/icaro/april-2010-magma/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=resource_link" target="\_blank" style="color:#808080; font-weight:bold;"\>April 2010 - MaGmA\</a\>\ by \\<a href="http://www.mixcloud.com/icaro/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=profile_link" target="\_blank" style="color:#808080; font-weight:bold;"\>Icaro\</a\>\ on \\<a href="http://www.mixcloud.com/?utm_source=widget&amp;utm_medium=web&amp;utm_campaign=base_links&amp;utm_term=homepage_link" target="\_blank" style="color:#808080; font-weight:bold;"\> Mixcloud\</a\>\</p\>\
\

\<h2\>Tracklist\</h2\>
\

\- Steed Lord - You (Keinekemusik Remix) \[Get Physical Music\]\</li\>
\- Kaiserdisco - Amalfino \[MBF\]\</li\>
\- Jay Lumen, Umek - Sinful Ladies \[Great Stuff Recordings\]\</li\>
\- Kaiserdisco - Aguja \[MBF\]\</li\>
\- Meat Katie - Lucia (Flavio Diaz Remix) \[LOT49\]\</li\>
\- Lissat, Voltaxx - 8 Days In Kazantip (Federico Milani Remix) \[303Lovers\]\</li\>
\- Duca - Home \[Tribal Vision Records\]\</li\>
\- A. Mochi - Whiplash \[Figure\]\</li\>
\- Alex Di Stefano - Something Is Moving \[Mantide Records\]\</li\>
\- Meck, Dino - Feels Like A Prayer (Michael Woods Remix) \[Toolroom Records\]\</li\>
\

\<h2\>Contacts\</h2\>
\
Info &amp; Remix enquires: icaro \[at\] icaro.dj\<br /\>
Booking: icaro \[at\] icaro.dj
\</p\>Thu, 27 May 2010 17:48:00 GMThttp://andreaazzola.com/set-april-2010

New DJ Set! February 2010 for the MaGmA Radio Show

http://andreaazzola.com/set-february-2010/Here's my DJ set aired in February 2010 on the MaGmA Radio Show:
February 2010 - MaGmA by Icaro on Mixcloud
Tracklist
Jakiro - Caveman \[eVapour8\]
Moonbeam - Tiger \[Traum\]
Lila D. - Wet (The Midnight Perverts Remix) \[Dialtone Records\]
\[a\]pendics.shuffle &amp; Dilo - Vaquero \[Trapez\]
FLOW Superstars - Special Stuff (Ian F Remix) \[Hell Yeah\]
James Kameran &amp; Joe…\Here's my DJ set aired in February 2010 on the \<a href="http://www.magmaglobalgroove.com" target="\_blank" title="MaGmA Official Website"\>MaGmA Radio Show\</a\>:\</p\>
\<iframe width="660" height="180" src="https://www.mixcloud.com/widget/iframe/?feed=http%3A%2F%2Fwww.mixcloud.com%2Ficaro%2Ffebruary-2010-magma%2F&amp;embed_uuid=5b6edd97-532a-4cd8-8c1c-88a726d73cd9&amp;replace=0&amp;hide_cover=1&amp;embed_type=widget_standard&amp;hide_tracklist=1" frameborder="0"\>\</iframe\>\
\
\\<a href="http://www.mixcloud.com/icaro/february-2010-magma/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=resource_link" target="\_blank" style="color:#808080; font-weight:bold;"\>February 2010 - MaGmA\</a\>\ by \\<a href="http://www.mixcloud.com/icaro/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=profile_link" target="\_blank" style="color:#808080; font-weight:bold;"\>Icaro\</a\>\ on \\<a href="http://www.mixcloud.com/?utm_source=widget&amp;utm_medium=web&amp;utm_campaign=base_links&amp;utm_term=homepage_link" target="\_blank" style="color:#808080; font-weight:bold;"\> Mixcloud\</a\>\</p\>\
\

\<h2\>Tracklist\</h2\>
\

\- Jakiro - Caveman \[eVapour8\]\</li\>
\- Moonbeam - Tiger \[Traum\]\</li\>
\- Lila D. - Wet (The Midnight Perverts Remix) \[Dialtone Records\]\</li\>
\- \[a\]pendics.shuffle &amp; Dilo - Vaquero \[Trapez\]\</li\>
\- FLOW Superstars - Special Stuff (Ian F Remix) \[Hell Yeah\]\</li\>
\- James Kameran &amp; Joe Smilovitch - Time \[Amazone13\]\</li\>
\- 4D - Amped \[4DigitalAudio\]\</li\>
\- Denis A - Heroine \[DAR\]\</li\>
\- Peter Horrevorts &ndash; Bloody Hands \[Gem Records\]\</li\>
\- Perfect Stranger - Prata da Casa (Ritkam &amp; Bansi Remix) \[Flow Vinyl\]\</li\>
\
Sun, 07 Feb 2010 18:44:00 GMThttp://andreaazzola.com/set-february-2010

Improve ASP.NET SEO by using System.Web.Routing

http://andreaazzola.com/seo-asp-net-routing/This page is specific to Microsoft Visual Studio 2008/.NET Framework 3.5 or higher
SEO and ASP.NET
&quot;As an Internet marketing strategy, SEO considers how search engines work and what people search for. Optimizing a website primarily involves editing its content and HTML indexing activities of search engines.&quot; \[source: wikipedia.org\]
Search Engine Friendly URLs vs "Dirty"…\\This page is specific to Microsoft Visual Studio 2008/.NET Framework 3.5 or higher\\</p\>
\<h2\>SEO and ASP.NET\</h2\>
&quot;\<i\>As an \<a href="http://en.wikipedia.org/wiki/Internet_marketing" title="Internet marketing"\>Internet marketing\</a\> strategy, SEO considers how search engines work and what people search for. Optimizing a website primarily involves editing its content and \<a href="http://en.wikipedia.org/wiki/HTML" title="HTML"\>HTML\</a\> \<a href="http://en.wikipedia.org/wiki/Web_crawler" title="Web crawler"\>indexing activities\</a\> of search engines.\</i\>&quot; \[source: \<a href="http://en.wikipedia.org/wiki/Search_engine_optimization" id="d5rp" title="wikipedia.org"\>wikipedia.org\</a\>\]
\<h2\>Search Engine Friendly URLs vs "Dirty" URLs\</h2\>
\Current URL will be taken as example\</p\>
\

\- SEF URL\</li\>: http://AndreaAzzola.com/seo-asp-net-routing\<br /\>
\- RAW URL\</li\>: http://AndreaAzzola.com/Post.aspx?id=cd171f7c-560d-4a62-8d65-16b87419a58c
\

\ \<strong\>SEFs are better to write, remember, understand and mantain\</strong\>. In the example above you can understand immediatly what the resource is about but the RAW version is difficult to read and almost impossible to rember.\</p\>
\<h2\>Implementation\</h2\>
\ASP.NET offers a great resource called &#39;System.Web.Routing&#39;, it support routes. Routes translates both the pattern you define and the context parameters, into an intelligible request. In the following example you will find:\</p\>
\

\- How to enable routing on your web application\</li\>
\- A class that handle routes by implementing IRouteHandler\</li\>
\- How to initialize routes when your application starts\</li\>
\- How to pass values in a clean and robust manner\</li\>
\

\<h3\>#1 File Web.config\</h3\>
\\<code class="xml"\>&lt;system.web&gt;
...
&lt;add name=&quot;RoutingModule&quot; type=&quot;System.Web.Routing.UrlRoutingModule&quot; /&gt;
&lt;/system.web&gt;\</code\>\</pre\>
\<h3\>#2 File Global.asax\</h3\>
\\<code class="cs"\>public class EnhancedRouteHandler : IRouteHandler
{
string \_pageURL;
public EnhancedRouteHandler(string pageURL)
{
\_pageURL = pageURL;
}
public IHttpHandler GetHttpHandler(RequestContext requestContext)
{
IRoutePage page =
BuildManager.CreateInstanceFromVirtualPath(\_pageURL,
typeof(IRoutePage)) as IRoutePage;
page.Parameters = requestContext.RouteData.Values;
return page;
}
}\</code\>\</pre\>
\<h3\>#3 File Global.asax\</h3\>
\\<code class="cs"\>protected void Application_Start(object sender, EventArgs e)
{
RegisterRoutes(RouteTable.Routes);
}
public static void RegisterRoutes(RouteCollection routes)
{
routes.Add(new Route(string.Empty,
new EnhancedRouteHandler(&quot;~/Default.aspx&quot;))); // nothing after domain name
routes.Add(new Route(&quot;post/{slug}&quot;,
new EnhancedRouteHandler(&quot;~/Post.aspx&quot;))); // post followed by his slug
routes.Add(new Route(&quot;twitter-mutuality&quot;,
new EnhancedRouteHandler(&quot;~/Apps/Mutuality.aspx&quot;))); // a fixed path
routes.Add(new Route(&quot;{\*catchall}&quot;,
new EnhancedRouteHandler(&quot;~/Error.aspx&quot;))); // catchall
}\</code\>\</pre\>
\The catchall part works whenever the engine does not find a suitable resource or route for the request, this behaviour is extremely helpful expecially when dealing with 404 error or moved resources.\</p\>
\<h3\>#4 File App_Code\IRoutePage.cs\</h3\>
\\<code class="cs"\>using System.Web;
using System.Web.Routing;
public interface IRoutePage : IHttpHandler
{
RouteValueDictionary Parameters { get; set; }
}\</code\>\</pre\>
\By using this code you are obliged to inherit in each page you want to route to, and you should implement the Parameters field as well, however it doesn&#39;t require you to expose unappropriate querystrings or dangerous sessions that would damage the aesthetics of your code :D. Be aware, this won&#39;t cover all the possible test cases, but it would help with the most of them.\</p\>
\<h2\>In Conclusion\</h2\>
\ In recent years we have witnessed a turnaround in the development of web-applications, especially since the technology made it possible to enlarge the catchment area, just think about mobile, MID/Netbook sales growth, disadvantage people... this has helped to promote a web simple and functional at the expense of a powerful web, but less usable.\</p\>
\SEFs are an important way to catch the guest&#39;s attention, please consider for example the Google&#39; results page, search anything you want, and think about the link you&#39;ll choose, the clean one, or the dirty one? Not all clean URLs are the most attractives yet, but there are a good changes you will choose the simple one, this would mean an important point for your SEO score.\</p\>Mon, 18 Jan 2010 20:57:00 GMThttp://andreaazzola.com/seo-asp-net-routing

Asus EeePC 1201HA review

http://andreaazzola.com/asus-eeepc-1201ha/First look
The EeePC 1201HA is part of a new generation of big netbooks, that refers to not just the hardware that accompanies them as far as the size, in fact, this netbook has a 12.1 inch monitor.
It comes with Windows 7 but in some cases with XP, provides opportunities for overclocking, can play movies in HD (decently up to 720p) with no trouble, has 2GB of ram (IMHO very…\\![](/images/resource)\</p\>
\<h2\>First look\</h2\>
\The EeePC 1201HA is part of a new generation of big netbooks, that refers to not just the hardware that accompanies them as far as the size, in fact, this netbook has a 12.1 inch monitor.\</p\>
\It comes with Windows 7 but in some cases with XP, provides opportunities for overclocking, can play movies in HD (decently up to 720p) with no trouble, has 2GB of ram (\<em\>IMHO very valuable\</em\>) 160GB of hard disk (+500 online, free for the first year), isolated keys, very light, autonomy is good: 7/8 hours in standard office applications.\</p\>
\<h2\>Power On\</h2\>
\Unfortunately, the pre-installed system had some difficulties in starting, due to some missing DLLs (...), fortunately it provides a recovery CD that has helped to solve everything in a few hours, it was obviously quite alarming, in hand to the novice user in fact, the Netbook would probably have to go back to assistance.\</p\>
\The performances guaranteed by Windows 7 are good enough, the boot in some cases has outpaced that of the MacBook Pro!!, but you&#39;ll definitely need to turn off Aero and overclock the processor (I suggest 20%) and work almost always on &#39;Superperformace-mode&#39;.\</p\>
\<h2\>Peculiarities\</h2\>
\The design is simple, black never goes out of fashion, but the paint layer is very easy to smudge. It is part of the ASUS Seashell family so it&#39;s very compact and lightweight (approximately 1.5 kg). The connectivity section is good, comes with an Ethernet and WI-FI b / g / n. Nice about keyboard: you can change the way it consume/performs (Power Saving, Auto High-Performance, Super Performance, High Performance), activate the standby, turn off the monitor, activate and adjust the sound, manage your media files (rew, stop, pause / play, fwd) and activate the web-cam.\</p\>
\<h2\>Conclusion\</h2\>
\It&#39;s very quiet, the ideal PC for the simple things of everyday (e-mail, browsing, chat, downloads, file sharing, ...). I get Visual Studio 2008 running and not too bad, and Eclipse, can be used to develop but does not offer the performance of a workstation, and the relatively tiny display in the long run... may be annoying.\</p\>
\<h2\>Specs\</h2\>
\

\- Display: 12.1 inch, 1366 x 768 pixels\</li\>
\- CPU: 1.33GHz Intel Atom Z520\</li\>
\- Graphics &amp; chipset: Intel US15W / GMA 500 graphics\</li\>
\- OS: Windows 7 Home Premium\</li\>
\- Memory: 2GB DDR2\</li\>
\- Storage: 250GB HDD + 500GB web-based storage\</li\>
\- Connectivity: 802.11b/g/n WiFI, Bluetooth, Ethernet\</li\>
\- I/O: VGA, 3 USB 2.0 ports, SD card slot, mic, headphones\</li\>
\- Webcam: 0.3MP\</li\>
\- Touchpad: Supports multitouch gestures\</li\>
\- Battery: 6 cells, 8 hours\</li\>
\- Colors: Black, blue, or red\</li\>
\- Dimensions: 11.7&Prime; x 8.2&Prime; x 1.3&Prime;\</li\>
\- Weight: 3.1 pounds\</li\>
\
Sat, 09 Jan 2010 11:13:00 GMThttp://andreaazzola.com/asus-eeepc-1201ha

New DJ Set! November 2009 for the MaGmA Radio Show

http://andreaazzola.com/set-november-2009/Here's my DJ set aired in November 2009 on the MaGmA Radio Show:
November 2009 - MaGmA by Icaro on Mixcloud
Tracklist
SLOK - Freak \[Circle Music\]
Kriminal - Soon \[Nutempo Records\]
Daniele Papini - Junk Dancer \[Mija\]
Umek - S Cream (Peter Taster Remix) \[Hell Yeah\]
Mikas - Elipse (Manuel De La Mare Remix) \[Progressive Grooves\]
Manuel De La Mare - The Holy Cow \[303Lovers\]…\Here's my DJ set aired in November 2009 on the \<a href="http://www.magmaglobalgroove.com" target="\_blank" title="MaGmA Official Website"\>MaGmA Radio Show\</a\>:\</p\>
\<iframe width="660" height="180" src="https://www.mixcloud.com/widget/iframe/?feed=http%3A%2F%2Fwww.mixcloud.com%2Ficaro%2Fnovember-2009-magma%2F&amp;embed_uuid=4683b1d1-1cb7-41c2-b8ce-e91a1293894a&amp;replace=0&amp;hide_cover=1&amp;embed_type=widget_standard&amp;hide_tracklist=1" frameborder="0"\>\</iframe\>\
\
\\<a href="http://www.mixcloud.com/icaro/november-2009-magma/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=resource_link" target="\_blank" style="color:#808080; font-weight:bold;"\>November 2009 - MaGmA\</a\>\ by \\<a href="http://www.mixcloud.com/icaro/?utm_source=widget&amp;amp;utm_medium=web&amp;amp;utm_campaign=base_links&amp;amp;utm_term=profile_link" target="\_blank" style="color:#808080; font-weight:bold;"\>Icaro\</a\>\ on \\<a href="http://www.mixcloud.com/?utm_source=widget&amp;utm_medium=web&amp;utm_campaign=base_links&amp;utm_term=homepage_link" target="\_blank" style="color:#808080; font-weight:bold;"\> Mixcloud\</a\>\</p\>\
\

\<h2\>Tracklist\</h2\>
\

\- SLOK - Freak \[Circle Music\]\</li\>
\- Kriminal - Soon \[Nutempo Records\]\</li\>
\- Daniele Papini - Junk Dancer \[Mija\]\</li\>
\- Umek - S Cream (Peter Taster Remix) \[Hell Yeah\]\</li\>
\- Mikas - Elipse (Manuel De La Mare Remix) \[Progressive Grooves\]\</li\>
\- Manuel De La Mare - The Holy Cow \[303Lovers\]\</li\>
\- Alan Fitzpatrick - Static \[Drumcode\]\</li\>
\- Lissat &amp; Voltaxx - The Music And Me (Manuel De La Mare Remix) \[Leaders Of The New School\]\</li\>
\- Dave Seaman &amp; Josh Grabriel - Heyaah (Francis Preve Remix) \[Different Pieces\]\</li\>
\- Marshall, Charlie, Peter - CPM 02 \[303Lovers\]\</li\>
\- Speca, Roman, Gertz - Happy Time (Tomy Declerque Remix) \[Speca Records\]\</li\>
\- Sean Quinn - Rentless (Steve Ward Remix) \[Drum Ride Recordings\]\</li\>
\

\</li\>Tue, 22 Dec 2009 12:59:00 GMThttp://andreaazzola.com/set-november-2009

Call async methods with C#

http://andreaazzola.com/call-async-method/The article might be obsolete due to C# technology improvements
This article help you in delegating work to an asynchronous thread in C#, thus allowing for code execution and App responsitivity, but you might go a step futher implementing error notifications, polling, wait for the procedure to complete at a certain point&#8230; and so on.
Suppose you have the following method
public void…\\The article might be obsolete due to C# technology improvements\\</p\>
\This article help you in delegating work to an asynchronous thread in C#, thus allowing for code execution and App responsitivity, but you might go a step futher implementing error notifications, polling, wait for the procedure to complete at a certain point&#8230; and so on.\</p\>
\Suppose you have the following method\</p\>
\
\<code class="cs"\>public void UploadFile(string path)
{
try
{
//... uploads some file to the server
}
catch(Exception ex)
{
// ... handle errors
}
}\</code\>\</pre\>
\And you are implementing it as a web service: you are asked to give an immediate response and upload the file \<em\>asynchronously\</em\>, the user won't use soon, as she only needs the upload.\</p\>
\<h3\>Declare a method delegate\</h3\>
\\<code class="js"\>public delegate void UploadFileDelegate(string path);\</code\>\</pre\>
\<h3\>Invoke it asynchronously\</h3\>
\\<code class="cs"\>\[WebMethod\]
public bool GetFile(string path)
{
try
{
UploadFileDelegate uid = UploadFile;
IAsyncResult rsl = uid.BeginInvoke(path, null, null);
return true;
}
catch(Exception ex)
{
return false;
}
}\</code\>\</pre\>
\The \<em\>BeginInvoke\</em\> method start the thread but allows for the code to execute further without waiting for an immediate return.\</p\>
Thu, 15 Oct 2009 10:50:00 GMThttp://andreaazzola.com/call-async-method

POST data with JavaScript

http://andreaazzola.com/post-data-js/The HTML 4.0 specs
If the method is &quot;get&quot; - -, the user agent takes the value of action, appends a ? to it, then appends the form data set, encoded using the application/x-www-form-urlencoded content type. The user agent then traverses the link to this URI. In this scenario, form data are restricted to ASCII codes.
If the method is &quot;post&quot; --, the user agent…\
\<b\>The \<a href="http://www.w3.org/TR/html401/" target="\_blank" title="HTML 4.0 specifications by W3C reccomendation"\>HTML 4.0 specs\</a\>\</b\>\</p\>
\

\- If the method is &quot;get&quot; - -, the user agent takes the value of action, appends a ? to it, then appends the form data set, encoded using the application/x-www-form-urlencoded content type. The user agent then traverses the link to this URI. In this scenario, form data are restricted to ASCII codes.\</li\>
\- If the method is &quot;post&quot; --, the user agent conducts an HTTP post transaction using the value of the action attribute and a message created according to the content type specified by the enctype attribute.\</li\>
\

\
\<b\>What are the benefits of performing POSTs via JavaScript?\</b\>\</p\>
\

\- Perform redirects programmatically\</li\>
\- Post data without annoying the user\</li\>
\- Avoid the misuse of query string and beautify URLs\</li\>
\

\<h2\>The &#39;post&#39; function\</h2\>
\
Copy and paste the following code in the \<a href="http://en.wikipedia.org/wiki/HTML_element" target="\_blank" title="HEAD section on Wikipedia"\>HEAD\</a\> section of your \<a href="http://en.wikipedia.org/wiki/Html" target="\_blank" title="HTML on Wikipedia"\>HTML\</a\> page\</p\>
\
\<code class="javascript"\>&lt;script language=&quot;javascript&quot;&gt;
function post(dictionary, url, method) {
method = method \|\| &quot;post&quot;; // post (set to default) or get
// Create the form object
var form = document.createElement(&quot;form&quot;);
form.setAttribute(&quot;method&quot;, method);
form.setAttribute(&quot;action&quot;, url);
// For each key-value pair
for (key in dictionary) {
//alert(&#39;key: &#39; + key + &#39;, value:&#39; + dictionary\[key\]); // debug
var hiddenField = document.createElement(&quot;input&quot;);
hiddenField.setAttribute(&quot;type&quot;, &quot;hidden&quot;);
hiddenField.setAttribute(&quot;name&quot;, key);
hiddenField.setAttribute(&quot;value&quot;, dictionary\[key\]);
// append the newly created control to the form
form.appendChild(hiddenField);
}
document.body.appendChild(form); // inject the form object into the body section
form.submit();
}
&lt;/script&gt;\</code\>\</pre\>
\
\<b\>How do I use it?\</b\>\<br /\>
Copy the following code in the \<a href="http://en.wikipedia.org/wiki/Body_text#Document_elements" target="\_blank" title="BODY section on Wikipedia"\>BODY\</a\> section of your HTML page.\<br /\>
As you can see a dictionary object is declared as first, then two parameters are added.\<br /\>
You can add as many parameters as you need.\</p\>
\
\<code\>&lt;script language=&quot;javascript&quot;&gt;
var myDictionary = \[\];
myDictionary\[&quot;1stKey&quot;\] = &quot;1stValue&quot;;
myDictionary\[&quot;2ndKey&quot;\] = &quot;2ndValue&quot;;
&lt;/script&gt;
&lt;input type=&quot;button&quot; value=&quot;Click me to POST&quot;
onclick=&quot;javascript:post(myDictionary, &#39;destination.html&#39;);&quot; /&gt;
&lt;input type=&quot;button&quot; value=&quot;Click me to GET&quot;
onclick=&quot;javascript:post(myDictionary, &#39;destination.html&#39;, &#39;get&#39;);&quot; /&gt;\</code\>\</pre\>
\
The post function accepts a \<a href="http://en.wikipedia.org/wiki/Associative_array" target="\_blank" title="Associative array on Wikipedia"\>dictionary\</a\> object, a destination \<a href="http://en.wikipedia.org/wiki/Url" target="\_blank" title="Uniform Resource Locator on Wikipedia"\>URL\</a\>, and optionally, the method (post or get, case in-sensitive).\</p\>
\<h2\>The jQuery.post() alternative\</h2\>
\If \<em\>jQuery \</em\>is already part of your solution, you may want to try the \<em\>jQuery.post()\</em\> approach instead:\</p\>
\
\<code class="javascript"\>jQuery.post( url \[, data \] \[, success(data, textStatus, jqXHR) \] \[, dataType \] )
\</code\>\</pre\>
\
which is a \<dfn\>\<abbr title="Abbreviated writing"\>shorthand\</abbr\>\</dfn\> for the Ajax function:\</p\>
\
\<code class="javascript"\>\$.ajax({
type: &quot;POST&quot;,
url: url,
data: data,
success: success,
dataType: dataType
});\</code\>\</pre\>
\
So, the equivalent \<em\>jQuery \</em\>code for \<em\>POST\</em\>ing the above-mentioned values would be:\</p\>
\
\<code class="javascript"\>\$.post( &quot;test.php&quot;, { 1stKey: &quot;1stValue&quot;, 2ndKey: &quot;2ndValue&quot; } );\</code\>\</pre\>
\
Further details about \<em\>jQuery.post()\</em\> function can be found \<a href="http://api.jquery.com/jquery.post/" target="\_blank" title="jQuery.post() wiki"\>here\</a\>\</p\>Tue, 07 Jul 2009 12:07:00 GMThttp://andreaazzola.com/post-data-js

Sennheiser HD 25-II headphones review

http://andreaazzola.com/sennheiser-hd-25-review/What you get
Headphones
Bag
Replacement ear pads
Adapter to 6.3 mm stereo jack plug
My impressions
I first heard about this model from a professional producer a while ago. Although Sennheiser is one of the most renowned headphone manifacturers, competition was high and so the offer. Since I was a beginner I took the advice. Lots of years have passed since then, and…\<h2\>What you get\</h2\>
\

\- Headphones\</li\>
\- Bag\</li\>
\- Replacement ear pads\</li\>
\- Adapter to 6.3 mm stereo jack plug\</li\>
\

\<h2\>My impressions\</h2\>
\I first heard about this model from a professional producer a while ago. Although Sennheiser is one of the most renowned headphone manifacturers, competition was high and so the offer. Since I was a beginner I took the advice. Lots of years have passed since then, and they're still one of the best DJ/producer headphone you can get. Mine doesn't have a single scratch, although they had a pretty 'intense' life.\</p\>
\\![](/images/posts/sennheiser-hd-25-review.jpg)\</p\>
\So, here are the pros and cons I found after this prolonged use of 'stress testing':\</p\>
\<h3\>Pros\</h3\>
\

\- Comfortable and lightweight, I've been able to use them for hours\</li\>
\- Mostly flat response\</li\>
\- Great sound quality is great at any volume\</li\>
\- Simple, classic, unmistakable\</li\>
\- Solid like a tank\</li\>
\- Low impedance, they're good for almost any MP3 player.\</li\>
\

\<h3\>Cons\</h3\>
\Price is a little high, no doubt, still, they're worth the premium.\</p\>
\<h2\>Technical Specifications:\</h2\>
\

\- Nominal impedance: 70 Ohm\</li\>
\- Load rating: 0.2 W\</li\>
\- Contact pressure: ca. 2.5 N\</li\>
\- Weight w/o cable: ca. 140 g\</li\>
\- Jack plug: 3,5/6,3 mm stereo\</li\>
\- Transducer principle: dynamic, closed\</li\>
\- Ear coupling: supraaural\</li\>
\- Cable length: 1,5 m\</li\>
\- Sound pressure level (SPL): 120 dB(SPL)\</li\>
\- THD, total harmonic distortion: &lt; 0,3 %\</li\>
\- Frequency response (headphones): 16.....22000 Hz\</li\>
\

\<h2\>Conclusions\</h2\>
\Great headphones for djs, producers and studio monitoring.\</p\>Fri, 12 Jun 2009 09:25:00 GMThttp://andreaazzola.com/sennheiser-hd-25-review

JavaScript Auto-collapsing Notification Panel

http://andreaazzola.com/js-notification-panel-gmail/In almost all web applications comes the moment when it becomes necessary to show some notifications to the user. Fairly widespread practice even when elegance was unimportant and web pages didn&#39;t show great dynamic qualities, was the use of the method alert() from JavaScript.
Nowadays, the practice of interacting with the DOM is a widespread, so you&#39;d be able to write some functions in…\In almost all web applications comes the moment when it becomes necessary to show some notifications to the user. Fairly widespread practice even when elegance was unimportant and web pages didn&#39;t show great dynamic qualities, was the use of the method \<em\>alert()\</em\> from JavaScript.\</p\>
\Nowadays, the practice of interacting with the \<a href="http://en.wikipedia.org/wiki/Document_Object_Model" target="\_blank" title="Document Object Model"\>DOM\</a\> is a widespread, so you&#39;d be able to write some functions in a more elegant, advanced and enjoyable way for the user.\</p\>
\This code behaviour you&#39;ll find below was made famous by Google mailing client \<a href="http://en.wikipedia.org/wiki/Gmail" target="\_blank" title="Gmail"\>Gmail\</a\>, is nothing exceptional and can be managed with a few simple lines of code:\</p\>
\\<code\>&lt;div id=&quot;notification&quot; class=&quot;notification&quot; style=&quot;background-color:#f8f8f8;&quot;&gt;
Hello World!!!
(&lt;a OnClick=\\quot;document.getElementById(&#39;notification&#39;).style.display=&#39;none&#39;;\\quot;&gt;close&lt;/a&gt;)
&lt;/div&gt;
function closeDiv() {
document.getElementById(&#39;notification&#39;).style.display = &#39;none&#39;;
}
&lt;input type=&quot;button&quot; value=&quot;Hide&quot; onclick=&quot;window.setTimeout(closeDiv, 5000);&quot; /&gt;\</code\>\</pre\>
\You can use CSSs to make your DIV appear like a popup, in addiction, using a graphic library like \<a href="http://jquery.com" target="\_blank" title="jQuery"\>jQuery\</a\> you can easily introduce more advanced text effects.\</p\>Fri, 29 May 2009 16:33:00 GMThttp://andreaazzola.com/js-notification-panel-gmail

Get and Set Radio controls checked value with JavaScript

http://andreaazzola.com/get-radio-checked-js/Suppose you have the following radio controls:
.csharpcode, .csharpcode pre { font-size: small; color: black; font-family: Consolas, "Courier New", Courier, Monospace; background-color: \#ffffff; /\*white-space: pre;\*/ }
.csharpcode pre { margin: 0em; }
.csharpcode .rem { color: \#008000; }
.csharpcode .kwrd { color: \#0000ff; }
.csharpcode .str { color: \#006080; }
.csharpcode .op {…\
Suppose you have the following \<b\>radio\</b\> controls:\<br /\>
\<br /\>
\<!-- code formatted by http://manoli.net/csharpformat/ --\>
\<style type="text/css"\>
.csharpcode, .csharpcode pre { font-size: small; color: black; font-family: Consolas, "Courier New", Courier, Monospace; background-color: \#ffffff; /\*white-space: pre;\*/ }
.csharpcode pre { margin: 0em; }
.csharpcode .rem { color: \#008000; }
.csharpcode .kwrd { color: \#0000ff; }
.csharpcode .str { color: \#006080; }
.csharpcode .op { color: \#0000c0; }
.csharpcode .preproc { color: \#cc6633; }
.csharpcode .asp { background-color: \#ffff00; }
.csharpcode .html { color: \#800000; }
.csharpcode .attr { color: \#ff0000; }
.csharpcode .alt { background-color: \#f4f4f4; width: 100%; margin: 0em; }
.csharpcode .lnum { color: \#606060; }
\#out {font: normal 10pt Courier,"Courier New",monospace; background: \#f5f5f5;}
.keyword {color:#0000ff;}
.object {color:#ff00ff;}
.literal {color:#cc9966;}
.comment {color:#999999;} \</style\>
\</p\>
\

\
\ 1: \\&lt;\\input\ \name\\=&quot;Book&quot;\ \type\\=&quot;radio&quot;\ \value\\=&quot;asp&quot;\ \checked\\=&quot;true&quot;\\&gt;\ASP .NET\&lt;/\\input\\&gt;&lt;\\br\ \/&gt;\\</pre\>
\
\ 2: \\&lt;\\input\ \name\\=&quot;Book&quot;\ \type\\=&quot;radio&quot;\ \value\\=&quot;wcf&quot;\ \&gt;\Windows Presentation Foundation\&lt;/\\input\\&gt;&lt;\\br\ \/&gt;\\</pre\>
\
\ 3: \\&lt;\\input\ \name\\=&quot;Book&quot;\ \type\\=&quot;radio&quot;\ \value\\=&quot;slg&quot;\ \&gt;\Silverlight 2.0\&lt;/\\input\\&gt;&lt;\\br\ \/&gt;\\</pre\>
\

\
\<br /\>
\<b\>How do you get the selected value via JavaScript?\</b\>\<br /\>
As you can see in the example, radio controls are declared in a particular way, there are no \<b\>id\</b\>s, instead there are \<b\>name\</b\>s that identifies related \<b\>radio\</b\>s.\<br /\>
You should be aware that \<i\>Book\</i\> is not treated as an unique control by the browser&#39;s engine, because each radio control correspond to one different element in the page.\<br /\>
\<br /\>
\<b\>The \<u\>getElementsByName\</u\> method\</b\>\<br /\>
\<a href="http://www.w3.org/TR/DOM-Level-2-HTML/html.html#ID-71555259" target="\_blank" title="W3C Reccomendation"\>This method\</a\> allows you to obtain a collection of controls from the (X)HTML \<a href="http://en.wikipedia.org/wiki/Document_Object_Model" target="\_blank" title="Document Object Model"\>DOM\</a\>, by specifying the common \<b\>name\</b\> value.\<br /\>
Now we can write the following code to get or set the \<b\>checked\</b\> value:\</p\>
\
 \</p\>
\
 \</p\>
\

\
\ 1: \ function getRadio(name) {\</pre\>
\
\ 2: \ var radios = document.getElementsByName(name);\</pre\>
\
\ 3: \ \</pre\>
\
\ 4: \ for (var i = 0; i &lt; radios.length; i++) {\</pre\>
\
\ 5: \ if (radios\[i\].checked) {\</pre\>
\
\ 6: \ return radios\[i\].value;\</pre\>
\
\ 7: \ }\</pre\>
\
\ 8: \ }\</pre\>
\
\ 9: \ \</pre\>
\
\ 10: \ return null;\</pre\>
\
\ 11: \ }\</pre\>
\
\ 12: \ \</pre\>
\
\ 13: \ function setRadio(name, val) {\</pre\>
\
\ 14: \ var radios = document.getElementsByName(name);\</pre\>
\
\ 15: \ \</pre\>
\
\ 16: \ for (var i = 0; i &lt; radios.length; i++) {\</pre\>
\
\ 17: \ radios\[i\].checked = (radios\[i\].value == val);\</pre\>
\
\ 18: \ }\</pre\>
\
\ 19: \ }\</pre\>
\

\
 \</p\>
\
 \</p\>Fri, 20 Mar 2009 21:25:00 GMThttp://andreaazzola.com/get-radio-checked-js

Clean Up Stored Procedures Cache with SQL Server

http://andreaazzola.com/clean-sp-cache-sql-server/When deploying a stored procedure, a clean up the db&#39;s cache might go a long way in order to apply changes immediately. Have a look to the following code:
-- Cleans up db&#39;s cache
DECLARE @dbID INTEGER
SET @dbID = (SELECT dbid FROM master.dbo.sysdatabases WHERE name = &#39;DBNameHere&#39;)
DBCC FLUSHPROCINDB (@dbID)
The DBCC FLUSHPROCINDB command allows for specifing a particular…\When deploying a stored procedure, a clean up the db&#39;s cache might go a long way in order to apply changes immediately. Have a look to the following code:\<br /\>
\\<code\>-- Cleans up db&#39;s cache
DECLARE @dbID INTEGER
SET @dbID = (SELECT dbid FROM master.dbo.sysdatabases WHERE name = &#39;DBNameHere&#39;)
DBCC FLUSHPROCINDB (@dbID)\</code\>\</pre\>
\The \<a href="http://msdn.microsoft.com/en-us/library/cc297250.aspx" target="\_blank" title="The Plan Cache"\>DBCC FLUSHPROCINDB\</a\> command allows for specifing a particular database id, and then clears all the plans from it.\</p\>Fri, 06 Mar 2009 12:30:00 GMThttp://andreaazzola.com/clean-sp-cache-sql-server

Handle Multiple Columns as One with Dynamic Data

http://andreaazzola.com/multiple-columns-dynamic-data/I need to schedule some tasks with ASP .NET and save a "Start date" and an "Interval", stored respectively as date (DateTime) and long (TimeSpan.Ticks) in my database.
Editing ticks values is not exactly what I define good UX, so I binded the proper MetaColumn, to the proper UIHint. After a few tests, I noticed how my GUI was - working, but not easy to understand as I was expecting.
I…\I need to schedule some tasks with ASP .NET and save a "Start date" and an "Interval", stored respectively as date (\<a href="http://msdn.microsoft.com/en-us/library/system.datetime.aspx" target="\_blank"\>DateTime\</a\>) and long (\<a href="http://msdn.microsoft.com/en-us/library/system.datetime.aspx" target="\_blank"\>TimeSpan.Ticks\</a\>) in my database.\</p\>
\Editing ticks values is not exactly what I define good UX, so I binded the proper \<a href="http://msdn.microsoft.com/en-us/library/system.datetime.aspx" target="\_blank"\>MetaColumn\</a\>, to the proper \<a href="http://msdn.microsoft.com/en-us/library/system.web.dynamicdata.metacolumn.uihint.aspx" target="\_blank"\>UIHint\</a\>. After a few tests, I noticed how my GUI was - working, but not easy to understand as I was expecting.\</p\>
\I decided to deeply customize the \<a href="http://msdn.microsoft.com/en-us/library/system.web.dynamicdata.fieldtemplateusercontrol.aspx" target="\_blank"\>FieldTemplateUserControl\</a\> of Dynamic Data, to display and save multiple Columns I needed (Start Date, Start Time, Occours - Daily, Weekly, Monthly.., etc...). The solution is really simple, but there are few points you may need to bear in mind:\</p\>
\<h2\>How to retrieve values (Schedule_EditField.ascx.cs)\</h2\>:
\\<code\>protected override void OnDataBinding(EventArgs e)
{
base.OnDataBinding(e);
DateTime? startFrom = (DateTime?)Eval("StartFrom");
long? timeIntervalTicks = (long?)Eval("TimeInterval");
DateTime? lastExecution = (DateTime?)Eval("LastExecution");
}\</code\>\</pre\>
\<h2\>How to store values\</h2\>
\\<code\>protected override void ExtractValues(IOrderedDictionary dictionary)
{
dictionary\["StartFrom"\] = &#8230;; //logic here
dictionary\["TimeInterval"\] = &#8230;; //logic here
}\</code\>\</pre\>Sun, 02 Nov 2008 15:50:00 GMThttp://andreaazzola.com/multiple-columns-dynamic-data

Allow the Upload of Large Files with ASP.NET

http://andreaazzola.com/upload-large-files-asp-net/I found this post while googling a bit... and I'm reporting the just the essentials, for further reference.
&lt;configuration&gt;
...
&lt;system.web&gt;
...
&lt;httpRuntime
executionTimeout="240"
maxRequestLength="16384"
useFullyQualifiedRedirectUrl="false"
minFreeThreads="8"
minLocalRequestFreeThreads="4"…\I found \<a href="http://www.codeproject.com/KB/aspnet/uploadlargefilesaspnet.aspx" title="Setting up Web.config to allow uploading of large files by ASP.net" target="\_blank"\>this post\</a\> while googling a bit... and I'm reporting the just the essentials, for further reference.\</p\>
\\<code\>&lt;configuration&gt;
...
&lt;system.web&gt;
...
&lt;httpRuntime
executionTimeout="240"
maxRequestLength="16384"
useFullyQualifiedRedirectUrl="false"
minFreeThreads="8"
minLocalRequestFreeThreads="4"
appRequestQueueLimit="100"
enableVersionHeader="true" /\>
&lt;system.web&gt;
&lt;/configuration&gt;
\</code\>\</pre\>
\This will allow for the upload of a 16mb content.\</p\>Tue, 24 Jun 2008 14:30:00 GMThttp://andreaazzola.com/upload-large-files-asp-net

Check the MetaModel Existence while Running a Dynamic Data Application

http://andreaazzola.com/check-metamodel-existence-dynamic-data-application/In the web application that I&#39;m developing using Dynamic Data, I set the DataContext at runtime, the application might bind different contexts, depending on many variables. I usually test it on two different browser, and, because of the session, I need to pass the same procedure twice. The second time, the DataContext it&#39;s already set so I don&#39;t need to register the context anymore.…\In the web application that I&#39;m developing using Dynamic Data, I set the DataContext at runtime, the application might bind different contexts, depending on many variables. I usually test it on two different browser, and, because of the session, I need to pass the same procedure twice. The second time, the DataContext it&#39;s already set so I don&#39;t need to register the context anymore. The simple condition I use:\</p\>
\\<code class="cs"\>if (System.Web.DynamicData.MetaModel.Default == null)
// Register context and routes
...
}\</code\>\</pre\>
\Othwerwise I would get this exception:\</p\>
\\<code\>\[ArgumentException: L&#39;elemento &egrave; gi&agrave; stato aggiunto. Chiave nel dizionario: &#39;MyAppDataContext&#39;. Chiave aggiunta: &#39;MyAppDataContext&#39;\]\</code\>\</pre\>
\The exception meaning: The item is already present, Key in dictionary 'MyAppDataContext', Key added 'MyAppDataContext'.\</p\>Wed, 18 Jun 2008 12:21:00 GMThttp://andreaazzola.com/check-metamodel-existence-dynamic-data-application

Set the ConnectionString at Runtime with DynamicData

http://andreaazzola.com/set-connectionstring-runtime-dynamicdata/The following snippet customizes the .NET ConnectionString property at runtime in a Dynamic Data application.
Edit the file Global.asax and modify the RegisterRoutes(RouteCollection routes) method. Instead of the following statement:
model.RegisterContext(typeof(XYZDataContext), new ContextConfiguration() { ScaffoldAllTables = true });
Use
model.RegisterContext
(
() =&gt; new…\The following snippet customizes the .NET ConnectionString property at runtime in a Dynamic Data application.\</p\>
\Edit the file \<strong\>Global.asax\</strong\> and modify the \<strong\>RegisterRoutes(RouteCollection routes)\</strong\> method. Instead of the following statement:\</p\>
\\<code class="cs"\>model.RegisterContext(typeof(XYZDataContext), new ContextConfiguration() { ScaffoldAllTables = true });\</code\>\</pre\>
\Use\</p\>
\\<code class="cs"\>model.RegisterContext
(
() =&gt; new XYZDataContext(connectionString),
new ContextConfiguration() { ScaffoldAllTables = true }
);\</code\>\</pre\>
\Where \<em\>connectionString\</em\> is your string value. The \<strong\>RegisterRoutes\</strong\>&#39;s parameter collection can be customized without comprimosing the application functionality.\</p\>Mon, 16 Jun 2008 11:20:00 GMThttp://andreaazzola.com/set-connectionstring-runtime-dynamicdata

Consuming .NET Webservices Using PHP and NuSoap

http://andreaazzola.com/consuming-net-web-services-using-php-nusoap/In my scenario a .NET webservice offers particular encrypting capabilities. I need to consume the webservice with PHP by sending my plain string to get an encrypted one in return. The .NET webservice is working properly. I found the NuSoap library, and adopted it, her the inclusion:
require_once(&#39;lib/nusoap.php&#39;);
And here the code:
// requires web service&#39;s specifications aka…\In my scenario a .NET webservice offers particular encrypting capabilities. I need to consume the webservice with PHP by sending my plain string to get an encrypted one in return. The .NET webservice is working properly. I found the \<a href="http://sourceforge.net/projects/nusoap/" title="NuSoap project Home Page"\>NuSoap\</a\> library, and adopted it, her the inclusion:\</p\>
\\<code class="php"\>require_once(&#39;lib/nusoap.php&#39;);\</code\>\</pre\>
\And here the code:\</p\>
\\<code class="php"\>// requires web service&#39;s specifications aka wsdl
// \$parameters:
// requires following the array &#39;notation&#39;
// array(&#39;parameters&#39; =&gt; (array(&#39;text&#39; =&gt; &#39;Hello World!!!&#39;)));
// that equals to Hello World!!!
// \$proxy (-&gt;host, -&gt;port, -&gt;username, -&gt; password)
// optional, uses a proxy server
function consume_webservice(\$wsdl, \$method, \$parameters, \$debug = false, \$proxy = null)
{
if (\$proxy != null)
\$proxy-&gt;host = \$proxy-&gt;port = \$proxy-&gt;username = \$proxy-&gt;password = false;
\$client = new soapclient(\$wsdl, true, \$proxy-&gt;host, \$proxy-&gt;port,
\$proxy-&gt;username, \$proxy-&gt;password);
\$err = \$client-&gt;getError();
if (\$err)
echo &#39;Constructor error&#39; . \$err;
\$result = \$client-&gt;call(\$method, \$parameters);
// check for a fault
if (\$client-&gt;fault)
{
echo &#39;Fault&#39;;
print_r(\$result);
}
else
{
// check for errors
\$err = \$client-&gt;getError();
if (\$err)
echo &#39;Error&#39; . \$err;
}
if (\$debug)
{
echo &#39;Request&#39; . htmlspecialchars(\$client-&gt;request, ENT_QUOTES);
echo &#39;Response&#39; . htmlspecialchars(\$client-&gt;response, ENT_QUOTES);
echo &#39;Debug&#39; . htmlspecialchars(\$client-&gt;debug_str, ENT_QUOTES);
}
return \$result;
}\</code\>\</pre\>
\This approach works only with \<a href="http://en.wikipedia.org/wiki/SOAP"\>soap\</a\> webservices. Please note that .NET web services includes all response content into a &quot;\<em\>parameters&quot;\</em\> section by design.\</p\>Tue, 23 Oct 2007 21:04:00 GMThttp://andreaazzola.com/consuming-net-web-services-using-php-nusoap

Using an ajax:ModalPopup Without a TargetControl

http://andreaazzola.com/using-ajax-modalpopup-targetcontrol/The ModalPopup extender requires a control for firing up, that can be set through the TargetControlID property. However, sometimes you may want to show and hide the panel programmatically. All you need, is a fake activator like following:
&lt;div id=&quot;divFakeActivator&quot; runat=&quot;server&quot; style=&quot;display: none&quot; /&gt;
The Extender
&lt;ajax:ModalPopupExtender…\The ModalPopup extender requires a control for firing up, that can be set through the \<em\>TargetControlID\</em\> property. However, sometimes you may want to show and hide the panel programmatically. All you need, is a fake activator like following:\</p\>
\\<code class="html"\>&lt;div id=&quot;divFakeActivator&quot; runat=&quot;server&quot; style=&quot;display: none&quot; /&gt;\</code\>\</pre\>
\<h2\>The Extender\</h2\>
\\<code class="xml"\>&lt;ajax:ModalPopupExtender ID=&quot;mpeInfo&quot; runat=&quot;server&quot; TargetControlID=&quot; divFakeActivator &quot;
PopupControlID=&quot;pnlInfo&quot; CancelControlID=&quot;bttInfoClose&quot; /&gt;\</code\>\</pre\>
\<h2\>The Panel\</h2\>
\\<code class="xml"\>&lt;asp:Panel ID=&quot;pnlInfo&quot; runat=&quot;server&quot;&gt;
Hello World!!!
&lt;/asp:Panel&gt;\</code\>\</pre\>
\<h2\>The C# code\</h2\>
\\<code class="html"\>// C#
mpeInfo.Show();
mpeInfo.Hide();\</code\>\</pre\>Tue, 25 Sep 2007 09:41:00 GMThttp://andreaazzola.com/using-ajax-modalpopup-targetcontrol

Issues With AJAX and a Custom HttpModule

http://andreaazzola.com/issues-ajax-custom-httpmodule/My web app needs to catch every non-existent path as a search string, because I'm implementing an HttpModule that handle URLs in a SEO friendly way:
http://contoso.com/search-string
But the AJAX script module (a.k.a. &quot;ScriptModule&quot;) decides to quit on me. So I add the following module:
&lt;add name=&quot;ScriptModule&quot;
type=&quot;System.Web.Handlers.ScriptModule,…\My web app needs to catch every non-existent path as a search string, because I'm implementing an HttpModule that handle URLs in a SEO friendly way:\</p\>
\\<code\>  http://contoso.com/search-string\</code\>\</pre\>
\But the AJAX script module (a.k.a. &quot;ScriptModule&quot;) decides to quit on me. So I add the following module:\</p\>
\\<code class="xml"\>&lt;add name=&quot;ScriptModule&quot;
type=&quot;System.Web.Handlers.ScriptModule, System.Web.Extensions, ...&quot; /&gt;
&lt;add name=&quot;MyModule&quot; type=&quot;MyModule&quot;/&gt;\</code\>\</pre\>
\Then Internet Explorer (js debug enabled) decides it was the right time for firing fire some fancy javascript errors, like &quot;AJAX Framework failed to load....&quot;. No problem, back to fixer mode... and this snippet is the final, working piece of snippet art:\</p\>
\\<code class="cs"\>using...
public class MyModule : IHttpModule
{
public MyModule()
{
}
private void Application_OnAfterProcess(Object source, EventArgs e)
{
HttpApplication application = (HttpApplication)source;
HttpContext context = application.Context;
if (context.Request.Headers\[&quot;x-microsoftajax&quot;\] == null)
{
if ((!System.IO.File.Exists(application.Request.PhysicalPath)) &amp;&amp;
(!application.Request.Url.ToString().Contains(&quot;.axd&quot;)) &amp;&amp;
(!application.Request.Url.ToString().Contains(&quot;.asmx&quot;)))
{
string newUrl = &quot;~/Search.aspx?q=&quot;
+ context.Server.UrlEncode(application.Request.Url.Segments.Last());
...
context.RewritePath(newUrl);
}
}
}
\#region IHttpModule Members
void IHttpModule.Init(HttpApplication context)
{
context.PostResolveRequestCache +=
(new EventHandler(this.Application_OnAfterProcess));
}
}\</code\>\</pre\>
\Basically it intervenes at a specific part of the Request handle (AfterProcess) and just if a certain header is found then excludes the AJAX web services from the search, so they can be dealt with in the classic fashion.\</p\>Sat, 18 Jun 2005 17:32:00 GMThttp://andreaazzola.com/issues-ajax-custom-httpmodule
