---
title: "Save Money with Traditional Wet Shaving"
draft: false
date: 2018-04-07 10:02
---
# Save Money with Traditional Wet Shaving

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2018-04-07 10:02
\[<a href="index.html" target="_self" title="Permalink to Save Money with Traditional Wet Shaving">Permalink</a>\]

I own a Gillette "Fusion ProGlide" (<a href="https://amzn.to/2QK1ot3" target="_blank" title="Gillette Fusion5 ProGlide Men’s Razor, Handle &amp; 2 Blade Refills">amazon link</a>), a very effective multi-blade razor, equipped with a movable head that allows for reaching all face's nooks and crannies quickly, pretty much without risks. It features a vibrating mechanism, which makes it very comfortable. But the cost of cartridges, no less than 11 euros for 4, is not cheap.

For some years now I've been interested in minimalism, especially from a financial point of view, simply trying to reason where money can be spent consciously. There's no guarantee in the path of the "becoming man" for "shaving orientation": when the first beard appears, our fathers usually direct us towards the multi-blade as a practical and rarely dangerous option. With the passing of years it becomes as a plateau for many men.

## The Safety Razor

Safety razors usually have two components, handle and blade holder. The blade needs to be mounted in the blade holder, it is used at an inclination of 30 degrees, inclination which might slightly change depending on the razor. Two sharp sides allows for more passings and less rinsing. Both razor sides are usually equipped with combs (closed or opened), that stretch the skin before blade's passage. Replacing the blade is as easy as unscrewing the parts and opening the blade holder. Other models may have a TTO (twist-to-open) or "butterfly" opening system, a handy version that opens by "screwing" the bottom part of the handle.

First safety razors in their traditional T-shape were produced in Sheffield, England, around the middle of the fourteenth century. In 1880 the American brothers Kampfe had the design patented, their version had a single blade meant to be removed and sharpened like we usually do with knives; in 1900 are the first disposable razor blades are born. It was the 1918 when the United States decided to equip soldiers with razors: the beard made the gas mask ineffective. Gillette wins the procuremnt bid of 3.5 million razors,and 32 million razor blades. The T-shape of has since remained unchanged.

Price of blades makes this type of razors extremely convenient: quality razor blades can be found at a price of 3 cents each, while the "Fusion ProGlide" multi-blade cartridges cost no less than 2.75 euro each, but comes with a longer life span. The comparison does not acquire a sense until the costs of the two setups are compared. Below a project based on 182 annual shaves.

### Gillette Fusion ProGlide

- Razor's cost=12 € (<a href="https://amzn.to/2QK1ot3" target="_blank" title="Gillette Fusion5 ProGlide Men’s Razor, Handle &amp; 2 Blade Refills">amazon link</a>)
- **Start-up=12 €**

- Price for each cartridge 11/4=2.75 €
- Each cartridge is lasts about 10 shaves, cost per shave=.275 €
- **182 shaves cost=50 €**

### Edwin Jagger DE89bl

- Razor's cost=16 € (<a href="https://amzn.to/2rtqTAA" target="_blank" title="Edwin Jagger Double Edge Safety Razor">amazon link</a>)
- Brush's cost=15 € (sintetic that emulates badger, <a href="https://amzn.to/2Pzv5bw" target="blank" title="RazoRock Plissoft Disruptor Synthetic Shaving Brush">amazon link</a>)
- **Start-up=31 €**

- Cost for each blade 10 €/100=0.1 €
- Each blade lasts about 3 shave, cost per shave=.0333 €
- **182 shaves cost=6.06 €**

## Considerations

The start-up costs of the traditional setup are basically double, they are however compensated by razor and brush life span, several years at least. The example demonstrates how you can spend up to 8 times less with the traditional setup.

Paradoxically, ther's a well-developed market niche for traditional shaving aficionados, rich with a variety of products from the most exotic artisinal and luxurious manufacture. According to modern masculine style rules in fact, traditional shaving is a plus.

I personally come from more than two years of traditional shaving, to is a moment of wellness, I spent time experimenting different razor blades—which might differ in hardness and sharpening—or appreciating the softness the density and the aroma of a new soap .... All this while still saving money.

## Subscriptions

A small side note... many services now offer cartridge supplies subscriptions, meaning that you can automatically get multiblades delivered to your home. These offers aim to gain space in a monopolized market leaded by a few companies by distrupting the business model, committing the customer to the volumes, while choosing alternative suppliers and technologies, in order to offer competitive prices.

Personally I appreciate the existence of these alternatives, unfortunately I do not see a real competion to traditional shaving due to the recurring costs these subscription exercise.

Categories:
<a href="../category/extreme-saving.html" class="tag">Extreme Saving</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Save%20Money%20with%20Traditional%20Wet%20Shaving&amp;url=http%3a%2f%2fandreaazzola.com%2fsaving-traditional-wet-shaving%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fsaving-traditional-wet-shaving%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>