---
title: "Asus EeePC 1201HA review"
draft: false
date: 2010-01-09 11:13
---
# Asus EeePC 1201HA review

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2010-01-09 11:13
\[<a href="index.html" target="_self" title="Permalink to Asus EeePC 1201HA review">Permalink</a>\]

## First look

The EeePC 1201HA is part of a new generation of big netbooks, that refers to not just the hardware that accompanies them as far as the size, in fact, this netbook has a 12.1 inch monitor.

It comes with Windows 7 but in some cases with XP, provides opportunities for overclocking, can play movies in HD (decently up to 720p) with no trouble, has 2GB of ram (*IMHO very valuable*) 160GB of hard disk (+500 online, free for the first year), isolated keys, very light, autonomy is good: 7/8 hours in standard office applications.

## Power On

Unfortunately, the pre-installed system had some difficulties in starting, due to some missing DLLs (...), fortunately it provides a recovery CD that has helped to solve everything in a few hours, it was obviously quite alarming, in hand to the novice user in fact, the Netbook would probably have to go back to assistance.

The performances guaranteed by Windows 7 are good enough, the boot in some cases has outpaced that of the MacBook Pro!!, but you'll definitely need to turn off Aero and overclock the processor (I suggest 20%) and work almost always on 'Superperformace-mode'.

## Peculiarities

The design is simple, black never goes out of fashion, but the paint layer is very easy to smudge. It is part of the ASUS Seashell family so it's very compact and lightweight (approximately 1.5 kg). The connectivity section is good, comes with an Ethernet and WI-FI b / g / n. Nice about keyboard: you can change the way it consume/performs (Power Saving, Auto High-Performance, Super Performance, High Performance), activate the standby, turn off the monitor, activate and adjust the sound, manage your media files (rew, stop, pause / play, fwd) and activate the web-cam.

## Conclusion

It's very quiet, the ideal PC for the simple things of everyday (e-mail, browsing, chat, downloads, file sharing, ...). I get Visual Studio 2008 running and not too bad, and Eclipse, can be used to develop but does not offer the performance of a workstation, and the relatively tiny display in the long run... may be annoying.

## Specs

- Display: 12.1 inch, 1366 x 768 pixels
- CPU: 1.33GHz Intel Atom Z520
- Graphics & chipset: Intel US15W / GMA 500 graphics
- OS: Windows 7 Home Premium
- Memory: 2GB DDR2
- Storage: 250GB HDD + 500GB web-based storage
- Connectivity: 802.11b/g/n WiFI, Bluetooth, Ethernet
- I/O: VGA, 3 USB 2.0 ports, SD card slot, mic, headphones
- Webcam: 0.3MP
- Touchpad: Supports multitouch gestures
- Battery: 6 cells, 8 hours
- Colors: Black, blue, or red
- Dimensions: 11.7″ x 8.2″ x 1.3″
- Weight: 3.1 pounds

Categories:
<a href="../category/gears.html" class="tag">Gears</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Asus%20EeePC%201201HA%20review&amp;url=http%3a%2f%2fandreaazzola.com%2fasus-eeepc-1201ha%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fasus-eeepc-1201ha%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

![](/images/39cebc4727e83b50df6dc01c90b776912d049d54.jpg)

How did you manage to overclock this? I've been trying with SetFSB for a while and haven't been able to get anywhere. I got this laptop from Woot for \$250 and couldn't be happier (for the money, of course).

*~Jake*

![](/images/4092bff58b39c9dfefdcc0cd1bdcd6dfc5dfc52c.png)

Had the same problem, maybe you could check if your BIOS is up to date, after that in fact I was able to use the overclock option. I don't remember specifically if that helped or if I was simply missing the menu option... With regard to how I can recommend this video, take a look to minute 3:25~. Asus EeePC 1201HA - Unbox e prime impressioni <http://youtu.be/_FDP71fVzHE>

*~<a href="http://brk.me" target="_blank" title="Visit Andrea&#39;s web site">Andrea</a>*

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment2&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment2" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>