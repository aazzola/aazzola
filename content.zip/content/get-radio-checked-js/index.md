---
title: "Get and Set Radio controls checked value with JavaScript"
draft: false
date: 2009-03-20 21:25
---
# Get and Set Radio controls checked value with JavaScript

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2009-03-20 21:25
\[<a href="index.html" target="_self" title="Permalink to Get and Set Radio controls checked value with JavaScript">Permalink</a>\]

Suppose you have the following **radio** controls:

       1:  <input name="Book" type="radio" value="asp" checked="true">ASP .NET</input>

       2:  <input name="Book" type="radio" value="wcf" >Windows Presentation Foundation</input>

       3:  <input name="Book" type="radio" value="slg" >Silverlight 2.0</input>

**How do you get the selected value via JavaScript?**
As you can see in the example, radio controls are declared in a particular way, there are no **id**s, instead there are **name**s that identifies related **radio**s.
You should be aware that *Book* is not treated as an unique control by the browser's engine, because each radio control correspond to one different element in the page.

**The <u>getElementsByName</u> method**
<a href="http://www.w3.org/TR/DOM-Level-2-HTML/html.html#ID-71555259" target="_blank" title="W3C Reccomendation">This method</a> allows you to obtain a collection of controls from the (X)HTML <a href="http://en.wikipedia.org/wiki/Document_Object_Model" target="_blank" title="Document Object Model">DOM</a>, by specifying the common **name** value.
Now we can write the following code to get or set the **checked** value:

 

 

       1:      function getRadio(name) {

       2:          var radios = document.getElementsByName(name);

       3:   

       4:          for (var i = 0; i < radios.length; i++) {

       5:              if (radios[i].checked) {

       6:                  return radios[i].value;

       7:              }

       8:          }

       9:   

      10:          return null;

      11:      }

      12:   

      13:      function setRadio(name, val) {

      14:          var radios = document.getElementsByName(name);

      15:   

      16:          for (var i = 0; i < radios.length; i++) {

      17:              radios[i].checked = (radios[i].value == val);

      18:          }

      19:      }

 

 

Categories:

Share on:
<a href="https://twitter.com/intent/tweet?text=Get%20and%20Set%20Radio%20controls%20checked%20value%20with%20JavaScript&amp;url=http%3a%2f%2fandreaazzola.com%2fget-radio-checked-js%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2fget-radio-checked-js%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

![](/images/39cebc4727e83b50df6dc01c90b776912d049d54.jpg)

Nice!

*~Flavio*

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>