---
title: "Book Review: The 10X Rule by Grant Cardone"
draft: false
date: 2016-12-04 17:03
---
# Book Review: The 10X Rule by Grant Cardone

[Andrea Azzola](../index.html "Back to the Home Page")


Posted on
2016-12-04 17:03
\[<a href="index.html" target="_self" title="Permalink to Book Review: The 10X Rule by Grant Cardone">Permalink</a>\]

Among the bestsellers of the self-help category on Audible.com, **The 10X Rule** is a book about productivity within the business world, it underlines the importance of not limiting goals and *taking 10 times higher levels of action* in order to achieve them, placing the success as an essential milestone: *"if you're not first, you're last"*.

The book's author is Greg Cardone, an American entrepreneur with an estimated networth of 500 million dollars. He began his career as a car salesman, soon CEO of Freedom Motorsports Group Inc., he worked on a television series for the National Geographic channel named Turnaround King, where he helps small businesses to get back on their feet. Author of 10 books, now directs his companies *Cardone Acquisitions*, *Cardone Enterprises* and *The Cardone Group*; Cardone has been choosen by Forbes as the most promising Marketing Influencer for 2017.

## Book Review

The beginning of the book was a bit disappointing: a little bit irrational, full of hyperboles, not what I hoped from a five-starred best seller. Cardone uses *an aggressive salesman style*, sometimes *challenging the reader's values in a subtly disrespectful way*. I soon stopped reading and was ready to discard it.

There was some potential in the ideas though, so I spoke about it to a friend, he read the book, agreed on my objections and in the end he was fairly optimistic. So I felt compelled to finish considered that after all, the narration was quite enjoyable. One thing that particularly set me off: Cardone stresses that commitment to success is a duty owed to the simple fact the we exists. He discredits the values of a modest/frugal life, stating they are values taught by some kind of propaganda to keep people under control. But of course that's one of Cardone's opinion on which no one is oblidged to embrace.

As today however, this book is one the most mentioned in our conversations, for one simple reason. It talks about a single fundamental rule that people sometimes don't know or forget: **if you to want to get 100, go for 1000**—*an Italian saying*.

Most people might tend to look at the "once blue moon successes" and forget that statistically for every success there are countless failures and only increasing the amount of effort one can streghten her skills and increase her chances. Throughout the book there are many clever ideas and interpretations to credit this principle, making it a worthwhile reading.

This controversial concepts had surely gained the book a lot of attention, which has become a New York Time best seller. And like Cardone reminds us: there's no such thing as bad publicity.

## My 6 Key Takeaways

- set goals that are ten time more ambitious
- act 10 times greater than what you consider normal
- to compete is wrong, one must dominate
- obsession is not a disease, it's a blessing
- getting clients is more important than supporting them
- commit and take opportunities, figure out "stuff" later

<a href="https://amzn.to/2NnPD60" class="btn btn-warning" role="button" target="_blank" rel="nofollow" title="The 10X Rule on Amazon.com">All editions of **The 10X Rule** on Amazon.com</a>

Categories:
<a href="../category/books.html" class="tag">Books</a><a href="../category/entrepreneurship.html" class="tag">Entrepreneurship</a><a href="../category/goal-setting.html" class="tag">Goal Setting</a><a href="../category/personal-development.html" class="tag">Personal Development</a>

Share on:
<a href="https://twitter.com/intent/tweet?text=Book%20Review:%20The%2010X%20Rule%20by%20Grant%20Cardone&amp;url=http%3a%2f%2fandreaazzola.com%2freview-10x-rule-grant-cardone%2f" target="_blank" title="Share it on Twitter">Twitter</a>, 
<a href="http://facebook.com/sharer.php?u=http%3a%2f%2fandreaazzola.com%2freview-10x-rule-grant-cardone%2f" target="_blank" title="Share it on Facebook">Facebook</a>
<a href="https://AndreaAzzola.com" rel="author"></a>

### Comments

<a href="javascript:__doPostBack(&#39;ctl00$cphBody$cmm$lbtNewComment1&#39;,&#39;&#39;)" id="ctl00_cphBody_cmm_lbtNewComment1" class="action">Post a new comment</a>

Author's portrait

<a href="http://twitter.com/AndreaAzzola" rel="me" target="_blank" data-text="Twitter" title="Stay up to date with my tweets">My Twitter profile</a><a href="http://www.linkedin.com/in/andreaazzola" rel="me" target="_blank" data-text="LinkedIn" title="Find me on LinkedIn">My LinkedIn profile</a><a href="http://www.facebook.com/andrea.azzola" rel="me" target="_blank" data-text="Facebook" title="Get in touch with Facebook">My Facebook profile</a><a href="http://www.pinterest.com/andreaazzola" rel="me" target="_blank" data-text="Pinterest" title="I&#39;m on Pinterest!">My Pinterest profile</a><a href="http://instagram.com/andrea.azzola" rel="me" target="_blank" data-text="Instagram" title="My Instagram profile">My Instagram profile</a>

- <a href="../about/index.html" style="font-weight:bold" data-text="About" title="Short summary">About</a>
- <a href="../articles/index.html" style="font-weight:bold" data-text="Articles" title="Collection of all articles in this website">Articles</a>
- <a href="../books/index.html" style="font-weight:bold" data-text="Books" title="My book recommendations">Books</a>
- <a href="../contact/index.html" style="font-weight:bold" data-text="Contact" title="Short summary">Contact</a>
- <a href="../feed/index.html" data-text="RSS feed" title="Subscribe to this blog">RSS feed</a>
- <a href="../login/index.html" data-text="Login" title="Login">Login</a>

- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageEN%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageEN" class="lang-sm lang-lbl" lang="en"></a>
- <a href="javascript:WebForm_DoPostBackWithOptions(new%20WebForm_PostBackOptions(%22ctl00$stp1$lbLanguageIT%22,%20%22%22,%20true,%20%22%22,%20%22%22,%20false,%20true))" id="ctl00_stp1_lbLanguageIT" class="lang-sm lang-lbl" lang="it"></a>

#### Newsletter

 
 

<a href="../category/books/index.html" class="category" style="font-size:112%;">Books</a>
<a href="../category/decision-fatigue/index.html" class="category" style="font-size:112%;">Decision Fatigue</a>
<a href="../category/diet/index.html" class="category" style="font-size:112%;">Diet</a>
<a href="../category/extreme-saving/index.html" class="category" style="font-size:119%;">Extreme Saving</a>
<a href="../category/finance/index.html" class="category" style="font-size:112%;">Finance</a>
<a href="../category/financial-independence/index.html" class="category" style="font-size:125%;">Financial Independence</a>
<a href="../category/fitness/index.html" class="category" style="font-size:119%;">Fitness</a>
<a href="../category/gears/index.html" class="category" style="font-size:112%;">Gears</a>
<a href="../category/geo-arbitrage/index.html" class="category" style="font-size:112%;">Geo Arbitrage</a>
<a href="../category/goal-setting/index.html" class="category" style="font-size:112%;">Goal Setting</a>
<a href="../category/nutrition/index.html" class="category" style="font-size:112%;">Nutrition</a>
<a href="../category/personal-branding/index.html" class="category" style="font-size:112%;">Personal Branding</a>
<a href="../category/personal-development/index.html" class="category" style="font-size:150%;">Personal Development</a>
<a href="../category/productivity/index.html" class="category" style="font-size:125%;">Productivity</a>
<a href="../category/time-management/index.html" class="category" style="font-size:106%;">Time Management</a>